# Email Monitoring - User Guide

## How to Add Emails for Phishing Detection

### Step 1: Access Email Monitor

1. **Open the Application**
2. **Click "Email Monitor"** in the navigation menu (top header or sidebar)
3. You'll see the Email Monitor dashboard with 4 tabs

---

## Step 2: Get Your Monitoring Address

### In the "Setup" Tab:

1. Look for the **"Monitoring Address"** section (gray box)
2. You'll see: `security@cyberguard.monitor`
3. Click the **Copy button** (📋 icon) to copy this address

**This is the address you'll forward suspicious emails to!**

---

## Step 3: Forward Suspicious Emails

### When you receive a suspicious email:

#### Option A: Using Gmail
1. Open the suspicious email in Gmail
2. Click the **"Forward"** button (→ icon)
3. In the "To" field, paste: `security@cyberguard.monitor`
4. Click **"Send"**

#### Option B: Using Outlook
1. Open the suspicious email in Outlook
2. Click **"Forward"** in the ribbon
3. In the "To" field, paste: `security@cyberguard.monitor`
4. Click **"Send"**

#### Option C: Using Yahoo Mail
1. Open the suspicious email in Yahoo Mail
2. Click the **"Forward"** button
3. In the "To" field, paste: `security@cyberguard.monitor`
4. Click **"Send"**

#### Option D: Using Any Email Client
1. Open the suspicious email
2. Find the "Forward" or "Forward as attachment" option
3. Enter: `security@cyberguard.monitor`
4. Send the email

---

## Step 4: View Analysis Results

### Check the "Monitored Emails" Tab:

1. Click the **"Monitored Emails"** tab
2. Your forwarded email will appear with:
   - **Risk Level Badge**: 🔴 High Risk / 🟠 Medium Risk / 🟢 Low Risk
   - **Sender**: Who sent the email
   - **Subject**: Email subject line
   - **Analysis**: AI-generated phishing analysis
   - **Timestamp**: When it was analyzed

3. Click **"View Email Content"** to see the full email
4. Click **"Mark Read"** after reviewing
5. Click **🗑️ Delete** to remove from history

---

## Step 5: Review Statistics

### Check the "Statistics" Tab:

- **Total Monitored**: How many emails you've analyzed
- **High Risk**: Number of dangerous phishing attempts
- **Medium Risk**: Number of suspicious emails
- **Unread Alerts**: Emails you haven't reviewed yet

---

## Quick Reference

### Where to Find Things:

| What You Need | Where to Find It |
|--------------|------------------|
| **Monitoring Address** | Setup Tab → Monitoring Address section |
| **Copy Address Button** | Next to the monitoring address (📋 icon) |
| **Analyzed Emails** | Monitored Emails Tab |
| **Risk Levels** | Color-coded badges on each email |
| **Statistics** | Statistics Tab |
| **Recent Alerts** | Alerts Tab |

---

## Example Workflow

### Real-World Example:

1. **You receive an email** from "support@paypa1.com" (notice the "1" instead of "l")
2. **You suspect it's phishing** because:
   - Suspicious sender address
   - Asks for password
   - Urgent language

3. **Forward the email**:
   - Click Forward in your email client
   - To: `security@cyberguard.monitor`
   - Send

4. **Check CyberGuard**:
   - Go to Email Monitor → Monitored Emails tab
   - See the email with a 🔴 **HIGH RISK** badge
   - Read the analysis: "Phishing attempt detected. Sender domain is typosquatting PayPal..."

5. **Take action**:
   - Delete the original email from your inbox
   - Mark as read in CyberGuard
   - Report to your email provider

---

## Important Notes

### Privacy & Security:

✅ **What we DO**:
- Analyze ONLY emails you forward to us
- Store analysis results for your review
- Provide risk assessment and recommendations

❌ **What we DON'T do**:
- Access your email inbox
- Read your other emails
- Share your data with anyone
- Automatically monitor your emails

### Tips for Best Results:

1. **Forward the entire email** (not just a screenshot)
2. **Include email headers** if possible (shows sender details)
3. **Forward as soon as you receive** suspicious emails
4. **Check the Monitored Emails tab** regularly for alerts
5. **Review the analysis** to learn about phishing tactics

---

## Troubleshooting

### "I forwarded an email but don't see it"

**Solution**: 
- Wait a few seconds and refresh the page
- Check that you forwarded to the correct address: `security@cyberguard.monitor`
- Make sure you're logged in to CyberGuard

### "Where is the monitoring address?"

**Solution**:
- Go to Email Monitor → Setup Tab
- Scroll down to "Monitoring Address" section
- Click the copy button (📋) to copy it

### "I can't find Email Monitor"

**Solution**:
- Look in the top navigation menu
- Or check the sidebar menu
- It should be listed after "Phishing Detection"

### "How do I know if an email is dangerous?"

**Solution**:
- Look at the risk level badge:
  - 🔴 **HIGH RISK** = Dangerous, delete immediately
  - 🟠 **MEDIUM RISK** = Suspicious, be cautious
  - 🟢 **LOW RISK** = Relatively safe, but review analysis

---

## Need Help?

If you have questions or issues:

1. Click **"Help & Support"** in the navigation menu
2. Check the **FAQ section**
3. Submit a **feedback** with your question
4. Contact your system administrator

---

## Summary

**To add emails for monitoring:**

1. ✅ Go to **Email Monitor** page
2. ✅ Copy the monitoring address: `security@cyberguard.monitor`
3. ✅ Forward suspicious emails to that address
4. ✅ Check **Monitored Emails** tab for analysis
5. ✅ Review risk level and recommendations

**That's it!** The system will automatically analyze every email you forward and alert you to phishing threats.

---

*Last Updated: December 2024*
*CyberGuard AI Assistant - Email Monitoring System*
