import { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, ArrowLeft, CheckCircle2, FileText, Lock, ChevronRight } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { QuizLevel as QuizLevelType, QuizModule, UserQuizProgress } from '@/types/types';

export default function QuizLevel() {
  const { user } = useAuth();
  const { levelId } = useParams();
  const navigate = useNavigate();
  const [level, setLevel] = useState<QuizLevelType | null>(null);
  const [modules, setModules] = useState<QuizModule[]>([]);
  const [progress, setProgress] = useState<UserQuizProgress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (levelId) {
      loadData();
    }
  }, [levelId]);

  const loadData = async () => {
    setLoading(true);
    
    const levels = await api.quiz.getLevels();
    const currentLevel = levels.find(l => l.id === Number(levelId));
    setLevel(currentLevel || null);
    
    const modulesData = await api.quiz.getModulesByLevel(Number(levelId));
    setModules(modulesData);
    
    const userId = await userManager.getCurrentUserId();
    const progressData = await api.quiz.getUserProgress(userId);
    setProgress(progressData);
    
    setLoading(false);
  };

  const getModuleProgress = (moduleId: string) => {
    return progress.find(p => p.module_id === moduleId);
  };

  const isModuleUnlocked = (moduleNumber: number) => {
    if (moduleNumber === 1) return true;
    const previousModule = modules.find(m => m.module_number === moduleNumber - 1);
    if (!previousModule) return false;
    const prevProgress = getModuleProgress(previousModule.id);
    return prevProgress?.completed || false;
  };

  const handleModuleClick = (module: QuizModule) => {
    if (!isModuleUnlocked(module.module_number)) {
      return;
    }
    navigate(`/quiz/${levelId}/${module.module_number}`, { state: { moduleId: module.id } });
  };

  const getLevelProgress = () => {
    if (modules.length === 0) return 0;
    const completedModules = modules.filter(m => {
      const prog = getModuleProgress(m.id);
      return prog?.completed;
    }).length;
    return (completedModules / modules.length) * 100;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-12 w-12 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading modules...</p>
        </div>
      </div>
    );
  }

  if (!level) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">Level not found</p>
          <Link to="/quiz">
            <Button className="mt-4">Back to Quiz</Button>
          </Link>
        </div>
      </div>
    );
  }

  const levelProgress = getLevelProgress();

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                <Shield className="h-6 w-6 text-primary" />
                <span className="font-bold text-xl">CyberGuard AI</span>
              </Link>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          {/* Back Button */}
          <Link to="/quiz">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Levels
            </Button>
          </Link>

          {/* Level Header */}
          <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <span className="text-5xl">{level.badge_icon}</span>
                <div className="flex-1">
                  <h1 className="text-3xl font-bold mb-2">
                    Level {level.id} - {level.title}
                  </h1>
                  <p className="text-muted-foreground mb-4">{level.description}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <span>7 modules • 70 questions</span>
                    {levelProgress > 0 && (
                      <span className="font-medium text-primary">
                        {Math.round(levelProgress)}% complete
                      </span>
                    )}
                  </div>
                  {levelProgress > 0 && (
                    <Progress value={levelProgress} className="h-2" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Modules List */}
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">Modules</h2>
            {modules.map(module => {
              const moduleProgress = getModuleProgress(module.id);
              const isCompleted = moduleProgress?.completed || false;
              const score = moduleProgress?.score || 0;
              const unlocked = isModuleUnlocked(module.module_number);

              return (
                <Card 
                  key={module.id}
                  className={`${!unlocked ? 'opacity-60' : 'hover:shadow-lg'} transition-all cursor-pointer`}
                  onClick={() => handleModuleClick(module)}
                >
                  <CardContent className="p-5">
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        <FileText className="h-8 w-8 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-lg">
                            Module {module.module_number} - {module.title}
                          </h3>
                          {isCompleted && (
                            <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                          )}
                          {!unlocked && (
                            <Lock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{module.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>10 questions</span>
                          {isCompleted && (
                            <span className="font-medium text-primary">Score: {score}%</span>
                          )}
                          {!unlocked && (
                            <Badge variant="secondary" className="text-xs">
                              Complete previous module to unlock
                            </Badge>
                          )}
                        </div>
                      </div>
                      {unlocked && (
                        <div className="flex-shrink-0 flex items-center gap-2">
                          <span className="text-sm font-medium text-primary">
                            {isCompleted ? 'Retake' : 'Start'}
                          </span>
                          <ChevronRight className="h-5 w-5 text-primary" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Badge Info */}
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Earn the {level.badge_name} Badge
              </h3>
              <p className="text-sm text-muted-foreground mb-3">
                Complete all 7 modules with a score of 70% or higher to earn the <strong>{level.badge_name}</strong> badge and unlock the next level!
              </p>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{level.badge_icon}</span>
                <span className="font-medium">{level.badge_name}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
