import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, ArrowLeft, BookOpen, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';

const learningResources = {
  'password-security': {
    title: 'Password Security Best Practices',
    description: 'Learn how to create and manage strong passwords effectively to protect your online accounts.',
    sections: [
      {
        title: 'Why Password Security Matters',
        icon: AlertTriangle,
        content: [
          'Weak passwords are the #1 cause of security breaches',
          'Over 80% of hacking-related breaches involve weak or stolen passwords',
          'A strong password is your first line of defense against cyber attacks',
          'Password reuse across multiple sites increases your risk exponentially'
        ]
      },
      {
        title: 'Creating Strong Passwords',
        icon: CheckCircle2,
        content: [
          'Use at least 12-16 characters (longer is better)',
          'Mix uppercase and lowercase letters, numbers, and symbols',
          'Avoid dictionary words, personal information, and common patterns',
          'Consider using passphrases: "Coffee-Morning-Sunrise-2024!"',
          'Never reuse passwords across different accounts',
          'Change passwords immediately if you suspect a breach'
        ]
      },
      {
        title: 'Password Managers',
        icon: Info,
        content: [
          'Use a reputable password manager (LastPass, 1Password, Bitwarden)',
          'Let the manager generate random, complex passwords for you',
          'Only remember one master password (make it very strong!)',
          'Enable two-factor authentication on your password manager',
          'Regularly backup your password vault',
          'Use browser extensions for easy auto-fill'
        ]
      },
      {
        title: 'Two-Factor Authentication (2FA)',
        icon: CheckCircle2,
        content: [
          'Enable 2FA on all accounts that support it',
          'Use authenticator apps (Google Authenticator, Authy) instead of SMS',
          'Keep backup codes in a secure location',
          'Consider hardware security keys (YubiKey) for critical accounts',
          'Never share 2FA codes with anyone',
          'Be wary of phishing attempts asking for 2FA codes'
        ]
      }
    ],
    tips: [
      'Never write passwords on sticky notes or unencrypted files',
      'Use different passwords for work and personal accounts',
      'Check if your passwords have been compromised at haveibeenpwned.com',
      'Update passwords every 3-6 months for critical accounts',
      'Be cautious of "security questions" - use fake answers stored in your password manager'
    ]
  },
  'phishing-attacks': {
    title: 'Recognizing Phishing Attacks',
    description: 'Identify common phishing tactics and protect yourself from email scams and social engineering.',
    sections: [
      {
        title: 'What is Phishing?',
        icon: AlertTriangle,
        content: [
          'Phishing is a cyber attack that uses disguised emails to trick you',
          'Attackers impersonate trusted organizations to steal sensitive information',
          'Common targets: passwords, credit card numbers, social security numbers',
          'Phishing is responsible for over 90% of successful cyber attacks',
          'Anyone can be a victim - even tech-savvy individuals'
        ]
      },
      {
        title: 'Common Phishing Tactics',
        icon: Info,
        content: [
          'Urgent language: "Your account will be closed in 24 hours!"',
          'Suspicious sender addresses: paypa1.com instead of paypal.com',
          'Generic greetings: "Dear Customer" instead of your name',
          'Requests for personal information via email',
          'Suspicious links that don\'t match the claimed destination',
          'Unexpected attachments, especially .exe, .zip, or .scr files',
          'Too-good-to-be-true offers: "You\'ve won $1,000,000!"'
        ]
      },
      {
        title: 'How to Spot Phishing Emails',
        icon: CheckCircle2,
        content: [
          'Check the sender\'s email address carefully (hover over it)',
          'Look for spelling and grammar mistakes',
          'Verify links by hovering before clicking (check the URL)',
          'Be suspicious of urgent or threatening language',
          'Look for generic greetings instead of personalized messages',
          'Check for mismatched logos or poor-quality images',
          'Verify requests by contacting the company directly (not via the email)'
        ]
      },
      {
        title: 'What to Do If You Suspect Phishing',
        icon: AlertTriangle,
        content: [
          'Do NOT click any links or download attachments',
          'Do NOT reply to the email or provide any information',
          'Report the email to your IT department or email provider',
          'Delete the email immediately',
          'If you clicked a link, change your passwords immediately',
          'Monitor your accounts for suspicious activity',
          'Run a security scan on your device'
        ]
      }
    ],
    tips: [
      'When in doubt, go directly to the website instead of clicking email links',
      'Enable email filters and spam protection',
      'Use our Phishing Detector tool to analyze suspicious messages',
      'Educate family members about phishing risks',
      'Report phishing attempts to help protect others'
    ]
  },
  'safe-browsing': {
    title: 'Safe Browsing Habits',
    description: 'Essential practices for secure internet usage and protecting your privacy online.',
    sections: [
      {
        title: 'HTTPS and Secure Connections',
        icon: CheckCircle2,
        content: [
          'Always look for HTTPS (not HTTP) in the URL',
          'Check for the padlock icon in your browser\'s address bar',
          'Never enter sensitive information on non-HTTPS sites',
          'Be cautious of certificate warnings - don\'t ignore them',
          'Use browser extensions like HTTPS Everywhere',
          'Avoid public Wi-Fi for sensitive transactions'
        ]
      },
      {
        title: 'Cookie and Privacy Management',
        icon: Info,
        content: [
          'Regularly clear cookies and browsing history',
          'Use private/incognito mode for sensitive browsing',
          'Adjust browser privacy settings to limit tracking',
          'Block third-party cookies in your browser settings',
          'Use privacy-focused browsers (Firefox, Brave)',
          'Install privacy extensions (Privacy Badger, uBlock Origin)',
          'Review and limit browser permissions for websites'
        ]
      },
      {
        title: 'Safe Download Practices',
        icon: AlertTriangle,
        content: [
          'Only download from official and trusted sources',
          'Verify file checksums when available',
          'Scan downloads with antivirus before opening',
          'Be wary of "free" software that seems too good to be true',
          'Read user reviews before downloading applications',
          'Avoid clicking "Download" buttons in ads',
          'Keep your downloads folder organized and clean'
        ]
      },
      {
        title: 'Browser Security Settings',
        icon: CheckCircle2,
        content: [
          'Keep your browser updated to the latest version',
          'Enable pop-up blockers',
          'Disable auto-fill for sensitive information',
          'Use a password manager instead of browser password storage',
          'Enable "Do Not Track" requests',
          'Review and remove unused browser extensions',
          'Set your browser to clear data on exit'
        ]
      }
    ],
    tips: [
      'Use a VPN when on public Wi-Fi networks',
      'Bookmark important sites to avoid typosquatting',
      'Be cautious of shortened URLs - expand them first',
      'Regularly review your browser\'s saved passwords and remove old ones',
      'Use different browsers for different activities (work vs. personal)'
    ]
  },
  'social-media-privacy': {
    title: 'Social Media Privacy',
    description: 'Protect your personal information on social platforms and maintain your digital privacy.',
    sections: [
      {
        title: 'Privacy Settings and Controls',
        icon: CheckCircle2,
        content: [
          'Review privacy settings on all social media accounts',
          'Limit who can see your posts (friends only, not public)',
          'Control who can tag you in photos and posts',
          'Disable location tracking and geotagging',
          'Limit third-party app access to your profile',
          'Turn off facial recognition features',
          'Regularly audit your privacy settings (they change often!)'
        ]
      },
      {
        title: 'Oversharing Risks',
        icon: AlertTriangle,
        content: [
          'Don\'t share your full birthdate (use for identity verification)',
          'Avoid posting vacation plans in real-time (wait until you\'re back)',
          'Don\'t share photos of credit cards, IDs, or boarding passes',
          'Be cautious about sharing your location',
          'Avoid posting about expensive purchases',
          'Don\'t share personal phone numbers or addresses publicly',
          'Think before posting - it\'s permanent even if you delete it'
        ]
      },
      {
        title: 'Account Security',
        icon: Info,
        content: [
          'Use strong, unique passwords for each platform',
          'Enable two-factor authentication on all accounts',
          'Review login activity regularly',
          'Log out of accounts on shared devices',
          'Be cautious of friend requests from strangers',
          'Verify friend requests that seem suspicious (even from known contacts)',
          'Don\'t click suspicious links in messages, even from friends'
        ]
      },
      {
        title: 'Protecting Your Digital Footprint',
        icon: CheckCircle2,
        content: [
          'Google yourself regularly to see what\'s public',
          'Remove old, unused social media accounts',
          'Untag yourself from unwanted photos',
          'Request removal of personal information from data broker sites',
          'Be mindful of what you comment on public posts',
          'Use privacy-focused alternatives when possible',
          'Educate children about social media safety'
        ]
      }
    ],
    tips: [
      'Assume anything you post could become public',
      'Use profile pictures that don\'t reveal too much personal information',
      'Be skeptical of quizzes and games that request access to your profile',
      'Review tagged photos before they appear on your profile',
      'Consider using a pseudonym for public-facing accounts'
    ]
  },
  'mobile-security': {
    title: 'Mobile Device Security',
    description: 'Keep your smartphone and tablet secure with these essential security practices.',
    sections: [
      {
        title: 'Device Lock and Authentication',
        icon: CheckCircle2,
        content: [
          'Use a strong PIN, password, or pattern (not 1234 or 0000)',
          'Enable biometric authentication (fingerprint or face recognition)',
          'Set auto-lock to 30 seconds or 1 minute',
          'Never disable lock screen security',
          'Use different unlock methods for different security levels',
          'Enable "Find My Device" features',
          'Set up remote wipe capability'
        ]
      },
      {
        title: 'App Permissions and Security',
        icon: AlertTriangle,
        content: [
          'Review app permissions before installing',
          'Only grant necessary permissions (why does a flashlight need your contacts?)',
          'Download apps only from official stores (App Store, Google Play)',
          'Read app reviews and check developer reputation',
          'Keep apps updated to patch security vulnerabilities',
          'Uninstall apps you no longer use',
          'Be cautious of apps requesting admin privileges'
        ]
      },
      {
        title: 'Network and Connection Security',
        icon: Info,
        content: [
          'Avoid public Wi-Fi for sensitive transactions',
          'Use a VPN on public networks',
          'Turn off Wi-Fi and Bluetooth when not in use',
          'Forget Wi-Fi networks you no longer use',
          'Disable automatic Wi-Fi connection',
          'Be cautious of unknown Bluetooth pairing requests',
          'Use mobile data for banking and sensitive activities'
        ]
      },
      {
        title: 'Data Protection and Backup',
        icon: CheckCircle2,
        content: [
          'Enable automatic backups to cloud storage',
          'Encrypt your device storage',
          'Use secure messaging apps (Signal, WhatsApp)',
          'Regularly backup important data',
          'Enable "Erase Data" after failed unlock attempts',
          'Use secure folders for sensitive files',
          'Be cautious when charging at public USB ports (use power-only cables)'
        ]
      }
    ],
    tips: [
      'Keep your operating system updated',
      'Install mobile security software',
      'Be cautious of SMS phishing (smishing)',
      'Don\'t jailbreak or root your device (reduces security)',
      'Use separate devices for work and personal use if possible'
    ]
  }
};

export default function LearningResource() {
  const { resourceId } = useParams<{ resourceId: string }>();
  const { user } = useAuth();
  const resource = resourceId ? learningResources[resourceId as keyof typeof learningResources] : null;

  if (!resource) {
    return (
      <div className="min-h-screen bg-gradient-background">
        <header className="border-b border-border bg-card/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sidebar />
                <Link to="/">
                  <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <div className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-primary" />
                  <h1 className="text-xl font-bold text-foreground">CyberGuard AI</h1>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {user ? (
                  <UserMenu />
                ) : (
                  <Link to="/login">
                    <Button className="gap-2">Sign In</Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </header>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Resource Not Found</h1>
          <p className="text-muted-foreground mb-8">The learning resource you're looking for doesn't exist.</p>
          <Link to="/">
            <Button>Return Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <BookOpen className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Learning Resource</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold">{resource.title}</h1>
            <p className="text-lg text-muted-foreground">{resource.description}</p>
          </div>

          {resource.sections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <IconComponent className="h-5 w-5 text-primary" />
                    {section.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {section.content.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start gap-3">
                        <CheckCircle2 className="h-5 w-5 text-secondary mt-0.5 flex-shrink-0" />
                        <span className="text-foreground">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}

          <Card className="bg-secondary/10 border-secondary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-secondary" />
                Quick Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {resource.tips.map((tip, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="text-secondary font-bold flex-shrink-0">•</span>
                    <span className="text-foreground">{tip}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <div className="flex justify-center pt-4">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>Created by Jeeviraj V</p>
          <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
          <p className="mt-2">2025 CyberGuard AI</p>
        </div>
      </footer>
    </div>
  );
}
