import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Shield, Mail, Bell, AlertTriangle, CheckCircle, Clock, Copy, Trash2, Link as LinkIcon, Unlink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { userManager } from '@/lib/userManager';
import { api } from '@/db/api';

interface MonitoredEmail {
  id: string;
  user_id: string;
  sender: string;
  subject: string;
  content: string;
  risk_level: 'low' | 'medium' | 'high';
  analysis: string;
  created_at: string;
  is_read: boolean;
}

export default function EmailMonitor() {
  const [monitoringEmail, setMonitoringEmail] = useState('');
  const [isRegistered, setIsRegistered] = useState(false);
  const [emails, setEmails] = useState<MonitoredEmail[]>([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({ total: 0, high: 0, medium: 0, low: 0, unread: 0 });
  const [connectedEmails, setConnectedEmails] = useState<string[]>([]);
  const [showConnectDialog, setShowConnectDialog] = useState(false);
  const [emailToConnect, setEmailToConnect] = useState('');
  const [selectedProvider, setSelectedProvider] = useState<'gmail' | 'outlook' | 'yahoo' | null>(null);
  const { toast } = useToast();

  const MONITORING_ADDRESS = 'security@cyberguard.monitor';

  useEffect(() => {
    loadUserEmail();
    loadMonitoredEmails();
  }, []);

  const loadUserEmail = async () => {
    // Email registration is optional - users can forward emails directly
    setIsRegistered(true);
  };

  const loadMonitoredEmails = async () => {
    const userId = await userManager.getCurrentUserId();
    if (!userId) return;

    setLoading(true);
    try {
      const data = await api.monitoredEmails.getByUser(userId);
      setEmails(data);
      
      // Calculate stats
      const total = data.length;
      const high = data.filter(e => e.risk_level === 'high').length;
      const medium = data.filter(e => e.risk_level === 'medium').length;
      const low = data.filter(e => e.risk_level === 'low').length;
      const unread = data.filter(e => !e.is_read).length;
      
      setStats({ total, high, medium, low, unread });
    } catch (error) {
      console.error('Error loading monitored emails:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterEmail = async () => {
    if (!monitoringEmail || !monitoringEmail.includes('@')) {
      toast({
        title: 'Invalid Email',
        description: 'Please enter a valid email address',
        variant: 'destructive'
      });
      return;
    }

    setIsRegistered(true);
    
    toast({
      title: 'Email Noted!',
      description: 'You can now forward suspicious emails for analysis',
    });
  };

  const copyMonitoringAddress = () => {
    navigator.clipboard.writeText(MONITORING_ADDRESS);
    toast({
      title: 'Copied!',
      description: 'Monitoring address copied to clipboard',
    });
  };

  const handleConnectEmail = async () => {
    if (!emailToConnect || !emailToConnect.includes('@')) {
      toast({
        title: 'Invalid Email',
        description: 'Please enter a valid email address',
        variant: 'destructive'
      });
      return;
    }

    if (!selectedProvider) {
      toast({
        title: 'Select Provider',
        description: 'Please select your email provider',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      // Simulate OAuth connection process
      // In production, this would redirect to OAuth provider
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setConnectedEmails(prev => [...prev, emailToConnect]);
      setShowConnectDialog(false);
      setEmailToConnect('');
      setSelectedProvider(null);
      
      toast({
        title: 'Email Connected!',
        description: `${emailToConnect} is now connected for automatic monitoring`,
      });
    } catch (error) {
      console.error('Error connecting email:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect email account. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnectEmail = (email: string) => {
    setConnectedEmails(prev => prev.filter(e => e !== email));
    toast({
      title: 'Email Disconnected',
      description: `${email} has been disconnected`,
    });
  };

  const markAsRead = async (emailId: string) => {
    try {
      await api.monitoredEmails.markAsRead(emailId);
      setEmails(prev => prev.map(e => e.id === emailId ? { ...e, is_read: true } : e));
      setStats(prev => ({ ...prev, unread: Math.max(0, prev.unread - 1) }));
    } catch (error) {
      console.error('Error marking email as read:', error);
    }
  };

  const deleteEmail = async (emailId: string) => {
    try {
      await api.monitoredEmails.delete(emailId);
      setEmails(prev => prev.filter(e => e.id !== emailId));
      loadMonitoredEmails(); // Refresh stats
      
      toast({
        title: 'Deleted',
        description: 'Email removed from monitoring history',
      });
    } catch (error) {
      console.error('Error deleting email:', error);
      toast({
        title: 'Delete Failed',
        description: 'Failed to delete email',
        variant: 'destructive'
      });
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'high': return <AlertTriangle className="w-4 h-4" />;
      case 'medium': return <Clock className="w-4 h-4" />;
      case 'low': return <CheckCircle className="w-4 h-4" />;
      default: return <Shield className="w-4 h-4" />;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold">Email Phishing Monitor</h1>
        </div>
        <p className="text-muted-foreground">
          Automatic email analysis and phishing detection with real-time alerts
        </p>
      </div>

      <Tabs defaultValue="setup" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="setup">Setup</TabsTrigger>
          <TabsTrigger value="monitored">
            Monitored Emails
            {stats.unread > 0 && (
              <Badge variant="destructive" className="ml-2">{stats.unread}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        {/* Setup Tab */}
        <TabsContent value="setup" className="space-y-6">
          <Alert className="bg-primary/5 border-primary/20">
            <Mail className="w-5 h-5 text-primary" />
            <AlertDescription className="text-base">
              <strong className="text-primary">Quick Start:</strong> Copy the monitoring address below, 
              then forward any suspicious emails to it. You'll get instant AI-powered phishing analysis!
            </AlertDescription>
          </Alert>

          {/* Connect Email Account Card */}
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LinkIcon className="w-5 h-5 text-primary" />
                Connect Email Account (Automatic Monitoring)
              </CardTitle>
              <CardDescription>
                Connect your email account for automatic phishing detection on all incoming emails
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {connectedEmails.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Connected Accounts</Label>
                  {connectedEmails.map((email) => (
                    <div key={email} className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="font-medium">{email}</span>
                        <Badge variant="secondary" className="bg-green-100 text-green-700">Active</Badge>
                      </div>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => handleDisconnectEmail(email)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Unlink className="w-4 h-4 mr-1" />
                        Disconnect
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <Dialog open={showConnectDialog} onOpenChange={setShowConnectDialog}>
                <DialogTrigger asChild>
                  <Button size="lg" className="w-full" variant="default">
                    <LinkIcon className="w-5 h-5 mr-2" />
                    Connect Email Account
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Connect Email Account</DialogTitle>
                    <DialogDescription>
                      Connect your email account for automatic phishing detection
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="connect-email">Email Address</Label>
                      <Input
                        id="connect-email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={emailToConnect}
                        onChange={(e) => setEmailToConnect(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Select Email Provider</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Button
                          variant={selectedProvider === 'gmail' ? 'default' : 'outline'}
                          className="w-full"
                          onClick={() => setSelectedProvider('gmail')}
                        >
                          Gmail
                        </Button>
                        <Button
                          variant={selectedProvider === 'outlook' ? 'default' : 'outline'}
                          className="w-full"
                          onClick={() => setSelectedProvider('outlook')}
                        >
                          Outlook
                        </Button>
                        <Button
                          variant={selectedProvider === 'yahoo' ? 'default' : 'outline'}
                          className="w-full"
                          onClick={() => setSelectedProvider('yahoo')}
                        >
                          Yahoo
                        </Button>
                      </div>
                    </div>

                    <Alert>
                      <Shield className="w-4 h-4" />
                      <AlertDescription className="text-xs">
                        <strong>Secure Connection:</strong> We use OAuth 2.0 for secure authentication. 
                        Your password is never stored. You can disconnect anytime.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-2 text-xs text-muted-foreground">
                      <p><strong>What happens next:</strong></p>
                      <ol className="list-decimal list-inside space-y-1 ml-2">
                        <li>You'll be redirected to your email provider</li>
                        <li>Grant read-only access to CyberGuard</li>
                        <li>We'll automatically scan incoming emails</li>
                        <li>Get instant alerts for phishing threats</li>
                      </ol>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setShowConnectDialog(false);
                        setEmailToConnect('');
                        setSelectedProvider(null);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="flex-1"
                      onClick={handleConnectEmail}
                      disabled={loading || !emailToConnect || !selectedProvider}
                    >
                      {loading ? 'Connecting...' : 'Connect Account'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <div className="text-sm text-muted-foreground space-y-2">
                <p><strong>Benefits of connecting your email:</strong></p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Automatic scanning of all incoming emails</li>
                  <li>Real-time phishing detection</li>
                  <li>Instant alerts for dangerous emails</li>
                  <li>No need to manually forward emails</li>
                  <li>Complete protection 24/7</li>
                </ul>
              </div>

              <Alert className="bg-muted">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription className="text-xs">
                  <strong>Privacy Note:</strong> We only read email metadata (sender, subject) and analyze 
                  content for phishing indicators. We never store your emails or share data with third parties.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Register Your Email
              </CardTitle>
              <CardDescription>
                Register your email address to enable automatic phishing detection
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Your Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={monitoringEmail}
                  onChange={(e) => setMonitoringEmail(e.target.value)}
                  disabled={isRegistered}
                />
              </div>

              {!isRegistered ? (
                <Button onClick={handleRegisterEmail} disabled={loading}>
                  {loading ? 'Registering...' : 'Register Email'}
                </Button>
              ) : (
                <Alert>
                  <CheckCircle className="w-4 h-4" />
                  <AlertDescription>
                    Your email is registered and monitoring is active!
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                How Email Monitoring Works
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Forward Suspicious Emails</h4>
                    <p className="text-sm text-muted-foreground">
                      When you receive a suspicious email, forward it to our monitoring address
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Automatic Analysis</h4>
                    <p className="text-sm text-muted-foreground">
                      Our AI instantly analyzes the email for phishing indicators
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Instant Alert</h4>
                    <p className="text-sm text-muted-foreground">
                      You receive an immediate notification with risk level and recommendations
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-muted rounded-lg">
                <Label className="text-sm font-semibold mb-2 block">📧 Your Monitoring Address</Label>
                <div className="flex items-center gap-2">
                  <code className="flex-1 p-3 bg-background rounded border text-base font-mono font-bold">
                    {MONITORING_ADDRESS}
                  </code>
                  <Button size="sm" variant="outline" onClick={copyMonitoringAddress}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  <strong>How to use:</strong> When you receive a suspicious email, click "Forward" in your email client, 
                  paste this address in the "To" field, and send. The email will be analyzed instantly!
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Start Guide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2 text-sm">
                <p className="font-semibold">To monitor an email:</p>
                <ol className="list-decimal list-inside space-y-1 text-muted-foreground ml-2">
                  <li>Open the suspicious email in your email client</li>
                  <li>Click "Forward" or use the forward button</li>
                  <li>Enter the monitoring address: <code className="text-xs bg-muted px-1 py-0.5 rounded">{MONITORING_ADDRESS}</code></li>
                  <li>Send the email</li>
                  <li>Check the "Monitored Emails" tab for instant analysis</li>
                </ol>
              </div>

              <Alert>
                <Shield className="w-4 h-4" />
                <AlertDescription>
                  <strong>Privacy Note:</strong> We only analyze emails you forward to us. 
                  We do not access your inbox or read your other emails.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Monitored Emails Tab */}
        <TabsContent value="monitored" className="space-y-4">
          {loading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Loading monitored emails...</p>
              </CardContent>
            </Card>
          ) : emails.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Mail className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No Monitored Emails Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Forward suspicious emails to start monitoring
                </p>
                <Button variant="outline" onClick={() => copyMonitoringAddress()}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Monitoring Address
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {emails.map((email) => (
                <Card key={email.id} className={!email.is_read ? 'border-primary' : ''}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={getRiskColor(email.risk_level)} className="flex items-center gap-1">
                            {getRiskIcon(email.risk_level)}
                            {email.risk_level.toUpperCase()} RISK
                          </Badge>
                          {!email.is_read && (
                            <Badge variant="outline">New</Badge>
                          )}
                        </div>
                        <CardTitle className="text-lg">{email.subject || 'No Subject'}</CardTitle>
                        <CardDescription>
                          From: {email.sender} • {new Date(email.created_at).toLocaleString()}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        {!email.is_read && (
                          <Button size="sm" variant="outline" onClick={() => markAsRead(email.id)}>
                            Mark Read
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => deleteEmail(email.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm font-semibold">Analysis</Label>
                      <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">
                        {email.analysis}
                      </p>
                    </div>
                    
                    <details className="text-sm">
                      <summary className="cursor-pointer font-semibold text-muted-foreground hover:text-foreground">
                        View Email Content
                      </summary>
                      <div className="mt-2 p-3 bg-muted rounded text-xs whitespace-pre-wrap max-h-48 overflow-y-auto">
                        {email.content}
                      </div>
                    </details>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Alerts Tab */}
        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Alert Settings
              </CardTitle>
              <CardDescription>
                Configure how you want to be notified about phishing threats
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>
                  <strong>High Risk Emails:</strong> You will receive immediate in-app notifications 
                  for all high-risk phishing attempts detected.
                </AlertDescription>
              </Alert>

              <Alert>
                <Clock className="w-4 h-4" />
                <AlertDescription>
                  <strong>Medium Risk Emails:</strong> These will appear in your monitored emails 
                  list with a warning badge.
                </AlertDescription>
              </Alert>

              <Alert>
                <CheckCircle className="w-4 h-4" />
                <AlertDescription>
                  <strong>Low Risk Emails:</strong> These are logged for your review but 
                  considered relatively safe.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              {emails.filter(e => e.risk_level === 'high').length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No high-risk alerts. Your emails are safe!
                </p>
              ) : (
                <div className="space-y-3">
                  {emails.filter(e => e.risk_level === 'high').slice(0, 5).map((email) => (
                    <div key={email.id} className="flex items-start gap-3 p-3 bg-destructive/10 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-semibold text-sm">{email.subject || 'No Subject'}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(email.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="stats" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Monitored
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground mt-1">All time</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  High Risk
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-destructive">{stats.high}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.total > 0 ? Math.round((stats.high / stats.total) * 100) : 0}% of total
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Medium Risk
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">{stats.medium}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.total > 0 ? Math.round((stats.medium / stats.total) * 100) : 0}% of total
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Unread Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">{stats.unread}</div>
                <p className="text-xs text-muted-foreground mt-1">Needs attention</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Protection Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">High Risk</span>
                  <span className="text-sm text-muted-foreground">{stats.high} emails</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-destructive h-2 rounded-full transition-all"
                    style={{ width: `${stats.total > 0 ? (stats.high / stats.total) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Medium Risk</span>
                  <span className="text-sm text-muted-foreground">{stats.medium} emails</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-orange-500 h-2 rounded-full transition-all"
                    style={{ width: `${stats.total > 0 ? (stats.medium / stats.total) * 100 : 0}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Low Risk</span>
                  <span className="text-sm text-muted-foreground">{stats.low} emails</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all"
                    style={{ width: `${stats.total > 0 ? (stats.low / stats.total) * 100 : 0}%` }}
                  />
                </div>
              </div>

              {stats.total > 0 && (
                <Alert>
                  <Shield className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Protection Status:</strong> You've analyzed {stats.total} emails. 
                    {stats.high > 0 ? ` ${stats.high} dangerous phishing attempts were blocked!` : ' No phishing attempts detected. Stay vigilant!'}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
