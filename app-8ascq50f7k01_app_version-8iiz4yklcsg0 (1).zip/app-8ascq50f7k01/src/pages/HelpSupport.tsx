import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, ArrowLeft, HelpCircle, Mail, MessageCircle, Book, Video, FileText, ExternalLink } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const faqs = [
  {
    question: 'How do I use the Phishing Detector?',
    answer: 'The Phishing Detector analyzes suspicious emails, messages, and URLs. Simply paste the content or URL into the detector, and our AI will analyze it for phishing indicators. You\'ll receive a risk assessment and detailed explanation of any suspicious elements found.'
  },
  {
    question: 'Is my data secure when using CyberGuard AI?',
    answer: 'Yes! We take your privacy seriously. All conversations are encrypted, and we don\'t store sensitive information you share during phishing detection. Your personal data is protected with industry-standard security measures, and you have full control over your account data.'
  },
  {
    question: 'How accurate is the phishing detection?',
    answer: 'Our AI-powered phishing detector uses advanced language models trained on millions of phishing examples. While highly accurate, no system is perfect. We recommend using the detector as one tool in your security toolkit and always exercising caution with suspicious messages.'
  },
  {
    question: 'Can I use CyberGuard AI on my mobile device?',
    answer: 'Absolutely! CyberGuard AI is fully responsive and works on smartphones, tablets, and desktop computers. Simply access it through your mobile browser for the same great experience on any device.'
  },
  {
    question: 'How do I create a strong password?',
    answer: 'Use our Password Checker tool in the Security Tools section! Generally, strong passwords should be at least 12 characters long, include uppercase and lowercase letters, numbers, and symbols. Avoid dictionary words and personal information. Consider using a password manager to generate and store complex passwords.'
  },
  {
    question: 'What should I do if I clicked a phishing link?',
    answer: 'Act quickly: 1) Disconnect from the internet, 2) Change your passwords on a different device, 3) Run a security scan, 4) Monitor your accounts for suspicious activity, 5) Enable two-factor authentication, 6) Report the incident to relevant authorities. If you entered financial information, contact your bank immediately.'
  },
  {
    question: 'How often should I change my passwords?',
    answer: 'Change passwords every 3-6 months for critical accounts (banking, email). Change immediately if you suspect a breach or if a service you use reports a data breach. Use unique passwords for each account and enable two-factor authentication wherever possible.'
  },
  {
    question: 'Is CyberGuard AI free to use?',
    answer: 'Yes! CyberGuard AI is completely free for college students. All features including the AI chatbot, phishing detector, security tools, and learning resources are available at no cost. Our mission is to make cybersecurity education accessible to everyone.'
  },
  {
    question: 'Can I save my chat conversations?',
    answer: 'Yes! Your chat conversations are automatically saved to your account. You can access your chat history anytime by logging in. You can also export or delete conversations from your account settings.'
  },
  {
    question: 'How do I report a bug or suggest a feature?',
    answer: 'We love hearing from you! Visit our Feedback page to report bugs, suggest features, or share general feedback. You can also rate your experience. We review all submissions and use your input to improve CyberGuard AI.'
  }
];

const resources = [
  {
    title: 'Getting Started Guide',
    description: 'Learn the basics of using CyberGuard AI',
    icon: Book,
    link: '#'
  },
  {
    title: 'Video Tutorials',
    description: 'Watch step-by-step video guides',
    icon: Video,
    link: '#'
  },
  {
    title: 'Documentation',
    description: 'Detailed documentation for all features',
    icon: FileText,
    link: '#'
  },
  {
    title: 'Community Forum',
    description: 'Connect with other users and get help',
    icon: MessageCircle,
    link: '#'
  }
];

export default function HelpSupport() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <HelpCircle className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Help & Support</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold">How Can We Help You?</h1>
            <p className="text-lg text-muted-foreground">
              Find answers to common questions and get support
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="cursor-pointer hover:border-primary transition-colors">
              <Link to="/feedback">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5 text-primary" />
                    Send Feedback
                  </CardTitle>
                  <CardDescription>
                    Share your thoughts or report issues
                  </CardDescription>
                </CardHeader>
              </Link>
            </Card>

            <Card className="cursor-pointer hover:border-primary transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5 text-primary" />
                  Contact Support
                </CardTitle>
                <CardDescription>
                  Get help from our support team
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Email: support@cyberguard-ai.com
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>
                Quick answers to common questions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Learning Resources</CardTitle>
              <CardDescription>
                Explore guides and tutorials
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {resources.map((resource, index) => {
                  const IconComponent = resource.icon;
                  return (
                    <div
                      key={index}
                      className="flex items-start gap-3 p-4 rounded-lg border border-border hover:border-primary transition-colors cursor-pointer"
                    >
                      <IconComponent className="h-5 w-5 text-primary mt-0.5" />
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm mb-1">{resource.title}</h4>
                        <p className="text-xs text-muted-foreground">{resource.description}</p>
                      </div>
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>About CyberGuard AI</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                CyberGuard AI is an intelligent cybersecurity assistant designed specifically for college
                students. Our mission is to enhance cybersecurity awareness and provide real-time protection
                against online threats, particularly phishing attacks.
              </p>
              <div className="space-y-2">
                <h4 className="font-semibold">Key Features:</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>AI-powered phishing detection</li>
                  <li>Interactive cybersecurity chatbot</li>
                  <li>Comprehensive security tools</li>
                  <li>Educational resources and quizzes</li>
                  <li>Real-time threat analysis</li>
                </ul>
              </div>
              <div className="pt-4 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  <strong>Created by:</strong> Jeeviraj V
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Institution:</strong> Sri Shakthi Institute of Engineering and Technology, Coimbatore
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  <strong>Version:</strong> 1.0.0
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary/10 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Need More Help?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Can't find what you're looking for? Our support team is here to help!
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/feedback" className="flex-1">
                  <Button className="w-full">
                    Send Feedback
                  </Button>
                </Link>
                <Button variant="outline" className="flex-1">
                  Email Support
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center pt-4">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>Created by Jeeviraj V</p>
          <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
          <p className="mt-2">2025 CyberGuard AI</p>
        </div>
      </footer>
    </div>
  );
}
