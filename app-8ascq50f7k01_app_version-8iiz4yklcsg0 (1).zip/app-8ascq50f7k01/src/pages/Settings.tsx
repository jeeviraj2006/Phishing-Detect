import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Shield, ArrowLeft, Bell, Lock, Eye, Globe, Palette, Moon, Sun, User, GraduationCap, Info } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    notifications: true,
    emailAlerts: true,
    securityAlerts: true,
    darkMode: false,
    autoSave: true,
    twoFactor: false,
    sessionTimeout: true,
    dataCollection: false
  });

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
    toast({
      title: 'Settings Updated',
      description: 'Your preferences have been saved successfully.',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Settings</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold">Settings</h1>
            <p className="text-lg text-muted-foreground">Manage your preferences and account settings</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Notifications
              </CardTitle>
              <CardDescription>
                Configure how you receive alerts and updates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="notifications">Push Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive notifications about security alerts</p>
                </div>
                <Switch
                  id="notifications"
                  checked={settings.notifications}
                  onCheckedChange={() => handleToggle('notifications')}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailAlerts">Email Alerts</Label>
                  <p className="text-sm text-muted-foreground">Get security updates via email</p>
                </div>
                <Switch
                  id="emailAlerts"
                  checked={settings.emailAlerts}
                  onCheckedChange={() => handleToggle('emailAlerts')}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="securityAlerts">Security Alerts</Label>
                  <p className="text-sm text-muted-foreground">Immediate alerts for critical security issues</p>
                </div>
                <Switch
                  id="securityAlerts"
                  checked={settings.securityAlerts}
                  onCheckedChange={() => handleToggle('securityAlerts')}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Security & Privacy
              </CardTitle>
              <CardDescription>
                Manage your security preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="twoFactor">Two-Factor Authentication</Label>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                </div>
                <Switch
                  id="twoFactor"
                  checked={settings.twoFactor}
                  onCheckedChange={() => handleToggle('twoFactor')}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="sessionTimeout">Auto Session Timeout</Label>
                  <p className="text-sm text-muted-foreground">Automatically log out after 30 minutes of inactivity</p>
                </div>
                <Switch
                  id="sessionTimeout"
                  checked={settings.sessionTimeout}
                  onCheckedChange={() => handleToggle('sessionTimeout')}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dataCollection">Data Collection</Label>
                  <p className="text-sm text-muted-foreground">Allow anonymous usage data to improve the service</p>
                </div>
                <Switch
                  id="dataCollection"
                  checked={settings.dataCollection}
                  onCheckedChange={() => handleToggle('dataCollection')}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Appearance
              </CardTitle>
              <CardDescription>
                Customize how CyberGuard AI looks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="darkMode">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                </div>
                <Switch
                  id="darkMode"
                  checked={settings.darkMode}
                  onCheckedChange={() => handleToggle('darkMode')}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="autoSave">Auto-Save Chat History</Label>
                  <p className="text-sm text-muted-foreground">Automatically save your conversations</p>
                </div>
                <Switch
                  id="autoSave"
                  checked={settings.autoSave}
                  onCheckedChange={() => handleToggle('autoSave')}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                About
              </CardTitle>
              <CardDescription>
                Information about CyberGuard AI and its creator
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <User className="h-5 w-5 text-primary mt-0.5" />
                  <div className="space-y-1">
                    <Label className="text-base font-semibold">Created By</Label>
                    <p className="text-sm text-foreground font-medium">Jeeviraj V</p>
                    <p className="text-xs text-muted-foreground">Founder & Developer</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <GraduationCap className="h-5 w-5 text-primary mt-0.5" />
                  <div className="space-y-1">
                    <Label className="text-base font-semibold">Institution</Label>
                    <p className="text-sm text-foreground font-medium">Sri Shakthi Institute of Engineering and Technology</p>
                    <p className="text-xs text-muted-foreground">Coimbatore, Tamil Nadu, India</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <Shield className="h-5 w-5 text-primary mt-0.5" />
                  <div className="space-y-1">
                    <Label className="text-base font-semibold">About CyberGuard AI</Label>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      An intelligent chatbot assistant designed to enhance cybersecurity awareness among college students. 
                      Powered by advanced AI technology to provide real-time phishing detection, security education, 
                      and personalized guidance for staying safe online.
                    </p>
                  </div>
                </div>

                <div className="pt-2 text-center">
                  <p className="text-xs text-muted-foreground">Version 1.0.0 • 2025 CyberGuard AI</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive/50">
            <CardHeader>
              <CardTitle className="text-destructive">Danger Zone</CardTitle>
              <CardDescription>
                Irreversible actions - proceed with caution
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full">
                Clear All Chat History
              </Button>
              <Button variant="outline" className="w-full">
                Reset All Settings to Default
              </Button>
              <Button variant="destructive" className="w-full">
                Delete Account
              </Button>
            </CardContent>
          </Card>

          <div className="flex justify-center pt-4">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>Created by Jeeviraj V</p>
          <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
          <p className="mt-2">2025 CyberGuard AI</p>
        </div>
      </footer>
    </div>
  );
}
