import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChatInterface } from '@/components/chat/ChatInterface';
import { PhishingDetector } from '@/components/phishing/PhishingDetector';
import { SecurityTips } from '@/components/education/SecurityTips';
import { QuizCard } from '@/components/education/QuizCard';
import { ResourcesCard } from '@/components/education/ResourcesCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Shield, MessageSquare, GraduationCap, Wrench, ArrowRight } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';

export default function Home() {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-primary">
                <Shield className="h-7 w-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">CyberGuard AI</h1>
                <p className="text-sm text-muted-foreground">Your Personal Cybersecurity Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/phishing">
                <Button variant="default" className="gap-2">
                  <Shield className="h-4 w-4" />
                  Phishing Detection
                </Button>
              </Link>
              <Link to="/tools">
                <Button variant="outline" className="gap-2">
                  <Wrench className="h-4 w-4" />
                  Security Tools
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid gap-6 xl:grid-cols-[400px_1fr]">
          <div className="space-y-6">
            <Tabs defaultValue="phishing" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="phishing" className="text-xs">
                  <Shield className="mr-1 h-3 w-3" />
                  Detect
                </TabsTrigger>
                <TabsTrigger value="learn" className="text-xs">
                  <GraduationCap className="mr-1 h-3 w-3" />
                  Learn
                </TabsTrigger>
                <TabsTrigger value="quiz" className="text-xs">
                  <MessageSquare className="mr-1 h-3 w-3" />
                  Quiz
                </TabsTrigger>
              </TabsList>
              <TabsContent value="phishing" className="mt-4">
                <PhishingDetector />
              </TabsContent>
              <TabsContent value="learn" className="mt-4 space-y-4">
                <SecurityTips />
                <ResourcesCard />
              </TabsContent>
              <TabsContent value="quiz" className="mt-4">
                <QuizCard />
              </TabsContent>
            </Tabs>
          </div>

          <div className="h-[calc(100vh-180px)]">
            <ChatInterface
              sessionId={currentSessionId}
              onSessionCreated={setCurrentSessionId}
            />
          </div>
        </div>
      </main>

      <footer className="border-t border-border bg-card/50 py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            2025 CyberGuard AI
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Empowering students with cybersecurity knowledge and protection
          </p>
          <p className="text-xs mt-2">Created by Jeeviraj V</p>
          <p className="text-xs">Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
        </div>
      </footer>
    </div>
  );
}
