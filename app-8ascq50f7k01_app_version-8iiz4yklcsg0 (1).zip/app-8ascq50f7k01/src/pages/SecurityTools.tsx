import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { PasswordChecker } from '@/components/security/PasswordChecker';
import { LinkChecker } from '@/components/security/LinkChecker';
import { SecurityScore } from '@/components/security/SecurityScore';
import { SecurityNews } from '@/components/security/SecurityNews';
import { TwoFactorGuide } from '@/components/security/TwoFactorGuide';
import { BreachChecker } from '@/components/security/BreachChecker';
import { IncidentReporter } from '@/components/security/IncidentReporter';
import { SecurityChecklist } from '@/components/security/SecurityChecklist';
import { ThreatSimulator } from '@/components/security/ThreatSimulator';
import { SecurityGlossary } from '@/components/security/SecurityGlossary';
import { EmailHeaderAnalyzer } from '@/components/security/EmailHeaderAnalyzer';
import { DeviceSecurityScanner } from '@/components/security/DeviceSecurityScanner';
import { Shield, Lock, Link2, Trophy, Newspaper, Smartphone, Database, AlertCircle, ClipboardCheck, Target, BookOpen, Mail, Scan, Home, ArrowLeft } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';

export default function SecurityTools() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Security Tools Suite</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Comprehensive cybersecurity tools to protect yourself online. Check passwords, analyze threats, 
              track your progress, and learn security best practices.
            </p>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-7 h-auto gap-1">
              <TabsTrigger value="all" className="gap-2">
                <Shield className="h-4 w-4" />
                <span className="hidden sm:inline">All Tools</span>
                <span className="sm:hidden">All</span>
              </TabsTrigger>
              <TabsTrigger value="checkers" className="gap-2">
                <Scan className="h-4 w-4" />
                <span className="hidden sm:inline">Checkers</span>
                <span className="sm:hidden">Check</span>
              </TabsTrigger>
              <TabsTrigger value="analyzers" className="gap-2">
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">Analyzers</span>
                <span className="sm:hidden">Analyze</span>
              </TabsTrigger>
              <TabsTrigger value="learning" className="gap-2">
                <BookOpen className="h-4 w-4" />
                <span className="hidden sm:inline">Learning</span>
                <span className="sm:hidden">Learn</span>
              </TabsTrigger>
              <TabsTrigger value="tracking" className="gap-2">
                <Trophy className="h-4 w-4" />
                <span className="hidden sm:inline">Tracking</span>
                <span className="sm:hidden">Track</span>
              </TabsTrigger>
              <TabsTrigger value="guides" className="gap-2">
                <Smartphone className="h-4 w-4" />
                <span className="hidden sm:inline">Guides</span>
                <span className="sm:hidden">Guide</span>
              </TabsTrigger>
              <TabsTrigger value="report" className="gap-2">
                <AlertCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Report</span>
                <span className="sm:hidden">Report</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <PasswordChecker />
                <LinkChecker />
                <BreachChecker />
                <EmailHeaderAnalyzer />
                <DeviceSecurityScanner />
                <ThreatSimulator />
                <SecurityChecklist />
                <SecurityScore />
                <SecurityNews />
                <SecurityGlossary />
                <TwoFactorGuide />
                <IncidentReporter />
              </div>
            </TabsContent>

            <TabsContent value="checkers" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <PasswordChecker />
                <LinkChecker />
                <BreachChecker />
                <DeviceSecurityScanner />
              </div>
            </TabsContent>

            <TabsContent value="analyzers" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <EmailHeaderAnalyzer />
                <ThreatSimulator />
              </div>
            </TabsContent>

            <TabsContent value="learning" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <SecurityGlossary />
                <SecurityNews />
                <ThreatSimulator />
              </div>
            </TabsContent>

            <TabsContent value="tracking" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <SecurityScore />
                <SecurityChecklist />
              </div>
            </TabsContent>

            <TabsContent value="guides" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <TwoFactorGuide />
                <DeviceSecurityScanner />
              </div>
            </TabsContent>

            <TabsContent value="report" className="mt-6">
              <div className="max-w-2xl mx-auto">
                <IncidentReporter />
              </div>
            </TabsContent>
          </Tabs>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-6 text-center">
            <h3 className="text-lg font-semibold mb-2">🛡️ Stay Secure, Stay Informed</h3>
            <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
              Use these tools regularly to maintain strong cybersecurity practices. 
              Remember: security is an ongoing process, not a one-time task.
            </p>
          </div>
        </div>
      </div>
      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">

      </footer>
    </div>
  );
}
