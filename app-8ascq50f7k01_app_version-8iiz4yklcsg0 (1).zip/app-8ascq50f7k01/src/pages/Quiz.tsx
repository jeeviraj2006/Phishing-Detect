import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, Lock, CheckCircle2, Trophy, ChevronRight } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { QuizLevel, QuizModule, UserQuizProgress, UserBadge } from '@/types/types';

export default function Quiz() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [levels, setLevels] = useState<QuizLevel[]>([]);
  const [levelModules, setLevelModules] = useState<Map<number, QuizModule[]>>(new Map());
  const [progress, setProgress] = useState<UserQuizProgress[]>([]);
  const [badges, setBadges] = useState<UserBadge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const levelsData = await api.quiz.getLevels();
    setLevels(levelsData);

    const userId = await userManager.getCurrentUserId();
    const progressData = await api.quiz.getUserProgress(userId);
    const badgesData = await api.quiz.getUserBadges(userId);
    setProgress(progressData);
    setBadges(badgesData);

    // Load modules for all levels to calculate progress
    const modulesMap = new Map<number, QuizModule[]>();
    for (const level of levelsData) {
      const modules = await api.quiz.getModulesByLevel(level.id);
      modulesMap.set(level.id, modules);
    }
    setLevelModules(modulesMap);

    setLoading(false);
  };

  const isLevelUnlocked = (levelId: number) => {
    if (levelId === 1) return true;
    const previousLevel = levelId - 1;
    return hasBadge(previousLevel);
  };

  const hasBadge = (levelId: number) => {
    return badges.some(badge => badge.level_id === levelId);
  };

  const getModuleProgress = (moduleId: string) => {
    return progress.find(p => p.module_id === moduleId);
  };

  const getLevelProgress = (levelId: number) => {
    const modules = levelModules.get(levelId) || [];
    if (modules.length === 0) return 0;
    const completedModules = modules.filter(m => {
      const prog = getModuleProgress(m.id);
      return prog?.completed;
    }).length;
    return (completedModules / modules.length) * 100;
  };

  const handleLevelClick = (levelId: number) => {
    if (!isLevelUnlocked(levelId)) {
      return;
    }
    navigate(`/quiz/level/${levelId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-12 w-12 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading quiz levels...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                <Shield className="h-6 w-6 text-primary" />
                <span className="font-bold text-xl">CyberGuard AI</span>
              </Link>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="space-y-6">
          {/* Page Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold">Cybersecurity Quiz</h1>
            <p className="text-lg text-muted-foreground">
              Choose a level to start learning. Complete all modules to earn badges!
            </p>
          </div>

          {/* Badges Section */}
          {badges.length > 0 && (
            <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Trophy className="h-5 w-5 text-primary" />
                  <h2 className="text-lg font-semibold">Your Badges</h2>
                </div>
                <div className="flex flex-wrap gap-3">
                  {badges.map(badge => {
                    const level = levels.find(l => l.id === badge.level_id);
                    return (
                      <Badge key={badge.id} variant="default" className="text-sm py-2 px-3 gap-2">
                        <span className="text-lg">{level?.badge_icon}</span>
                        {level?.badge_name}
                      </Badge>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Levels Grid */}
          <div className="grid gap-4 md:grid-cols-2">
            {levels.map(level => {
              const unlocked = isLevelUnlocked(level.id);
              const earned = hasBadge(level.id);
              const levelProgress = getLevelProgress(level.id);

              return (
                <Card 
                  key={level.id} 
                  className={`${!unlocked ? 'opacity-60' : 'hover:shadow-lg'} transition-all cursor-pointer`}
                  onClick={() => handleLevelClick(level.id)}
                >
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {/* Level Icon and Title */}
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-4xl">{level.badge_icon}</span>
                          <div>
                            <h3 className="font-bold text-lg">Level {level.id}</h3>
                            <p className="text-sm text-muted-foreground">{level.title}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          {earned && (
                            <Badge variant="default" className="gap-1">
                              <CheckCircle2 className="h-3 w-3" />
                              Earned
                            </Badge>
                          )}
                          {!unlocked && (
                            <Badge variant="secondary" className="gap-1">
                              <Lock className="h-3 w-3" />
                              Locked
                            </Badge>
                          )}
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {level.description}
                      </p>

                      {/* Stats */}
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>7 modules • 70 questions</span>
                        {levelProgress > 0 && (
                          <span className="font-medium text-primary">
                            {Math.round(levelProgress)}% complete
                          </span>
                        )}
                      </div>

                      {/* Progress Bar */}
                      {unlocked && levelProgress > 0 && (
                        <Progress value={levelProgress} className="h-2" />
                      )}

                      {/* Action Button */}
                      {unlocked && (
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-sm font-medium text-primary">
                            {levelProgress === 100 ? 'Review' : levelProgress > 0 ? 'Continue' : 'Start'}
                          </span>
                          <ChevronRight className="h-5 w-5 text-primary" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Instructions */}
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                How It Works
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>Click on a level to view its modules</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>Complete all 7 modules in a level to earn the badge and unlock the next level</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>Each module contains 10 questions covering important cybersecurity topics</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>You need 70% or higher to pass a module</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>You can retake any module to improve your score</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
