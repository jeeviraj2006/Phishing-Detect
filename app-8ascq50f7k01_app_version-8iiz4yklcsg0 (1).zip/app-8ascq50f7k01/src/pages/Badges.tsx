import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, Trophy, Lock, CheckCircle2, Star, ArrowRight } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { QuizLevel, QuizModule, UserQuizProgress, UserBadge } from '@/types/types';

export default function Badges() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [levels, setLevels] = useState<QuizLevel[]>([]);
  const [levelModules, setLevelModules] = useState<Map<number, QuizModule[]>>(new Map());
  const [progress, setProgress] = useState<UserQuizProgress[]>([]);
  const [badges, setBadges] = useState<UserBadge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const levelsData = await api.quiz.getLevels();
    setLevels(levelsData);

    const userId = await userManager.getCurrentUserId();
    const progressData = await api.quiz.getUserProgress(userId);
    const badgesData = await api.quiz.getUserBadges(userId);
    setProgress(progressData);
    setBadges(badgesData);

    // Load modules for progress calculation
    const modulesMap = new Map<number, QuizModule[]>();
    for (const level of levelsData) {
      const modules = await api.quiz.getModulesByLevel(level.id);
      modulesMap.set(level.id, modules);
    }
    setLevelModules(modulesMap);

    setLoading(false);
  };

  const hasBadge = (levelId: number) => {
    return badges.some(badge => badge.level_id === levelId);
  };

  const getBadgeEarnedDate = (levelId: number) => {
    const badge = badges.find(b => b.level_id === levelId);
    if (!badge) return null;
    return new Date(badge.earned_at).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getModuleProgress = (moduleId: string) => {
    return progress.find(p => p.module_id === moduleId);
  };

  const getLevelProgress = (levelId: number) => {
    const modules = levelModules.get(levelId) || [];
    if (modules.length === 0) return 0;
    const completedModules = modules.filter(m => {
      const prog = getModuleProgress(m.id);
      return prog?.completed;
    }).length;
    return (completedModules / modules.length) * 100;
  };

  const getTotalProgress = () => {
    if (levels.length === 0) return 0;
    return (badges.length / levels.length) * 100;
  };

  const handleStartLevel = (levelId: number) => {
    navigate(`/quiz/level/${levelId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <div className="text-center">
          <Trophy className="h-12 w-12 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading your badges...</p>
        </div>
      </div>
    );
  }

  const earnedBadges = badges.length;
  const totalBadges = levels.length;
  const totalProgress = getTotalProgress();

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Sidebar />
            <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Shield className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl">CyberGuard AI</span>
            </Link>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="space-y-8">
          {/* Page Header */}
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-3">
              <Trophy className="h-10 w-10 text-primary" />
              <h1 className="text-4xl font-bold">Your Badge Collection</h1>
            </div>
            <p className="text-lg text-muted-foreground">
              Earn badges by completing all modules in each level
            </p>
          </div>

          {/* Overall Progress Card */}
          <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold">
                      {earnedBadges} / {totalBadges} Badges Earned
                    </h2>
                    <p className="text-muted-foreground">
                      {earnedBadges === totalBadges
                        ? '🎉 Congratulations! You earned all badges!'
                        : `${totalBadges - earnedBadges} more to go!`}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-4xl font-bold text-primary">{Math.round(totalProgress)}%</div>
                    <p className="text-sm text-muted-foreground">Complete</p>
                  </div>
                </div>
                <Progress value={totalProgress} className="h-3" />
              </div>
            </CardContent>
          </Card>

          {/* Badges Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">All Badges</h2>
              <Link to="/quiz">
                <Button variant="outline" className="gap-2">
                  Go to Quiz
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {levels.map(level => {
                const earned = hasBadge(level.id);
                const earnedDate = getBadgeEarnedDate(level.id);
                const levelProgress = getLevelProgress(level.id);

                return (
                  <Card
                    key={level.id}
                    className={`${
                      earned
                        ? 'bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/30'
                        : 'opacity-70'
                    } transition-all hover:shadow-lg`}
                  >
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {/* Badge Icon and Status */}
                        <div className="flex items-start justify-between">
                          <div className="relative">
                            <div
                              className={`text-6xl ${
                                !earned ? 'grayscale opacity-50' : ''
                              } transition-all`}
                            >
                              {level.badge_icon}
                            </div>
                            {earned && (
                              <div className="absolute -top-2 -right-2 bg-primary rounded-full p-1">
                                <CheckCircle2 className="h-5 w-5 text-primary-foreground" />
                              </div>
                            )}
                            {!earned && (
                              <div className="absolute -top-2 -right-2 bg-muted rounded-full p-1">
                                <Lock className="h-5 w-5 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          {earned && (
                            <Badge variant="default" className="gap-1">
                              <Star className="h-3 w-3" />
                              Earned
                            </Badge>
                          )}
                        </div>

                        {/* Badge Info */}
                        <div>
                          <h3 className="font-bold text-lg mb-1">{level.badge_name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">
                            Level {level.id} - {level.title}
                          </p>
                          {earned && earnedDate && (
                            <p className="text-xs text-primary font-medium">
                              Earned on {earnedDate}
                            </p>
                          )}
                        </div>

                        {/* Progress or Action */}
                        {earned ? (
                          <div className="pt-3 border-t">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Status</span>
                              <span className="font-medium text-primary">Completed ✓</span>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>Progress</span>
                              <span className="font-medium">{Math.round(levelProgress)}%</span>
                            </div>
                            <Progress value={levelProgress} className="h-2" />
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full mt-2"
                              onClick={() => handleStartLevel(level.id)}
                            >
                              {levelProgress > 0 ? 'Continue' : 'Start Level'}
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Achievement Tiers */}
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                Achievement Tiers
              </h3>
              <div className="grid gap-3 md:grid-cols-4">
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl mb-1">🥉</div>
                  <div className="font-medium text-sm">Beginner</div>
                  <div className="text-xs text-muted-foreground">1-2 badges</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl mb-1">🥈</div>
                  <div className="font-medium text-sm">Intermediate</div>
                  <div className="text-xs text-muted-foreground">3-5 badges</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl mb-1">🥇</div>
                  <div className="font-medium text-sm">Advanced</div>
                  <div className="text-xs text-muted-foreground">6-7 badges</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl mb-1">🏆</div>
                  <div className="font-medium text-sm">Master</div>
                  <div className="text-xs text-muted-foreground">All 8 badges</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How to Earn Badges */}
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                How to Earn Badges
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">1.</span>
                  <span>Navigate to the Quiz page and select a level</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">2.</span>
                  <span>Complete all 7 modules in that level</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">3.</span>
                  <span>Score 70% or higher on each module</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">4.</span>
                  <span>Earn the badge automatically when all modules are completed</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">5.</span>
                  <span>Unlock the next level by earning the current level's badge</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
