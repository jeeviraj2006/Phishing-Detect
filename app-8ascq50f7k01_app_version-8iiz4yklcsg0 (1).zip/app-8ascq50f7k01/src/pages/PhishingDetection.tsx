import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { PhishingDetector } from '@/components/phishing/PhishingDetector';
import { URLScanner } from '@/components/phishing/URLScanner';
import { EmailAnalyzer } from '@/components/phishing/EmailAnalyzer';
import { PhishingExamples } from '@/components/phishing/PhishingExamples';
import { PhishingHistory } from '@/components/phishing/PhishingHistory';
import { PhishingStats } from '@/components/phishing/PhishingStats';
import { Shield, Link2, Mail, BookOpen, History, BarChart3, ArrowLeft, Home } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';

export default function PhishingDetection() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Phishing Detection Center</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold text-foreground">
              🎣 Advanced Phishing Detection
            </h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Protect yourself from phishing attacks with AI-powered detection tools. 
              Analyze emails, URLs, and messages to identify potential threats before they harm you.
            </p>
          </div>

          <Tabs defaultValue="detector" className="w-full">
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 h-auto gap-1">
              <TabsTrigger value="detector" className="gap-2">
                <Shield className="h-4 w-4" />
                <span className="hidden sm:inline">Quick Scan</span>
                <span className="sm:hidden">Scan</span>
              </TabsTrigger>
              <TabsTrigger value="url" className="gap-2">
                <Link2 className="h-4 w-4" />
                <span className="hidden sm:inline">URL Check</span>
                <span className="sm:hidden">URL</span>
              </TabsTrigger>
              <TabsTrigger value="email" className="gap-2">
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">Email Analysis</span>
                <span className="sm:hidden">Email</span>
              </TabsTrigger>
              <TabsTrigger value="examples" className="gap-2">
                <BookOpen className="h-4 w-4" />
                <span className="hidden sm:inline">Examples</span>
                <span className="sm:hidden">Learn</span>
              </TabsTrigger>
              <TabsTrigger value="history" className="gap-2">
                <History className="h-4 w-4" />
                <span className="hidden sm:inline">History</span>
                <span className="sm:hidden">Past</span>
              </TabsTrigger>
              <TabsTrigger value="stats" className="gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Statistics</span>
                <span className="sm:hidden">Stats</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="detector" className="mt-6">
              <div className="max-w-4xl mx-auto">
                <PhishingDetector />
              </div>
            </TabsContent>

            <TabsContent value="url" className="mt-6">
              <div className="max-w-4xl mx-auto">
                <URLScanner />
              </div>
            </TabsContent>

            <TabsContent value="email" className="mt-6">
              <div className="max-w-4xl mx-auto">
                <EmailAnalyzer />
              </div>
            </TabsContent>

            <TabsContent value="examples" className="mt-6">
              <PhishingExamples />
            </TabsContent>

            <TabsContent value="history" className="mt-6">
              <PhishingHistory />
            </TabsContent>

            <TabsContent value="stats" className="mt-6">
              <div className="max-w-4xl mx-auto">
                <PhishingStats />
              </div>
            </TabsContent>
          </Tabs>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-6 text-center space-y-3">
            <h3 className="text-lg font-semibold">🛡️ Stay Vigilant Against Phishing</h3>
            <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
              Remember: Legitimate organizations will never ask for sensitive information via email or text. 
              When in doubt, contact the organization directly through official channels.
            </p>
            <div className="flex flex-wrap justify-center gap-2 text-xs text-muted-foreground">
              <span className="px-3 py-1 rounded-full bg-background border">✓ Check sender address</span>
              <span className="px-3 py-1 rounded-full bg-background border">✓ Verify links before clicking</span>
              <span className="px-3 py-1 rounded-full bg-background border">✓ Look for urgency tactics</span>
              <span className="px-3 py-1 rounded-full bg-background border">✓ Trust your instincts</span>
            </div>
          </div>
        </div>
      </div>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 CyberGuard AI Assistant - Protecting College Students Online</p>
        </div>
      </footer>
    </div>
  );
}
