import { useState, useEffect } from 'react';
import { Link, useParams, useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, ArrowLeft, CheckCircle2, XCircle, Trophy, Star } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { QuizQuestion, QuizModule as QuizModuleType, QuizLevel } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function QuizModule() {
  const { user } = useAuth();
  const { levelId, moduleNumber } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const moduleId = location.state?.moduleId;
  
  const [module, setModule] = useState<QuizModuleType | null>(null);
  const [level, setLevel] = useState<QuizLevel | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (moduleId) {
      loadQuiz();
    }
  }, [moduleId]);

  const loadQuiz = async () => {
    setLoading(true);
    
    const levels = await api.quiz.getLevels();
    const currentLevel = levels.find(l => l.id === Number(levelId));
    setLevel(currentLevel || null);
    
    const modules = await api.quiz.getModulesByLevel(Number(levelId));
    const currentModule = modules.find(m => m.id === moduleId);
    setModule(currentModule || null);
    
    const questionsData = await api.quiz.getQuestionsByModule(moduleId);
    setQuestions(questionsData);
    setSelectedAnswers(new Array(questionsData.length).fill(-1));
    
    setLoading(false);
  };

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = async () => {
    const correctCount = questions.filter((q, index) => 
      q.correct_answer === selectedAnswers[index]
    ).length;
    
    const score = Math.round((correctCount / questions.length) * 100);
    const passed = score >= 70;
    
    const userId = await userManager.getCurrentUserId();
    await api.quiz.saveProgress(userId, moduleId, score, passed);
    
    if (passed) {
      const isLevelComplete = await api.quiz.checkLevelCompletion(userId, Number(levelId));
      if (isLevelComplete) {
        await api.quiz.awardBadge(userId, Number(levelId));
        toast({
          title: '🎉 Badge Earned!',
          description: `Congratulations! You've earned the ${level?.badge_name} badge!`,
        });
      }
    }
    
    setShowResults(true);
  };

  const getScore = () => {
    const correctCount = questions.filter((q, index) => 
      q.correct_answer === selectedAnswers[index]
    ).length;
    return Math.round((correctCount / questions.length) * 100);
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setSelectedAnswers(new Array(questions.length).fill(-1));
    setShowResults(false);
  };

  const handleBackToQuiz = () => {
    navigate('/quiz');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-12 w-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Loading quiz...</p>
        </div>
      </div>
    );
  }

  if (!module || questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Quiz Not Available</CardTitle>
            <CardDescription>
              This quiz module is not available yet. Each module contains 10 questions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/quiz">
              <Button className="w-full">Back to Quiz</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showResults) {
    const score = getScore();
    const passed = score >= 70;
    
    return (
      <div className="min-h-screen bg-gradient-background">
        <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sidebar />
                <Link to="/quiz">
                  <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <div className="flex items-center gap-2">
                  <Trophy className="h-6 w-6 text-primary" />
                  <h1 className="text-xl font-bold text-foreground">Quiz Results</h1>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {user ? (
                  <UserMenu />
                ) : (
                  <Link to="/login">
                    <Button className="gap-2">Sign In</Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8 max-w-4xl">
          <Card className={`${passed ? 'border-primary/50 bg-primary/5' : 'border-destructive/50 bg-destructive/5'}`}>
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                {passed ? (
                  <CheckCircle2 className="h-16 w-16 text-primary" />
                ) : (
                  <XCircle className="h-16 w-16 text-destructive" />
                )}
              </div>
              <CardTitle className="text-3xl">
                {passed ? 'Congratulations!' : 'Keep Trying!'}
              </CardTitle>
              <CardDescription className="text-lg">
                {passed 
                  ? 'You passed this module!' 
                  : 'You need 70% to pass. Review the material and try again.'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-6xl font-bold text-primary mb-2">{score}%</div>
                <p className="text-muted-foreground">
                  {questions.filter((q, i) => q.correct_answer === selectedAnswers[i]).length} out of {questions.length} correct
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Review Your Answers</h3>
                {questions.map((question, index) => {
                  const isCorrect = question.correct_answer === selectedAnswers[index];
                  return (
                    <Card key={question.id} className={isCorrect ? 'border-primary/30' : 'border-destructive/30'}>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-start gap-2">
                          {isCorrect ? (
                            <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          ) : (
                            <XCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                          )}
                          <div className="flex-1">
                            <p className="font-medium mb-2">Question {index + 1}: {question.question_text}</p>
                            <div className="space-y-1 text-sm">
                              <p className="text-muted-foreground">
                                Your answer: <span className={isCorrect ? 'text-primary font-medium' : 'text-destructive font-medium'}>
                                  {question.options[selectedAnswers[index]]}
                                </span>
                              </p>
                              {!isCorrect && (
                                <p className="text-muted-foreground">
                                  Correct answer: <span className="text-primary font-medium">
                                    {question.options[question.correct_answer]}
                                  </span>
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground mt-2 italic">
                                {question.explanation}
                              </p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <div className="flex gap-3">
                <Button onClick={handleRetry} variant="outline" className="flex-1">
                  Retake Quiz
                </Button>
                <Button onClick={handleBackToQuiz} className="flex-1">
                  Back to Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
          <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
            <p>Created by Jeeviraj V</p>
            <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
            <p className="mt-2">2025 CyberGuard AI</p>
          </div>
        </footer>
      </div>
    );
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/quiz">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{level?.badge_icon}</span>
                <div>
                  <h1 className="text-lg font-bold text-foreground">{module.title}</h1>
                  <p className="text-xs text-muted-foreground">Level {levelId} - Module {moduleNumber}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <Card>
          <CardHeader>
            <div className="mb-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-sm">
                    Level {levelId}
                  </Badge>
                  <Badge variant="secondary" className="text-sm">
                    Module {moduleNumber} of 7
                  </Badge>
                </div>
                <span className="text-sm font-medium text-muted-foreground">{Math.round(progress)}% Complete</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{level?.badge_icon}</span>
                  <span className="text-sm font-medium text-muted-foreground">{level?.title}</span>
                </div>
                <Badge variant="outline" className="text-sm">
                  Question {currentQuestion + 1} of {questions.length}
                </Badge>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold mb-6">{question.question_text}</h2>
              <div className="space-y-3">
                {question.options.map((option, index) => (
                  <Card
                    key={index}
                    className={`cursor-pointer transition-all ${
                      selectedAnswers[currentQuestion] === index
                        ? 'ring-2 ring-primary bg-primary/10'
                        : 'hover:bg-accent'
                    }`}
                    onClick={() => handleAnswerSelect(index)}
                  >
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswers[currentQuestion] === index
                          ? 'border-primary bg-primary'
                          : 'border-border'
                      }`}>
                        {selectedAnswers[currentQuestion] === index && (
                          <CheckCircle2 className="h-4 w-4 text-primary-foreground" />
                        )}
                      </div>
                      <span className="flex-1">{option}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                variant="outline"
                className="flex-1"
              >
                Previous
              </Button>
              {currentQuestion < questions.length - 1 ? (
                <Button
                  onClick={handleNext}
                  disabled={selectedAnswers[currentQuestion] === -1}
                  className="flex-1"
                >
                  Next
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={selectedAnswers.some(a => a === -1)}
                  className="flex-1"
                >
                  Submit Quiz
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>Created by Jeeviraj V</p>
          <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
          <p className="mt-2">2025 CyberGuard AI</p>
        </div>
      </footer>
    </div>
  );
}
