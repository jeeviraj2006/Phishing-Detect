import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Shield, ArrowLeft, MessageSquare, Star, ThumbsUp, Bug, Lightbulb } from 'lucide-react';
import { UserMenu } from '@/components/common/UserMenu';
import { Sidebar } from '@/components/common/Sidebar';
import { useAuth } from '@/context/AuthContext';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Feedback() {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [feedbackType, setFeedbackType] = useState('general');
  const [rating, setRating] = useState(0);
  const [formData, setFormData] = useState({
    name: profile?.username || '',
    email: profile?.email || '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: 'Feedback Submitted!',
      description: 'Thank you for your feedback. We\'ll review it shortly.',
    });
    setFormData({ name: profile?.username || '', email: profile?.email || '', subject: '', message: '' });
    setRating(0);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="min-h-screen bg-gradient-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sidebar />
              <Link to="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold text-foreground">Feedback</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {user ? (
                <UserMenu />
              ) : (
                <Link to="/login">
                  <Button className="gap-2">Sign In</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold">We Value Your Feedback</h1>
            <p className="text-lg text-muted-foreground">
              Help us improve CyberGuard AI by sharing your thoughts and suggestions
            </p>
          </div>

          <Tabs defaultValue="general" className="w-full" onValueChange={setFeedbackType}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="general" className="gap-2">
                <MessageSquare className="h-4 w-4" />
                General
              </TabsTrigger>
              <TabsTrigger value="bug" className="gap-2">
                <Bug className="h-4 w-4" />
                Bug Report
              </TabsTrigger>
              <TabsTrigger value="feature" className="gap-2">
                <Lightbulb className="h-4 w-4" />
                Feature Request
              </TabsTrigger>
              <TabsTrigger value="rating" className="gap-2">
                <Star className="h-4 w-4" />
                Rate Us
              </TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>General Feedback</CardTitle>
                  <CardDescription>
                    Share your overall experience with CyberGuard AI
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="Your name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="your.email@example.com"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">Subject</Label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="Brief summary of your feedback"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Tell us what you think..."
                        rows={6}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Submit Feedback
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="bug" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bug className="h-5 w-5 text-destructive" />
                    Report a Bug
                  </CardTitle>
                  <CardDescription>
                    Help us fix issues by providing detailed information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bug-name">Name</Label>
                        <Input
                          id="bug-name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="Your name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="bug-email">Email</Label>
                        <Input
                          id="bug-email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="your.email@example.com"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bug-subject">Bug Title</Label>
                      <Input
                        id="bug-subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="Brief description of the bug"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bug-message">Bug Description</Label>
                      <Textarea
                        id="bug-message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Please describe:&#10;1. What you were trying to do&#10;2. What happened instead&#10;3. Steps to reproduce the issue&#10;4. Your browser and device"
                        rows={8}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Submit Bug Report
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="feature" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-secondary" />
                    Request a Feature
                  </CardTitle>
                  <CardDescription>
                    Suggest new features or improvements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="feature-name">Name</Label>
                        <Input
                          id="feature-name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="Your name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="feature-email">Email</Label>
                        <Input
                          id="feature-email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="your.email@example.com"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feature-subject">Feature Title</Label>
                      <Input
                        id="feature-subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="Name of the feature you'd like to see"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feature-message">Feature Description</Label>
                      <Textarea
                        id="feature-message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Please describe:&#10;1. What feature you'd like to see&#10;2. Why it would be useful&#10;3. How you envision it working"
                        rows={8}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Submit Feature Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="rating" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-secondary" />
                    Rate Your Experience
                  </CardTitle>
                  <CardDescription>
                    How would you rate CyberGuard AI?
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="flex justify-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`h-12 w-12 ${
                              star <= rating
                                ? 'fill-secondary text-secondary'
                                : 'text-muted-foreground'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    {rating > 0 && (
                      <p className="text-center text-muted-foreground">
                        You rated us {rating} out of 5 stars
                      </p>
                    )}
                    <div className="space-y-2">
                      <Label htmlFor="rating-message">Additional Comments (Optional)</Label>
                      <Textarea
                        id="rating-message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Tell us more about your experience..."
                        rows={4}
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={rating === 0}>
                      Submit Rating
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Card className="bg-secondary/10 border-secondary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ThumbsUp className="h-5 w-5 text-secondary" />
                Thank You!
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Your feedback helps us make CyberGuard AI better for everyone. We read every submission
                and use your insights to improve our platform. If you've reported a bug or requested a
                feature, we'll do our best to address it in future updates.
              </p>
            </CardContent>
          </Card>

          <div className="flex justify-center pt-4">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>Created by Jeeviraj V</p>
          <p>Sri Shakthi Institute of Engineering and Technology, Coimbatore</p>
          <p className="mt-2">2025 CyberGuard AI</p>
        </div>
      </footer>
    </div>
  );
}
