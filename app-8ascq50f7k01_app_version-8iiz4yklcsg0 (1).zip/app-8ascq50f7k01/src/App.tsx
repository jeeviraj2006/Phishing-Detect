import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/context/AuthContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import routes from './routes';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <RouteGuard>
          <Toaster />
          <Routes>
            {routes.map((route, index) => {
              const Component = route.component;
              return (
                <Route
                  key={index}
                  path={route.path}
                  element={<Component />}
                />
              );
            })}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </RouteGuard>
      </Router>
    </AuthProvider>
  );
};

export default App;
