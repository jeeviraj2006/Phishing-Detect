export interface User {
  id: string;
  created_at: string;
  last_active: string;
}

export interface Profile {
  id: string;
  username: string;
  email: string | null;
  avatar_url: string | null;
  role: 'user' | 'admin';
  created_at: string;
  updated_at: string;
}

export interface ChatSession {
  id: string;
  user_id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  session_id: string;
  role: 'user' | 'model';
  content: string;
  image_url?: string;
  created_at: string;
}

export interface PhishingDetection {
  id: string;
  user_id: string;
  content: string;
  risk_level: 'low' | 'medium' | 'high';
  analysis: string;
  created_at: string;
}

export interface MonitoredEmail {
  id: string;
  user_id: string;
  sender: string;
  subject: string;
  content: string;
  risk_level: 'low' | 'medium' | 'high';
  analysis: string;
  is_read: boolean;
  created_at: string;
}

export interface QuizResult {
  id: string;
  user_id: string;
  quiz_type: string;
  score: number;
  total_questions: number;
  created_at: string;
}

export interface QuizLevel {
  id: number;
  title: string;
  description: string;
  badge_name: string;
  badge_icon: string;
  created_at: string;
}

export interface QuizModule {
  id: string;
  level_id: number;
  module_number: number;
  title: string;
  description: string;
  created_at: string;
}

export interface QuizQuestion {
  id: string;
  module_id: string;
  question_text: string;
  options: string[];
  correct_answer: number;
  explanation: string;
  created_at: string;
}

export interface UserQuizProgress {
  id: string;
  user_id: string;
  module_id: string;
  score: number;
  completed: boolean;
  completed_at: string | null;
  created_at: string;
}

export interface UserBadge {
  id: string;
  user_id: string;
  level_id: number;
  earned_at: string;
  created_at: string;
}

export interface SecurityChecklistItem {
  id: string;
  user_id: string;
  item_id: string;
  item_type: 'daily' | 'weekly' | 'monthly';
  completed_at: string;
  created_at: string;
}

export interface ThreatSimulatorResult {
  id: string;
  user_id: string;
  score: number;
  total_questions: number;
  completed_at: string;
}

export interface SecurityIncidentReport {
  id: string;
  user_id: string;
  incident_type: string;
  description: string;
  status: 'pending' | 'reviewed' | 'resolved';
  created_at: string;
}

export interface DeviceSecurityScan {
  id: string;
  user_id: string;
  score: number;
  total_checks: number;
  passed_checks: number;
  scan_data: Record<string, boolean>;
  created_at: string;
}

export interface LLMMessage {
  role: 'user' | 'model';
  parts: Array<{
    text?: string;
    inlineData?: {
      mimeType: string;
      data: string;
    };
  }>;
}

export interface LLMResponse {
  candidates: Array<{
    content: {
      role: string;
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
    index: number;
  }>;
}

