import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChatMessage } from './ChatMessage';
import { ChatHistory } from './ChatHistory';
import { Send, Loader2, Info, User, GraduationCap, Shield, Plus, Image as ImageIcon } from 'lucide-react';
import { llmService } from '@/lib/llmService';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { ChatMessage as ChatMessageType, LLMMessage } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

interface ChatInterfaceProps {
  sessionId: string | null;
  onSessionCreated: (sessionId: string) => void;
}

export function ChatInterface({ sessionId, onSessionCreated }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (sessionId) {
      loadMessages();
    } else {
      setMessages([]);
    }
  }, [sessionId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  const loadMessages = async () => {
    if (!sessionId) return;
    const msgs = await api.chatMessages.getBySessionId(sessionId);
    setMessages(msgs);
  };

  const handleSelectSession = (newSessionId: string) => {
    onSessionCreated(newSessionId);
  };

  const handleNewChat = () => {
    onSessionCreated('');
    setMessages([]);
    setInput('');
    setStreamingContent('');
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);
    setStreamingContent('');

    try {
      const userId = await userManager.getCurrentUserId();
      let currentSessionId = sessionId;

      if (!currentSessionId) {
        const newSession = await api.chatSessions.create(userId, 'New Chat');
        if (!newSession) {
          throw new Error('Failed to create chat session');
        }
        currentSessionId = newSession.id;
        onSessionCreated(currentSessionId);
      }

      const savedUserMsg = await api.chatMessages.create(currentSessionId, 'user', userMessage);
      if (savedUserMsg) {
        setMessages(prev => [...prev, savedUserMsg]);
      }

      // Check if user is requesting image generation
      const imageGenKeywords = [
        'generate image', 'create image', 'make image', 'draw', 'generate picture',
        'create picture', 'make picture', 'show me', 'visualize', 'illustrate',
        'generate an image', 'create an image', 'make an image',
        'image of', 'picture of', 'photo of', 'graphic of', 'diagram of',
        'can you create', 'can you generate', 'can you make', 'can you draw',
        'could you create', 'could you generate', 'could you make', 'could you draw',
        'please create', 'please generate', 'please make', 'please draw',
        'i want an image', 'i want a picture', 'i need an image', 'i need a picture',
        'design', 'sketch'
      ];
      
      const isImageRequest = imageGenKeywords.some(keyword => 
        userMessage.toLowerCase().includes(keyword)
      );

      if (isImageRequest) {
        // Extract the image prompt from the user message
        let imagePrompt = userMessage;
        
        // Remove common prefixes
        const prefixes = [
          'generate image of', 'create image of', 'make image of',
          'generate an image of', 'create an image of', 'make an image of',
          'generate picture of', 'create picture of', 'make picture of',
          'generate a picture of', 'create a picture of', 'make a picture of',
          'generate image', 'create image', 'make image',
          'generate picture', 'create picture', 'make picture',
          'can you create an image of', 'can you generate an image of', 'can you make an image of',
          'can you create a picture of', 'can you generate a picture of', 'can you make a picture of',
          'could you create an image of', 'could you generate an image of', 'could you make an image of',
          'could you create a picture of', 'could you generate a picture of', 'could you make a picture of',
          'please create an image of', 'please generate an image of', 'please make an image of',
          'please create a picture of', 'please generate a picture of', 'please make a picture of',
          'can you create', 'can you generate', 'can you make', 'can you draw',
          'could you create', 'could you generate', 'could you make', 'could you draw',
          'please create', 'please generate', 'please make', 'please draw',
          'i want an image of', 'i want a picture of', 'i need an image of', 'i need a picture of',
          'image of', 'picture of', 'photo of', 'graphic of', 'diagram of',
          'draw', 'show me', 'visualize', 'illustrate', 'design', 'sketch'
        ];
        
        for (const prefix of prefixes) {
          if (imagePrompt.toLowerCase().startsWith(prefix)) {
            imagePrompt = imagePrompt.substring(prefix.length).trim();
            break;
          }
        }

        try {
          setStreamingContent('🎨 Generating image... This may take 1-2 minutes. Please be patient...');
          const imageUrl = await llmService.generateImage(imagePrompt);
          setStreamingContent('');
          
          const responseText = `Here's the image you requested:`;
          const savedModelMsg = await api.chatMessages.create(currentSessionId!, 'model', responseText, imageUrl);
          if (savedModelMsg) {
            setMessages(prev => [...prev, savedModelMsg]);
          }
          setIsLoading(false);
        } catch (error) {
          console.error('Image generation error:', error);
          setStreamingContent('');
          
          // Show specific error message
          const errorMsg = error instanceof Error ? error.message : 'Unknown error occurred';
          const errorResponse = `I apologize, but I encountered an error while generating the image:\n\n${errorMsg}\n\nPlease try again in a moment. I can still help you with cybersecurity questions and advice!`;
          const savedModelMsg = await api.chatMessages.create(currentSessionId!, 'model', errorResponse);
          if (savedModelMsg) {
            setMessages(prev => [...prev, savedModelMsg]);
          }
          setIsLoading(false);
        }
        return;
      }

      // Normal text chat
      const conversationHistory: LLMMessage[] = messages.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content }]
      }));

      conversationHistory.push({
        role: 'user',
        parts: [{ text: userMessage }]
      });

      const systemPrompt: LLMMessage = {
        role: 'user',
        parts: [{
          text: `You are CyberGuard AI, a friendly and knowledgeable cybersecurity assistant designed for college students. Your role is to:
1. Answer questions about cybersecurity in an easy-to-understand way
2. Provide practical advice on staying safe online
3. Explain security concepts clearly without being overly technical
4. Be encouraging and supportive in helping students learn
5. When users want to see visual content, guide them to use phrases like "generate image of [description]" or "create image of [description]" to trigger the image generation feature

Keep responses concise, friendly, and educational. Use examples when helpful. If someone asks for an image or visual content without using the trigger phrases, politely remind them to use phrases like "generate image of..." or "create image of..." to activate the image generation feature.`
        }]
      };

      const modelResponse: LLMMessage = {
        role: 'model',
        parts: [{
          text: 'I understand. I will help students with cybersecurity questions in a friendly and educational manner. When users want visual content, I will guide them to use the proper phrases to trigger image generation.'
        }]
      };

      const fullConversation = [systemPrompt, modelResponse, ...conversationHistory];

      let fullResponse = '';

      await llmService.streamChat(fullConversation, {
        onChunk: (text) => {
          fullResponse += text;
          setStreamingContent(fullResponse);
        },
        onComplete: async () => {
          setStreamingContent('');
          const savedModelMsg = await api.chatMessages.create(currentSessionId!, 'model', fullResponse);
          if (savedModelMsg) {
            setMessages(prev => [...prev, savedModelMsg]);
          }
          setIsLoading(false);
        },
        onError: (error) => {
          toast({
            title: 'Error',
            description: error,
            variant: 'destructive'
          });
          setIsLoading(false);
          setStreamingContent('');
        }
      });
    } catch (error) {
      console.error('Chat error:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive'
      });
      setIsLoading(false);
      setStreamingContent('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid File',
        description: 'Please upload an image file (PNG, JPG, JPEG, WebP)',
        variant: 'destructive',
      });
      return;
    }

    // Check file size (max 1MB)
    if (file.size > 1024 * 1024) {
      toast({
        title: 'File Too Large',
        description: 'Please upload an image smaller than 1MB',
        variant: 'destructive',
      });
      return;
    }

    setIsPopoverOpen(false);
    setIsLoading(true);

    try {
      // Convert image to base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64Image = event.target?.result as string;

        // Create user message with image
        const userMessage: ChatMessageType = {
          id: crypto.randomUUID(),
          session_id: sessionId || '',
          role: 'user',
          content: `[Image uploaded: ${file.name}]\n\nPlease analyze this image for potential security threats, phishing attempts, or suspicious content.`,
          created_at: new Date().toISOString(),
        };

        setMessages(prev => [...prev, userMessage]);

        // Create session if needed
        let currentSessionId = sessionId;
        if (!currentSessionId) {
          const userId = await userManager.getCurrentUserId();
          const newSession = await api.chatSessions.create(userId, 'Image Analysis');
          if (!newSession) {
            throw new Error('Failed to create chat session');
          }
          currentSessionId = newSession.id;
          onSessionCreated(currentSessionId);
        }

        // Save user message
        await api.chatMessages.create(currentSessionId, 'user', userMessage.content);

        // Send to LLM with image
        const llmMessages: LLMMessage[] = [
          {
            role: 'user',
            parts: [
              { text: 'You are a cybersecurity expert. Analyze this image for potential security threats, phishing attempts, suspicious links, fake websites, or any malicious content. Provide a detailed analysis and recommendations.' },
              { inlineData: { mimeType: file.type, data: base64Image.split(',')[1] } }
            ]
          }
        ];

        let fullResponse = '';
        await llmService.streamChat(llmMessages, {
          onChunk: (chunk) => {
            fullResponse += chunk;
            setStreamingContent(fullResponse);
          },
          onComplete: () => {},
          onError: (error) => {
            throw new Error(error);
          }
        });

        // Save assistant message
        const assistantMessage: ChatMessageType = {
          id: crypto.randomUUID(),
          session_id: currentSessionId,
          role: 'model',
          content: fullResponse,
          created_at: new Date().toISOString(),
        };

        await api.chatMessages.create(currentSessionId, 'model', fullResponse);
        setMessages(prev => [...prev, assistantMessage]);
        setStreamingContent('');
      };

      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: 'Upload Failed',
        description: 'Failed to analyze image. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleQuickAction = (action: string) => {
    setIsPopoverOpen(false);
    if (action === 'upload-image') {
      fileInputRef.current?.click();
    }
  };

  const quickActions = [
    { icon: ImageIcon, label: 'Upload image for analysis', action: 'upload-image' },
  ];

  return (
    <Card className="flex h-full flex-col">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageUpload}
      />
      <CardHeader>
        <CardTitle className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🛡️</span>
            CyberGuard AI Assistant
          </div>
          <div className="flex items-center gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Info className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-primary" />
                    About CyberGuard AI
                  </DialogTitle>
                  <DialogDescription>
                    Your intelligent cybersecurity assistant
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <User className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-semibold">Created By</p>
                      <p className="text-sm text-foreground font-medium">Jeeviraj V</p>
                      <p className="text-xs text-muted-foreground">Founder & Developer</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <GraduationCap className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-semibold">Institution</p>
                      <p className="text-sm text-foreground font-medium">Sri Shakthi Institute of Engineering and Technology</p>
                      <p className="text-xs text-muted-foreground">Coimbatore, Tamil Nadu, India</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-semibold">Mission</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Empowering college students with AI-powered cybersecurity education, 
                        real-time phishing detection, and personalized guidance for staying safe online.
                      </p>
                    </div>
                  </div>

                  <div className="text-center pt-2">
                    <p className="text-xs text-muted-foreground">Version 1.0.0 • 2025 CyberGuard AI</p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <ChatHistory
              currentSessionId={sessionId}
              onSelectSession={handleSelectSession}
              onNewChat={handleNewChat}
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4 overflow-hidden">
        <div className="flex-1 space-y-4 overflow-y-auto pr-2">
          {messages.length === 0 && !streamingContent && (
            <div className="flex h-full items-center justify-center text-center">
              <div className="space-y-2">
                <p className="text-lg font-medium text-muted-foreground">
                  Welcome to CyberGuard AI! 👋
                </p>
                <p className="text-sm text-muted-foreground">
                  Ask me anything about cybersecurity, phishing, passwords, or online safety.
                </p>
              </div>
            </div>
          )}
          {messages.map((msg) => (
            <ChatMessage key={msg.id} role={msg.role} content={msg.content} imageUrl={msg.image_url} />
          ))}
          {streamingContent && (
            <ChatMessage role="model" content={streamingContent} />
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className="flex gap-2 items-end">
          <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-full flex-shrink-0"
                disabled={isLoading}
              >
                <Plus className="h-5 w-5" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-2" align="start" side="top">
              <div className="space-y-1">
                {quickActions.map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={index}
                      variant="ghost"
                      className="w-full justify-start gap-3 h-10"
                      onClick={() => handleQuickAction(item.action)}
                    >
                      <Icon className="h-4 w-4" />
                      <span className="text-sm">{item.label}</span>
                    </Button>
                  );
                })}
              </div>
            </PopoverContent>
          </Popover>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Ask about cybersecurity..."
            className="min-h-[60px] resize-none flex-1"
            disabled={isLoading}
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            size="icon"
            className="h-[60px] w-[60px] flex-shrink-0"
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

