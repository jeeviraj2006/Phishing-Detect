import { Card } from '@/components/ui/card';
import { Bot, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ChatMessageProps {
  role: 'user' | 'model';
  content: string;
  imageUrl?: string;
}

export function ChatMessage({ role, content, imageUrl }: ChatMessageProps) {
  const isUser = role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
        isUser ? 'bg-primary' : 'bg-secondary'
      }`}>
        {isUser ? (
          <User className="h-5 w-5 text-primary-foreground" />
        ) : (
          <Bot className="h-5 w-5 text-secondary-foreground" />
        )}
      </div>
      <Card className={`max-w-[80%] p-4 ${
        isUser ? 'bg-primary text-primary-foreground' : 'bg-card'
      }`}>
        {imageUrl && (
          <div className="mb-3">
            <img 
              src={imageUrl} 
              alt="Generated image" 
              className="rounded-lg max-w-full h-auto"
              style={{ maxHeight: '400px' }}
            />
          </div>
        )}
        <div className="prose prose-sm max-w-none dark:prose-invert">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {content}
          </ReactMarkdown>
        </div>
      </Card>
    </div>
  );
}
