import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  User,
  Settings,
  HelpCircle,
  LogOut,
  ChevronRight,
  Upload,
  Shield,
  UserCircle,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/db/supabase';

export function UserMenu() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  if (!user || !profile) {
    return (
      <Button onClick={() => navigate('/login')} variant="outline" size="sm">
        <UserCircle className="h-4 w-4 mr-2" />
        Sign In
      </Button>
    );
  }

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: 'Signed out',
        description: 'You have been signed out successfully',
      });
      navigate('/');
      setIsOpen(false);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to sign out',
        variant: 'destructive',
      });
    }
  };

  const compressImage = async (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          const maxDimension = 1080;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          canvas.toBlob(
            (blob) => {
              if (blob) {
                const compressedFile = new File([blob], file.name.replace(/\.[^.]+$/, '.webp'), {
                  type: 'image/webp',
                });
                resolve(compressedFile);
              } else {
                reject(new Error('Failed to compress image'));
              }
            },
            'image/webp',
            0.8
          );
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!/^[a-zA-Z0-9_.-]+$/.test(file.name)) {
      toast({
        title: 'Invalid filename',
        description: 'Filename can only contain English letters and numbers',
        variant: 'destructive',
      });
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload an image file',
        variant: 'destructive',
      });
      return;
    }

    setIsUploading(true);
    try {
      let uploadFile = file;
      let wasCompressed = false;

      if (file.size > 1048576) {
        uploadFile = await compressImage(file);
        wasCompressed = true;
      }

      if (uploadFile.size > 1048576) {
        toast({
          title: 'File too large',
          description: 'Image must be under 1MB even after compression',
          variant: 'destructive',
        });
        return;
      }

      if (profile.avatar_url) {
        const oldPath = profile.avatar_url.split('/').pop();
        if (oldPath) {
          await supabase.storage
            .from('cyberguard_profile_images')
            .remove([`${user.id}/${oldPath}`]);
        }
      }

      const fileExt = uploadFile.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('cyberguard_profile_images')
        .upload(filePath, uploadFile);

      if (uploadError) throw uploadError;

      const {
        data: { publicUrl },
      } = supabase.storage.from('cyberguard_profile_images').getPublicUrl(filePath);

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      await refreshProfile();

      toast({
        title: 'Success',
        description: wasCompressed
          ? `Profile picture updated! Image was compressed to ${(uploadFile.size / 1024).toFixed(0)}KB`
          : 'Profile picture updated successfully',
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        title: 'Upload failed',
        description: error.message || 'Failed to upload profile picture',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  const getInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0">
          <Avatar className="h-10 w-10">
            <AvatarImage src={profile.avatar_url || undefined} alt={profile.username} />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {getInitials(profile.username)}
            </AvatarFallback>
          </Avatar>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[280px] p-0">
        <div className="flex h-full flex-col">
          <div className="p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="relative group">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={profile.avatar_url || undefined} alt={profile.username} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {getInitials(profile.username)}
                  </AvatarFallback>
                </Avatar>
                <label
                  htmlFor="avatar-upload"
                  className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                >
                  {isUploading ? (
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  ) : (
                    <Upload className="h-5 w-5 text-white" />
                  )}
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarUpload}
                  disabled={isUploading}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-lg truncate">{profile.username}</p>
                {profile.role === 'admin' && (
                  <div className="flex items-center gap-1 text-xs text-primary">
                    <Shield className="h-3 w-3" />
                    <span>Admin</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Separator />

          <div className="flex-1 overflow-y-auto">
            <div className="p-2 space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  navigate('/profile');
                  setIsOpen(false);
                }}
              >
                <User className="mr-3 h-5 w-5" />
                Profile
                <ChevronRight className="ml-auto h-4 w-4" />
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  navigate('/settings');
                  setIsOpen(false);
                }}
              >
                <Settings className="mr-3 h-5 w-5" />
                Settings
                <ChevronRight className="ml-auto h-4 w-4" />
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  navigate('/help');
                  setIsOpen(false);
                }}
              >
                <HelpCircle className="mr-3 h-5 w-5" />
                Help
                <ChevronRight className="ml-auto h-4 w-4" />
              </Button>

              {profile.role === 'admin' && (
                <>
                  <Separator className="my-2" />
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-primary"
                    onClick={() => {
                      navigate('/admin');
                      setIsOpen(false);
                    }}
                  >
                    <Shield className="mr-3 h-5 w-5" />
                    Admin Panel
                    <ChevronRight className="ml-auto h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>

          <Separator />

          <div className="p-2">
            <Button
              variant="ghost"
              className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
              onClick={handleSignOut}
            >
              <LogOut className="mr-3 h-5 w-5" />
              Log out
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
