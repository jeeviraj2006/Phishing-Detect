import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Menu,
  Home,
  Shield,
  BookOpen,
  Trophy,
  MessageSquare,
  Settings,
  HelpCircle,
  User,
  LogOut,
  ChevronRight,
  Star,
  Clock,
  TrendingUp,
  Mail,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { UserBadge, QuizLevel } from '@/types/types';

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [badges, setBadges] = useState<UserBadge[]>([]);
  const [levels, setLevels] = useState<QuizLevel[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && user) {
      loadUserData();
    }
  }, [open, user]);

  const loadUserData = async () => {
    setLoading(true);
    try {
      const userId = await userManager.getCurrentUserId();
      const [badgesData, levelsData] = await Promise.all([
        api.quiz.getUserBadges(userId),
        api.quiz.getLevels(),
      ]);
      setBadges(badgesData);
      setLevels(levelsData);
    } catch (error) {
      console.error('Error loading sidebar data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    setOpen(false);
  };

  const handleLogout = async () => {
    await signOut();
    setOpen(false);
    navigate('/');
  };

  const totalBadges = levels.length;
  const earnedBadges = badges.length;
  const progressPercentage = totalBadges > 0 ? (earnedBadges / totalBadges) * 100 : 0;

  const navigationItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Shield, label: 'Security Tools', path: '/tools' },
    { icon: Mail, label: 'Email Monitor', path: '/email-monitor' },
    { icon: BookOpen, label: 'Quiz', path: '/quiz' },
    { icon: Trophy, label: 'Badges', path: '/badges' },
  ];

  const quickActions = [
    { icon: MessageSquare, label: 'Feedback', path: '/feedback' },
    { icon: HelpCircle, label: 'Help & Support', path: '/help' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className={className}>
          <Menu className="h-5 w-5" />
          <span className="sr-only">Open menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
        <ScrollArea className="h-full">
          <div className="flex flex-col h-full">
            {/* Header */}
            <SheetHeader className="p-6 pb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <SheetTitle className="text-left">CyberGuard AI</SheetTitle>
                  <p className="text-xs text-muted-foreground">Your Security Assistant</p>
                </div>
              </div>
            </SheetHeader>

            <Separator />

            {/* User Profile Section */}
            {user ? (
              <div className="p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{user.email}</p>
                    <p className="text-xs text-muted-foreground">Logged in</p>
                  </div>
                </div>

                {/* Badge Progress */}
                {!loading && (
                  <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Trophy className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Your Progress</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {earnedBadges}/{totalBadges}
                      </Badge>
                    </div>
                    <Progress value={progressPercentage} className="h-2" />
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{earnedBadges} badges earned</span>
                      <span>{Math.round(progressPercentage)}%</span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full"
                      onClick={() => handleNavigation('/badges')}
                    >
                      View All Badges
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-6">
                <div className="bg-muted/50 rounded-lg p-4 text-center space-y-3">
                  <User className="h-8 w-8 mx-auto text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    Sign in to track your progress and earn badges
                  </p>
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => handleNavigation('/login')}
                  >
                    Sign In
                  </Button>
                </div>
              </div>
            )}

            <Separator />

            {/* Navigation Items */}
            <div className="p-4 space-y-1">
              <p className="text-xs font-semibold text-muted-foreground px-2 mb-2">
                NAVIGATION
              </p>
              {navigationItems.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  className="w-full justify-start gap-3"
                  onClick={() => handleNavigation(item.path)}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </Button>
              ))}
            </div>

            <Separator />

            {/* Recent Badges */}
            {user && badges.length > 0 && (
              <>
                <div className="p-4 space-y-3">
                  <p className="text-xs font-semibold text-muted-foreground px-2">
                    RECENT BADGES
                  </p>
                  <div className="space-y-2">
                    {badges.slice(0, 3).map((badge) => {
                      const level = levels.find((l) => l.id === badge.level_id);
                      if (!level) return null;
                      return (
                        <div
                          key={badge.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                          onClick={() => handleNavigation('/badges')}
                        >
                          <span className="text-2xl">{level.badge_icon}</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">
                              {level.badge_name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Level {level.id}
                            </p>
                          </div>
                          <Star className="h-4 w-4 text-primary flex-shrink-0" />
                        </div>
                      );
                    })}
                  </div>
                  {badges.length > 3 && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="w-full text-xs"
                      onClick={() => handleNavigation('/badges')}
                    >
                      View all {badges.length} badges
                    </Button>
                  )}
                </div>
                <Separator />
              </>
            )}

            {/* Quick Stats */}
            {user && (
              <>
                <div className="p-4 space-y-3">
                  <p className="text-xs font-semibold text-muted-foreground px-2">
                    QUICK STATS
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-muted/50 rounded-lg p-3 text-center">
                      <Trophy className="h-5 w-5 mx-auto mb-1 text-primary" />
                      <p className="text-lg font-bold">{earnedBadges}</p>
                      <p className="text-xs text-muted-foreground">Badges</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-3 text-center">
                      <TrendingUp className="h-5 w-5 mx-auto mb-1 text-primary" />
                      <p className="text-lg font-bold">{Math.round(progressPercentage)}%</p>
                      <p className="text-xs text-muted-foreground">Progress</p>
                    </div>
                  </div>
                </div>
                <Separator />
              </>
            )}

            {/* Quick Actions */}
            <div className="p-4 space-y-1">
              <p className="text-xs font-semibold text-muted-foreground px-2 mb-2">
                QUICK ACTIONS
              </p>
              {quickActions.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  className="w-full justify-start gap-3"
                  onClick={() => handleNavigation(item.path)}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </Button>
              ))}
            </div>

            {/* Logout Button */}
            {user && (
              <>
                <Separator />
                <div className="p-4">
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-3 text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Log Out</span>
                  </Button>
                </div>
              </>
            )}

            {/* Footer */}
            <div className="mt-auto p-4 text-center">
              <p className="text-xs text-muted-foreground">
                CyberGuard AI Assistant
              </p>
              <p className="text-xs text-muted-foreground">
                © 2025 All rights reserved
              </p>
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
