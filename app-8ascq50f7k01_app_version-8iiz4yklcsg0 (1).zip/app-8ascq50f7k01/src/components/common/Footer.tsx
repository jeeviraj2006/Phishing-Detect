import React from "react";
import { Sparkles } from "lucide-react";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-r from-primary/5 to-secondary/5 border-t border-border">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About CyberGuard AI */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              About CyberGuard AI
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Your intelligent cybersecurity companion, helping college students stay safe online through AI-powered threat detection and interactive security education.
            </p>
          </div>

          {/* Features */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Features
            </h3>
            <ul className="text-muted-foreground text-sm space-y-2">
              <li>• AI-Powered Phishing Detection</li>
              <li>• Interactive Security Chat</li>
              <li>• Comprehensive Security Tools</li>
              <li>• Educational Quizzes</li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Stay Secure
            </h3>
            <ul className="text-muted-foreground text-sm space-y-2">
              <li>• Enable Two-Factor Authentication</li>
              <li>• Use Strong Passwords</li>
              <li>• Stay Alert for Phishing</li>
              <li>• Keep Software Updated</li>
            </ul>
          </div>
        </div>

        {/* Built by Medo AI Section */}
        <div className="mt-8 pt-8 border-t border-border">
          <div className="flex flex-col items-center justify-center space-y-4">
            {/* Medo AI Branding */}
            <div className="flex items-center gap-3">
              <img 
                src="https://miaoda-site-img.s3cdn.medo.dev/images/4e455be1-404d-4834-9e4f-514102af12be.jpg" 
                alt="Medo AI Logo" 
                className="h-10 w-10 rounded-lg object-cover"
              />
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-muted-foreground">Built by</span>
                  <span className="text-lg font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                    Medo AI
                  </span>
                  <Sparkles className="h-4 w-4 text-accent" />
                </div>
                <span className="text-xs text-muted-foreground">Powered by Advanced AI Technology</span>
              </div>
            </div>
            
            {/* Copyright */}
            <p className="text-center text-sm text-muted-foreground">
              {currentYear} CyberGuard AI Assistant
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

