import { ReactNode, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

const PUBLIC_ROUTES = [
  '/',
  '/login',
  '/chat',
  '/phishing-detector',
  '/security-tools',
  '/education',
];

const ADMIN_ROUTES = ['/admin'];

interface RouteGuardProps {
  children: ReactNode;
}

export function RouteGuard({ children }: RouteGuardProps) {
  const { user, profile, loading } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;

    const currentPath = location.pathname;
    const isPublicRoute = PUBLIC_ROUTES.some(route => currentPath === route || currentPath.startsWith(route));
    const isAdminRoute = ADMIN_ROUTES.some(route => currentPath.startsWith(route));

    if (isAdminRoute) {
      if (!user) {
        navigate('/login', { state: { from: currentPath }, replace: true });
      } else if (profile?.role !== 'admin') {
        navigate('/', { replace: true });
      }
    }
  }, [user, profile, loading, location, navigate]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
