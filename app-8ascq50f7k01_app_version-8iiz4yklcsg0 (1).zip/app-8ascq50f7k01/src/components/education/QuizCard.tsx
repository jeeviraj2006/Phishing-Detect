import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, XCircle, Trophy } from 'lucide-react';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import { useToast } from '@/hooks/use-toast';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
}

const allQuizQuestions: Question[] = [
  // Password Security (10 questions)
  {
    question: 'What is the most secure way to create a password?',
    options: [
      'Use your birthday',
      'Use a random mix of letters, numbers, and symbols',
      'Use the same password for all accounts',
      'Use common words like "password123"'
    ],
    correctAnswer: 1,
    explanation: 'A strong password uses a random combination of uppercase and lowercase letters, numbers, and special symbols, making it harder to crack.',
    category: 'Password Security'
  },
  {
    question: 'How long should a strong password be?',
    options: [
      'At least 6 characters',
      'At least 8 characters',
      'At least 12 characters',
      'At least 20 characters'
    ],
    correctAnswer: 2,
    explanation: 'Security experts recommend passwords of at least 12 characters. Longer passwords are exponentially harder to crack.',
    category: 'Password Security'
  },
  {
    question: 'What is a password manager?',
    options: [
      'A person who remembers your passwords',
      'A secure app that stores and generates passwords',
      'A notebook for writing passwords',
      'A browser feature that saves passwords'
    ],
    correctAnswer: 1,
    explanation: 'A password manager is a secure application that stores, generates, and manages complex passwords for all your accounts.',
    category: 'Password Security'
  },
  {
    question: 'How often should you change your passwords?',
    options: [
      'Every day',
      'Every week',
      'Every 3-6 months or after a breach',
      'Never'
    ],
    correctAnswer: 2,
    explanation: 'Change passwords every 3-6 months for important accounts, or immediately if you suspect a breach.',
    category: 'Password Security'
  },
  {
    question: 'What makes a password weak?',
    options: [
      'Using personal information like names or birthdays',
      'Using special characters',
      'Being longer than 15 characters',
      'Using a password manager'
    ],
    correctAnswer: 0,
    explanation: 'Personal information is easily guessable. Avoid using names, birthdays, addresses, or other publicly available information.',
    category: 'Password Security'
  },
  {
    question: 'What is password hashing?',
    options: [
      'Writing passwords on paper',
      'Converting passwords into fixed-length encrypted strings',
      'Sharing passwords with friends',
      'Using the same password everywhere'
    ],
    correctAnswer: 1,
    explanation: 'Password hashing converts passwords into encrypted strings that cannot be reversed, protecting them even if a database is breached.',
    category: 'Password Security'
  },
  {
    question: 'What is a passphrase?',
    options: [
      'A short 4-digit PIN',
      'A long sentence or series of words used as a password',
      'A password hint',
      'A temporary password'
    ],
    correctAnswer: 1,
    explanation: 'A passphrase is a sequence of words or a sentence that is easy to remember but hard to crack, like "Coffee!Morning@Sunshine2024".',
    category: 'Password Security'
  },
  {
    question: 'Should you use the same password for multiple accounts?',
    options: [
      'Yes, it\'s easier to remember',
      'Yes, but only for unimportant accounts',
      'No, never',
      'Only for social media accounts'
    ],
    correctAnswer: 2,
    explanation: 'Never reuse passwords. If one account is breached, all accounts with the same password become vulnerable.',
    category: 'Password Security'
  },
  {
    question: 'What is a brute force attack?',
    options: [
      'Physical damage to a computer',
      'Trying all possible password combinations',
      'Sending spam emails',
      'Installing malware'
    ],
    correctAnswer: 1,
    explanation: 'A brute force attack systematically tries every possible password combination until finding the correct one.',
    category: 'Password Security'
  },
  {
    question: 'What should you do if you forget a password?',
    options: [
      'Try to guess it multiple times',
      'Use the "Forgot Password" feature',
      'Create a new account',
      'Ask a friend to hack it'
    ],
    correctAnswer: 1,
    explanation: 'Always use the official "Forgot Password" or password reset feature. Never try to guess repeatedly as this may lock your account.',
    category: 'Password Security'
  },

  // Phishing & Social Engineering (15 questions)
  {
    question: 'Which of these is a common sign of a phishing email?',
    options: [
      'Personalized greeting with your name',
      'Urgent language demanding immediate action',
      'Professional company logo',
      'Proper grammar and spelling'
    ],
    correctAnswer: 1,
    explanation: 'Phishing emails often create a sense of urgency to pressure you into acting without thinking. Always verify suspicious requests through official channels.',
    category: 'Phishing'
  },
  {
    question: 'What should you do before clicking a link in an email?',
    options: [
      'Click it immediately if it looks legitimate',
      'Hover over it to see the actual URL',
      'Forward it to friends first',
      'Nothing, all links are safe'
    ],
    correctAnswer: 1,
    explanation: 'Hovering over a link reveals the actual destination URL. Phishers often disguise malicious links with legitimate-looking text.',
    category: 'Phishing'
  },
  {
    question: 'What is spear phishing?',
    options: [
      'Fishing with a spear',
      'Targeted phishing attack on specific individuals',
      'Mass email spam',
      'A type of malware'
    ],
    correctAnswer: 1,
    explanation: 'Spear phishing is a targeted attack using personalized information to appear more legitimate and trustworthy.',
    category: 'Phishing'
  },
  {
    question: 'What is social engineering?',
    options: [
      'Building social media apps',
      'Manipulating people to divulge confidential information',
      'Engineering social networks',
      'Creating online communities'
    ],
    correctAnswer: 1,
    explanation: 'Social engineering uses psychological manipulation to trick people into revealing sensitive information or performing actions.',
    category: 'Phishing'
  },
  {
    question: 'You receive an email from "your bank" asking you to verify your account. What should you do?',
    options: [
      'Click the link and enter your information',
      'Reply with your account details',
      'Contact your bank directly using official contact info',
      'Forward it to friends'
    ],
    correctAnswer: 2,
    explanation: 'Banks never ask for sensitive information via email. Always contact them directly using official phone numbers or websites.',
    category: 'Phishing'
  },
  {
    question: 'What is whaling in cybersecurity?',
    options: [
      'Hunting for whales online',
      'Phishing attacks targeting high-profile executives',
      'A type of virus',
      'Downloading large files'
    ],
    correctAnswer: 1,
    explanation: 'Whaling targets high-profile individuals like CEOs or executives with sophisticated phishing attacks.',
    category: 'Phishing'
  },
  {
    question: 'What is pretexting?',
    options: [
      'Writing before an exam',
      'Creating a fabricated scenario to obtain information',
      'Sending text messages',
      'Previewing content'
    ],
    correctAnswer: 1,
    explanation: 'Pretexting involves creating a false scenario or identity to manipulate victims into sharing sensitive information.',
    category: 'Phishing'
  },
  {
    question: 'What is vishing?',
    options: [
      'Video phishing',
      'Voice phishing via phone calls',
      'Visual phishing',
      'Virtual phishing'
    ],
    correctAnswer: 1,
    explanation: 'Vishing (voice phishing) uses phone calls to trick victims into revealing sensitive information.',
    category: 'Phishing'
  },
  {
    question: 'What is smishing?',
    options: [
      'Smiling while phishing',
      'Phishing via SMS text messages',
      'Small phishing attacks',
      'Smart phishing'
    ],
    correctAnswer: 1,
    explanation: 'Smishing uses SMS text messages to deliver phishing attacks, often with malicious links.',
    category: 'Phishing'
  },
  {
    question: 'How can you identify a phishing website?',
    options: [
      'It has a professional design',
      'Check for HTTPS and verify the domain name',
      'It loads quickly',
      'It has a contact form'
    ],
    correctAnswer: 1,
    explanation: 'Check for HTTPS, verify the exact domain name (look for misspellings), and be wary of sites asking for sensitive information.',
    category: 'Phishing'
  },
  {
    question: 'What should you do if you clicked a phishing link?',
    options: [
      'Ignore it',
      'Immediately change passwords and scan for malware',
      'Wait and see what happens',
      'Delete your email account'
    ],
    correctAnswer: 1,
    explanation: 'Act quickly: change passwords, run antivirus scans, monitor accounts, and report the incident.',
    category: 'Phishing'
  },
  {
    question: 'What is a CEO fraud?',
    options: [
      'A CEO committing fraud',
      'Impersonating a CEO to authorize fraudulent transactions',
      'Fraud against CEOs',
      'CEO security training'
    ],
    correctAnswer: 1,
    explanation: 'CEO fraud involves impersonating executives to trick employees into transferring money or revealing sensitive data.',
    category: 'Phishing'
  },
  {
    question: 'What is baiting in social engineering?',
    options: [
      'Fishing for information',
      'Offering something enticing to trick victims',
      'Waiting for victims',
      'Setting traps'
    ],
    correctAnswer: 1,
    explanation: 'Baiting lures victims with promises of goods or services (like free USB drives or downloads) that contain malware.',
    category: 'Phishing'
  },
  {
    question: 'What is tailgating in security?',
    options: [
      'Following someone\'s car',
      'Following authorized person into restricted area',
      'Tracking online activity',
      'Monitoring emails'
    ],
    correctAnswer: 1,
    explanation: 'Tailgating is when an unauthorized person follows an authorized person into a restricted physical area.',
    category: 'Phishing'
  },
  {
    question: 'How can you report a phishing email?',
    options: [
      'Delete it immediately',
      'Forward to your IT department or use email provider\'s report feature',
      'Reply to tell them it\'s phishing',
      'Share it on social media'
    ],
    correctAnswer: 1,
    explanation: 'Report phishing to your IT department, email provider, or authorities to help protect others.',
    category: 'Phishing'
  },

  // Two-Factor Authentication (5 questions)
  {
    question: 'What is two-factor authentication (2FA)?',
    options: [
      'Using two different passwords',
      'An extra security layer requiring a second verification method',
      'Logging in twice',
      'Having two email accounts'
    ],
    correctAnswer: 1,
    explanation: '2FA adds an extra security layer by requiring something you know (password) and something you have (phone, security key) to access your account.',
    category: '2FA'
  },
  {
    question: 'Which is the most secure form of 2FA?',
    options: [
      'SMS text codes',
      'Email codes',
      'Hardware security keys',
      'Security questions'
    ],
    correctAnswer: 2,
    explanation: 'Hardware security keys (like YubiKey) are the most secure 2FA method as they cannot be intercepted or phished.',
    category: '2FA'
  },
  {
    question: 'What is an authenticator app?',
    options: [
      'An app that verifies your identity',
      'An app that generates time-based codes for 2FA',
      'An app that stores passwords',
      'An app that scans for viruses'
    ],
    correctAnswer: 1,
    explanation: 'Authenticator apps (like Google Authenticator) generate time-based one-time passwords (TOTP) for secure 2FA.',
    category: '2FA'
  },
  {
    question: 'Why is SMS-based 2FA less secure?',
    options: [
      'It\'s too complicated',
      'SMS can be intercepted or SIM cards can be swapped',
      'It costs money',
      'It\'s too slow'
    ],
    correctAnswer: 1,
    explanation: 'SMS can be intercepted through SIM swapping attacks or network vulnerabilities. Use authenticator apps or hardware keys instead.',
    category: '2FA'
  },
  {
    question: 'What are backup codes in 2FA?',
    options: [
      'Extra passwords',
      'One-time codes to access account if 2FA device is unavailable',
      'Codes for backing up data',
      'Codes for resetting passwords'
    ],
    correctAnswer: 1,
    explanation: 'Backup codes are one-time use codes that let you access your account if you lose your 2FA device. Store them securely.',
    category: '2FA'
  },

  // Wi-Fi & Network Security (8 questions)
  {
    question: 'Is it safe to use public Wi-Fi for online banking?',
    options: [
      'Yes, always safe',
      'No, unless using a VPN',
      'Only on weekends',
      'Yes, if the network has a password'
    ],
    correctAnswer: 1,
    explanation: 'Public Wi-Fi can be intercepted by attackers. Use a VPN to encrypt your connection when accessing sensitive information on public networks.',
    category: 'Network Security'
  },
  {
    question: 'What is a VPN?',
    options: [
      'Very Private Network',
      'Virtual Private Network that encrypts internet connection',
      'Virus Protection Network',
      'Visual Privacy Network'
    ],
    correctAnswer: 1,
    explanation: 'A VPN creates an encrypted tunnel for your internet traffic, protecting your privacy and security online.',
    category: 'Network Security'
  },
  {
    question: 'What is WPA3?',
    options: [
      'A type of malware',
      'The latest Wi-Fi security protocol',
      'A web browser',
      'A password manager'
    ],
    correctAnswer: 1,
    explanation: 'WPA3 is the newest Wi-Fi security standard, offering stronger encryption and protection than WPA2.',
    category: 'Network Security'
  },
  {
    question: 'What is a man-in-the-middle attack?',
    options: [
      'A physical attack',
      'Intercepting communication between two parties',
      'A type of virus',
      'A password attack'
    ],
    correctAnswer: 1,
    explanation: 'A man-in-the-middle attack intercepts and potentially alters communication between two parties without their knowledge.',
    category: 'Network Security'
  },
  {
    question: 'What should you do with your home Wi-Fi router?',
    options: [
      'Keep the default password',
      'Change default password and enable WPA3/WPA2',
      'Leave it unsecured for guests',
      'Hide it in a closet'
    ],
    correctAnswer: 1,
    explanation: 'Always change default router passwords and use the strongest available encryption (WPA3 or WPA2).',
    category: 'Network Security'
  },
  {
    question: 'What is a rogue access point?',
    options: [
      'A broken router',
      'An unauthorized Wi-Fi access point',
      'A fast internet connection',
      'A mobile hotspot'
    ],
    correctAnswer: 1,
    explanation: 'A rogue access point is an unauthorized Wi-Fi network that attackers use to intercept traffic or distribute malware.',
    category: 'Network Security'
  },
  {
    question: 'What is HTTPS?',
    options: [
      'High-speed internet',
      'Secure version of HTTP with encryption',
      'A type of virus',
      'A web browser'
    ],
    correctAnswer: 1,
    explanation: 'HTTPS encrypts data between your browser and websites, protecting sensitive information from interception.',
    category: 'Network Security'
  },
  {
    question: 'What is DNS spoofing?',
    options: [
      'Changing DNS settings',
      'Redirecting domain names to malicious IP addresses',
      'Speeding up internet',
      'Blocking websites'
    ],
    correctAnswer: 1,
    explanation: 'DNS spoofing redirects legitimate domain names to malicious websites, often used in phishing attacks.',
    category: 'Network Security'
  },

  // Malware & Viruses (10 questions)
  {
    question: 'What is malware?',
    options: [
      'Bad software',
      'Malicious software designed to harm systems',
      'Broken software',
      'Old software'
    ],
    correctAnswer: 1,
    explanation: 'Malware is any software intentionally designed to cause damage, steal data, or gain unauthorized access to systems.',
    category: 'Malware'
  },
  {
    question: 'What is ransomware?',
    options: [
      'Software that demands payment',
      'Malware that encrypts files and demands ransom',
      'Free software',
      'Antivirus software'
    ],
    correctAnswer: 1,
    explanation: 'Ransomware encrypts your files and demands payment (usually cryptocurrency) to restore access.',
    category: 'Malware'
  },
  {
    question: 'What is a trojan horse?',
    options: [
      'A Greek myth',
      'Malware disguised as legitimate software',
      'A type of virus',
      'A security tool'
    ],
    correctAnswer: 1,
    explanation: 'A trojan horse appears legitimate but contains malicious code that executes when you run it.',
    category: 'Malware'
  },
  {
    question: 'What is spyware?',
    options: [
      'Software for spies',
      'Malware that secretly monitors and collects information',
      'Antivirus software',
      'A web browser'
    ],
    correctAnswer: 1,
    explanation: 'Spyware secretly monitors your activities and collects personal information without your knowledge.',
    category: 'Malware'
  },
  {
    question: 'What is a keylogger?',
    options: [
      'A keyboard',
      'Software that records keystrokes',
      'A password manager',
      'A typing tutor'
    ],
    correctAnswer: 1,
    explanation: 'A keylogger records every keystroke, capturing passwords, messages, and other sensitive information.',
    category: 'Malware'
  },
  {
    question: 'What is a botnet?',
    options: [
      'A robot network',
      'Network of infected computers controlled by attackers',
      'A social network',
      'An antivirus program'
    ],
    correctAnswer: 1,
    explanation: 'A botnet is a network of infected computers (bots) controlled by attackers to perform coordinated attacks.',
    category: 'Malware'
  },
  {
    question: 'What is adware?',
    options: [
      'Advertising software',
      'Software that displays unwanted advertisements',
      'Ad blocker',
      'Marketing tool'
    ],
    correctAnswer: 1,
    explanation: 'Adware displays unwanted advertisements and may track your browsing habits to target ads.',
    category: 'Malware'
  },
  {
    question: 'What is a rootkit?',
    options: [
      'Root vegetables',
      'Malware that hides deep in the system',
      'Admin tools',
      'A password'
    ],
    correctAnswer: 1,
    explanation: 'A rootkit hides deep in the operating system, giving attackers persistent access while evading detection.',
    category: 'Malware'
  },
  {
    question: 'How does malware typically spread?',
    options: [
      'Through air',
      'Email attachments, downloads, and infected websites',
      'Through water',
      'Through phone calls'
    ],
    correctAnswer: 1,
    explanation: 'Malware spreads through email attachments, malicious downloads, infected websites, and removable media.',
    category: 'Malware'
  },
  {
    question: 'What should you do if you suspect malware infection?',
    options: [
      'Ignore it',
      'Disconnect from internet and run antivirus scan',
      'Restart computer',
      'Delete all files'
    ],
    correctAnswer: 1,
    explanation: 'Disconnect from the internet to prevent data theft, then run a full antivirus scan and change passwords.',
    category: 'Malware'
  },

  // Data Privacy & Protection (7 questions)
  {
    question: 'What is encryption?',
    options: [
      'Hiding files',
      'Converting data into coded format',
      'Deleting data',
      'Backing up data'
    ],
    correctAnswer: 1,
    explanation: 'Encryption converts data into a coded format that can only be read with the correct decryption key.',
    category: 'Data Privacy'
  },
  {
    question: 'What is end-to-end encryption?',
    options: [
      'Encrypting emails',
      'Encryption where only sender and recipient can read messages',
      'Full disk encryption',
      'Password encryption'
    ],
    correctAnswer: 1,
    explanation: 'End-to-end encryption ensures only the sender and intended recipient can read the messages, not even the service provider.',
    category: 'Data Privacy'
  },
  {
    question: 'What is a data breach?',
    options: [
      'Breaking data',
      'Unauthorized access to sensitive data',
      'Data backup',
      'Data transfer'
    ],
    correctAnswer: 1,
    explanation: 'A data breach occurs when unauthorized individuals access, steal, or expose sensitive information.',
    category: 'Data Privacy'
  },
  {
    question: 'What is GDPR?',
    options: [
      'A type of malware',
      'European data protection regulation',
      'A password standard',
      'An antivirus program'
    ],
    correctAnswer: 1,
    explanation: 'GDPR (General Data Protection Regulation) is a European law protecting personal data and privacy.',
    category: 'Data Privacy'
  },
  {
    question: 'What is personally identifiable information (PII)?',
    options: [
      'Public information',
      'Information that can identify an individual',
      'Company data',
      'Encrypted data'
    ],
    correctAnswer: 1,
    explanation: 'PII is any information that can identify a specific individual, like name, address, SSN, or email.',
    category: 'Data Privacy'
  },
  {
    question: 'What is the principle of least privilege?',
    options: [
      'Giving everyone full access',
      'Granting minimum access rights necessary',
      'Removing all privileges',
      'Sharing passwords'
    ],
    correctAnswer: 1,
    explanation: 'The principle of least privilege means giving users only the minimum access rights they need to perform their job.',
    category: 'Data Privacy'
  },
  {
    question: 'What should you do before disposing of an old device?',
    options: [
      'Just throw it away',
      'Wipe all data securely',
      'Give it away as-is',
      'Remove the battery'
    ],
    correctAnswer: 1,
    explanation: 'Always securely wipe all data using specialized software before disposing of or selling devices.',
    category: 'Data Privacy'
  }
];

// Function to get random questions
function getRandomQuestions(count: number = 10): Question[] {
  const shuffled = [...allQuizQuestions].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

export function QuizCard() {
  const [quizQuestions, setQuizQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const { toast } = useToast();

  // Initialize quiz with random questions
  useEffect(() => {
    setQuizQuestions(getRandomQuestions(10));
  }, []);

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    const isCorrect = selectedAnswer === quizQuestions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
    }
    setShowResult(true);
  };

  const handleNext = async () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizCompleted(true);
      try {
        const userId = await userManager.getCurrentUserId();
        await api.quizResults.create(userId, 'cybersecurity-basics', score + (selectedAnswer === quizQuestions[currentQuestion].correctAnswer ? 1 : 0), quizQuestions.length);
        toast({
          title: 'Quiz Completed!',
          description: `Your score: ${score}/${quizQuestions.length}`,
        });
      } catch (error) {
        console.error('Failed to save quiz result:', error);
      }
    }
  };

  const handleRestart = () => {
    setQuizQuestions(getRandomQuestions(10)); // Get new random questions
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setQuizCompleted(false);
  };

  if (quizQuestions.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">Loading quiz...</p>
        </CardContent>
      </Card>
    );
  }

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;
  const currentQ = quizQuestions[currentQuestion];

  if (quizCompleted) {
    const percentage = Math.round((score / quizQuestions.length) * 100);
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-accent" />
            Quiz Complete!
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <div className="space-y-2">
            <div className="text-4xl font-bold text-primary">{percentage}%</div>
            <p className="text-lg">
              You scored {score} out of {quizQuestions.length}
            </p>
          </div>
          <div className="space-y-2">
            {percentage >= 80 && (
              <p className="text-sm text-success">Excellent! You have a strong understanding of cybersecurity basics.</p>
            )}
            {percentage >= 60 && percentage < 80 && (
              <p className="text-sm text-warning">Good job! Keep learning to improve your security knowledge.</p>
            )}
            {percentage < 60 && (
              <p className="text-sm text-destructive">Keep practicing! Review the security tips and try again.</p>
            )}
          </div>
          <Button onClick={handleRestart} className="w-full">
            Take New Quiz (Different Questions)
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Cybersecurity Quiz</CardTitle>
        <CardDescription>
          Question {currentQuestion + 1} of {quizQuestions.length} • {currentQ.category}
        </CardDescription>
        <Progress value={progress} className="mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">{currentQ.question}</h3>
          <RadioGroup
            value={selectedAnswer?.toString()}
            onValueChange={(value) => setSelectedAnswer(parseInt(value))}
            disabled={showResult}
          >
            {currentQ.options.map((option, index) => (
              <div
                key={index}
                className={`flex items-center space-x-2 rounded-lg border p-3 transition-colors ${
                  showResult
                    ? index === currentQ.correctAnswer
                      ? 'border-success bg-success/10'
                      : index === selectedAnswer
                      ? 'border-destructive bg-destructive/10'
                      : 'border-border'
                    : 'border-border hover:border-primary'
                }`}
              >
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label
                  htmlFor={`option-${index}`}
                  className="flex-1 cursor-pointer text-sm"
                >
                  {option}
                </Label>
                {showResult && index === currentQ.correctAnswer && (
                  <CheckCircle className="h-5 w-5 text-success" />
                )}
                {showResult && index === selectedAnswer && index !== currentQ.correctAnswer && (
                  <XCircle className="h-5 w-5 text-destructive" />
                )}
              </div>
            ))}
          </RadioGroup>

          {showResult && (
            <div className="rounded-lg border border-info/50 bg-info/10 p-4">
              <p className="text-sm leading-relaxed">{currentQ.explanation}</p>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          {!showResult ? (
            <Button
              onClick={handleSubmitAnswer}
              disabled={selectedAnswer === null}
              className="w-full"
            >
              Submit Answer
            </Button>
          ) : (
            <Button onClick={handleNext} className="w-full">
              {currentQuestion < quizQuestions.length - 1 ? 'Next Question' : 'Finish Quiz'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

