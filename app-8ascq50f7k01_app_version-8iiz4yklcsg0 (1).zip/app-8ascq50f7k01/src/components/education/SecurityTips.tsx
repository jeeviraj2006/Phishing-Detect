import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, Lock, Eye, Mail, Wifi, Smartphone } from 'lucide-react';

const tips = [
  {
    icon: Lock,
    title: 'Strong Passwords',
    description: 'Use unique passwords with 12+ characters, mixing letters, numbers, and symbols. Enable two-factor authentication.'
  },
  {
    icon: Eye,
    title: 'Verify Before Clicking',
    description: 'Hover over links to see the actual URL. Be suspicious of urgent requests or unexpected attachments.'
  },
  {
    icon: Mail,
    title: 'Email Safety',
    description: 'Check sender addresses carefully. Legitimate companies never ask for passwords via email.'
  },
  {
    icon: Wifi,
    title: 'Public Wi-Fi Caution',
    description: 'Avoid accessing sensitive accounts on public networks. Use a VPN for added security.'
  },
  {
    icon: Smartphone,
    title: 'Keep Software Updated',
    description: 'Install security updates promptly. They patch vulnerabilities that hackers exploit.'
  }
];

export function SecurityTips() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-accent" />
          Daily Security Tips
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {tips.map((tip, index) => {
          const Icon = tip.icon;
          return (
            <div
              key={index}
              className="flex gap-3 rounded-lg border border-border bg-card p-3 transition-all hover:shadow-md"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 space-y-1">
                <h4 className="font-semibold text-sm">{tip.title}</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {tip.description}
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
