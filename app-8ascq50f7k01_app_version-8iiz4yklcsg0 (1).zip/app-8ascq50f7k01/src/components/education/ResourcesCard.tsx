import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, ExternalLink } from 'lucide-react';

const resources = [
  {
    id: 'password-security',
    title: 'Password Security Best Practices',
    description: 'Learn how to create and manage strong passwords effectively.',
    topics: ['Password managers', 'Passphrases', 'Two-factor authentication']
  },
  {
    id: 'phishing-attacks',
    title: 'Recognizing Phishing Attacks',
    description: 'Identify common phishing tactics and protect yourself.',
    topics: ['Email spoofing', 'Suspicious links', 'Social engineering']
  },
  {
    id: 'safe-browsing',
    title: 'Safe Browsing Habits',
    description: 'Essential practices for secure internet usage.',
    topics: ['HTTPS verification', 'Cookie management', 'Privacy settings']
  },
  {
    id: 'social-media-privacy',
    title: 'Social Media Privacy',
    description: 'Protect your personal information on social platforms.',
    topics: ['Privacy controls', 'Oversharing risks', 'Account security']
  },
  {
    id: 'mobile-security',
    title: 'Mobile Device Security',
    description: 'Keep your smartphone and tablet secure.',
    topics: ['App permissions', 'Screen locks', 'Remote wipe']
  }
];

export function ResourcesCard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-secondary" />
          Learning Resources
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {resources.map((resource) => (
          <Link key={resource.id} to={`/learn/${resource.id}`}>
            <div className="group cursor-pointer rounded-lg border border-border bg-card p-4 transition-all hover:border-secondary hover:shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-2">
                  <h4 className="font-semibold text-sm group-hover:text-secondary transition-colors">
                    {resource.title}
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {resource.description}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {resource.topics.map((topic, topicIndex) => (
                      <span
                        key={topicIndex}
                        className="rounded-full bg-secondary/10 px-2 py-1 text-xs text-secondary"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
              </div>
            </div>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}
