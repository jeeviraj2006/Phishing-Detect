import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Database, AlertTriangle, CheckCircle, Shield, ExternalLink } from 'lucide-react';

interface BreachResult {
  email: string;
  isBreached: boolean;
  breachCount: number;
  breaches: Array<{
    name: string;
    date: string;
    dataTypes: string[];
    severity: 'low' | 'medium' | 'high';
  }>;
  recommendations: string[];
}

export function BreachChecker() {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<BreachResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);

  const checkBreach = (emailAddress: string): BreachResult => {
    // Simulate breach check (in production, this would call Have I Been Pwned API)
    const mockBreaches = [
      {
        name: 'LinkedIn Data Breach',
        date: '2021-06',
        dataTypes: ['Email addresses', 'Names', 'Phone numbers', 'Job titles'],
        severity: 'high' as const
      },
      {
        name: 'Adobe Security Incident',
        date: '2013-10',
        dataTypes: ['Email addresses', 'Passwords', 'Password hints'],
        severity: 'high' as const
      },
      {
        name: 'Dropbox Breach',
        date: '2012-07',
        dataTypes: ['Email addresses', 'Passwords'],
        severity: 'medium' as const
      }
    ];

    // Randomly determine if email is breached (for demo)
    const isBreached = Math.random() > 0.5;
    const breachCount = isBreached ? Math.floor(Math.random() * 3) + 1 : 0;
    const breaches = isBreached ? mockBreaches.slice(0, breachCount) : [];

    const recommendations: string[] = [];
    if (isBreached) {
      recommendations.push('Change your password immediately on all affected services');
      recommendations.push('Enable two-factor authentication (2FA) on all accounts');
      recommendations.push('Use unique passwords for each account');
      recommendations.push('Consider using a password manager');
      recommendations.push('Monitor your accounts for suspicious activity');
      recommendations.push('Check your credit report for unusual activity');
    } else {
      recommendations.push('Great! Your email hasn\'t been found in known breaches');
      recommendations.push('Continue using strong, unique passwords');
      recommendations.push('Enable 2FA on all important accounts');
      recommendations.push('Regularly check for breaches');
    }

    return {
      email: emailAddress,
      isBreached,
      breachCount,
      breaches,
      recommendations
    };
  };

  const handleCheck = () => {
    if (!email.trim() || !email.includes('@')) return;
    
    setIsChecking(true);
    setTimeout(() => {
      const breachResult = checkBreach(email);
      setResult(breachResult);
      setIsChecking(false);
    }, 1500);
  };

  const getSeverityBadge = (severity: 'low' | 'medium' | 'high') => {
    const config = {
      low: { variant: 'secondary' as const, label: 'Low Risk' },
      medium: { variant: 'secondary' as const, label: 'Medium Risk' },
      high: { variant: 'destructive' as const, label: 'High Risk' }
    };
    const { variant, label } = config[severity];
    return <Badge variant={variant}>{label}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Database className="h-5 w-5 text-primary" />
          <CardTitle>Breach Database Checker</CardTitle>
        </div>
        <CardDescription>
          Check if your email has been compromised in known data breaches
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            type="email"
            placeholder="your.email@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCheck()}
          />
          <Button onClick={handleCheck} disabled={isChecking || !email.trim()}>
            {isChecking ? 'Checking...' : 'Check'}
          </Button>
        </div>

        {result && (
          <div className="space-y-4">
            <Alert variant={result.isBreached ? 'destructive' : 'default'}>
              <div className="flex items-start gap-2">
                {result.isBreached ? (
                  <AlertTriangle className="h-5 w-5 mt-0.5" />
                ) : (
                  <CheckCircle className="h-5 w-5 mt-0.5 text-green-500" />
                )}
                <div className="flex-1">
                  <AlertDescription>
                    {result.isBreached ? (
                      <span className="font-semibold">
                        Found in {result.breachCount} breach{result.breachCount > 1 ? 'es' : ''}!
                      </span>
                    ) : (
                      <span className="font-semibold">No breaches found!</span>
                    )}
                  </AlertDescription>
                </div>
              </div>
            </Alert>

            {result.breaches.length > 0 && (
              <div className="space-y-3">
                <p className="text-sm font-medium">Affected Breaches:</p>
                {result.breaches.map((breach, index) => (
                  <div key={index} className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-medium text-sm">{breach.name}</h4>
                        <p className="text-xs text-muted-foreground">Date: {breach.date}</p>
                      </div>
                      {getSeverityBadge(breach.severity)}
                    </div>
                    <div>
                      <p className="text-xs font-medium mb-1">Compromised Data:</p>
                      <div className="flex flex-wrap gap-1">
                        {breach.dataTypes.map((type, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="rounded-lg bg-muted p-3 space-y-2">
              <p className="text-sm font-medium flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Recommendations:
              </p>
              <ul className="space-y-1 text-sm text-muted-foreground">
                {result.recommendations.map((rec, index) => (
                  <li key={index}>• {rec}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
              <p className="font-medium text-primary mb-1">ℹ️ About This Tool:</p>
              <p className="text-muted-foreground text-xs">
                This is a demonstration tool. For real breach checking, visit{' '}
                <a 
                  href="https://haveibeenpwned.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-1"
                >
                  Have I Been Pwned
                  <ExternalLink className="h-3 w-3" />
                </a>
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
