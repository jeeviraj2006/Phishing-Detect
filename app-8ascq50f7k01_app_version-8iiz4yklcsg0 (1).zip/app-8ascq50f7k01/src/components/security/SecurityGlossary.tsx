import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Search } from 'lucide-react';

interface GlossaryTerm {
  term: string;
  definition: string;
  category: 'attack' | 'defense' | 'concept' | 'tool';
  relatedTerms?: string[];
}

const glossaryTerms: GlossaryTerm[] = [
  {
    term: 'Phishing',
    definition: 'A cyber attack that uses fraudulent emails, messages, or websites to trick people into revealing sensitive information like passwords or credit card numbers.',
    category: 'attack',
    relatedTerms: ['Spear Phishing', 'Social Engineering']
  },
  {
    term: 'Malware',
    definition: 'Malicious software designed to harm, exploit, or otherwise compromise a computer system. Includes viruses, trojans, ransomware, and spyware.',
    category: 'attack',
    relatedTerms: ['Ransomware', 'Trojan', 'Virus']
  },
  {
    term: 'Two-Factor Authentication (2FA)',
    definition: 'A security process that requires two different forms of identification to access an account, typically something you know (password) and something you have (phone).',
    category: 'defense',
    relatedTerms: ['Multi-Factor Authentication', 'Authentication']
  },
  {
    term: 'Encryption',
    definition: 'The process of converting information into a code to prevent unauthorized access. Only those with the correct decryption key can read the data.',
    category: 'defense',
    relatedTerms: ['End-to-End Encryption', 'SSL/TLS']
  },
  {
    term: 'Ransomware',
    definition: 'A type of malware that encrypts a victim\'s files and demands payment (ransom) to restore access to the data.',
    category: 'attack',
    relatedTerms: ['Malware', 'Encryption']
  },
  {
    term: 'VPN (Virtual Private Network)',
    definition: 'A service that creates a secure, encrypted connection over the internet, protecting your online privacy and allowing secure access to restricted resources.',
    category: 'tool',
    relatedTerms: ['Encryption', 'Privacy']
  },
  {
    term: 'Firewall',
    definition: 'A security system that monitors and controls incoming and outgoing network traffic based on predetermined security rules.',
    category: 'defense',
    relatedTerms: ['Network Security', 'IDS']
  },
  {
    term: 'Social Engineering',
    definition: 'Psychological manipulation techniques used to trick people into divulging confidential information or performing actions that compromise security.',
    category: 'attack',
    relatedTerms: ['Phishing', 'Pretexting']
  },
  {
    term: 'Zero-Day Vulnerability',
    definition: 'A security flaw in software that is unknown to the vendor and has no patch available, making it particularly dangerous.',
    category: 'concept',
    relatedTerms: ['Vulnerability', 'Exploit']
  },
  {
    term: 'Brute Force Attack',
    definition: 'A trial-and-error method used to decode encrypted data by systematically trying all possible combinations until the correct one is found.',
    category: 'attack',
    relatedTerms: ['Password Attack', 'Encryption']
  },
  {
    term: 'SSL/TLS',
    definition: 'Security protocols that provide encrypted communication over a computer network. Websites using HTTPS employ SSL/TLS.',
    category: 'defense',
    relatedTerms: ['Encryption', 'HTTPS']
  },
  {
    term: 'DDoS Attack',
    definition: 'Distributed Denial of Service attack that overwhelms a target system with traffic from multiple sources, making it unavailable to users.',
    category: 'attack',
    relatedTerms: ['Botnet', 'Network Attack']
  },
  {
    term: 'Password Manager',
    definition: 'A tool that securely stores and manages passwords for multiple accounts, allowing users to maintain unique, strong passwords.',
    category: 'tool',
    relatedTerms: ['Password Security', 'Encryption']
  },
  {
    term: 'Spear Phishing',
    definition: 'A targeted phishing attack directed at specific individuals or organizations, using personalized information to appear more legitimate.',
    category: 'attack',
    relatedTerms: ['Phishing', 'Social Engineering']
  },
  {
    term: 'End-to-End Encryption',
    definition: 'A communication system where only the sender and recipient can read the messages, preventing intermediaries from accessing the data.',
    category: 'defense',
    relatedTerms: ['Encryption', 'Privacy']
  },
  {
    term: 'Trojan Horse',
    definition: 'Malware disguised as legitimate software that tricks users into installing it, then performs malicious actions.',
    category: 'attack',
    relatedTerms: ['Malware', 'Social Engineering']
  },
  {
    term: 'Antivirus Software',
    definition: 'A program designed to detect, prevent, and remove malware from computer systems.',
    category: 'tool',
    relatedTerms: ['Malware', 'Defense']
  },
  {
    term: 'Data Breach',
    definition: 'An incident where sensitive, protected, or confidential data is accessed, stolen, or used by unauthorized individuals.',
    category: 'concept',
    relatedTerms: ['Cybersecurity Incident', 'Data Loss']
  },
  {
    term: 'Keylogger',
    definition: 'Software or hardware that records every keystroke made on a computer, often used to steal passwords and sensitive information.',
    category: 'attack',
    relatedTerms: ['Spyware', 'Malware']
  },
  {
    term: 'Patch',
    definition: 'A software update designed to fix security vulnerabilities, bugs, or improve functionality.',
    category: 'defense',
    relatedTerms: ['Software Update', 'Vulnerability']
  }
];

export function SecurityGlossary() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTerms = glossaryTerms.filter(
    (item) =>
      item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCategoryBadge = (category: GlossaryTerm['category']) => {
    const config = {
      attack: { variant: 'destructive' as const, label: 'Attack' },
      defense: { variant: 'default' as const, label: 'Defense' },
      concept: { variant: 'secondary' as const, label: 'Concept' },
      tool: { variant: 'outline' as const, label: 'Tool' }
    };
    const { variant, label } = config[category];
    return <Badge variant={variant} className="text-xs">{label}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          <CardTitle>Security Glossary</CardTitle>
        </div>
        <CardDescription>
          Comprehensive dictionary of cybersecurity terms
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search terms..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {filteredTerms.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-8">
                No terms found matching "{searchTerm}"
              </p>
            ) : (
              filteredTerms.map((item, index) => (
                <div
                  key={index}
                  className="rounded-lg border p-4 space-y-2 hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-semibold text-lg">{item.term}</h4>
                    {getCategoryBadge(item.category)}
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.definition}
                  </p>
                  {item.relatedTerms && item.relatedTerms.length > 0 && (
                    <div className="pt-2">
                      <p className="text-xs font-medium mb-1">Related Terms:</p>
                      <div className="flex flex-wrap gap-1">
                        {item.relatedTerms.map((related, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {related}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        <div className="rounded-lg bg-muted p-3 text-sm">
          <p className="font-medium mb-1">📚 Learning Tip:</p>
          <p className="text-muted-foreground text-xs">
            Understanding these terms will help you better recognize and respond to 
            cybersecurity threats. Review this glossary regularly to reinforce your knowledge.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
