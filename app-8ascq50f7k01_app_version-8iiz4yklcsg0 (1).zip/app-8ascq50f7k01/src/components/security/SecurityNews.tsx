import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Newspaper, ExternalLink, Clock } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  category: 'breach' | 'vulnerability' | 'malware' | 'tips' | 'update';
  date: string;
  url: string;
}

const mockNews: NewsItem[] = [
  {
    id: '1',
    title: 'New Phishing Campaign Targets College Students',
    summary: 'Cybercriminals are using fake scholarship emails to steal credentials from university students.',
    category: 'breach',
    date: '2 hours ago',
    url: '#'
  },
  {
    id: '2',
    title: 'Critical Security Update for Popular Browsers',
    summary: 'Major browsers release patches for zero-day vulnerabilities. Update immediately.',
    category: 'update',
    date: '5 hours ago',
    url: '#'
  },
  {
    id: '3',
    title: 'How to Spot AI-Generated Phishing Emails',
    summary: 'Learn the telltale signs of sophisticated AI-powered phishing attempts.',
    category: 'tips',
    date: '1 day ago',
    url: '#'
  },
  {
    id: '4',
    title: 'New Ransomware Variant Discovered',
    summary: 'Security researchers identify new ransomware targeting educational institutions.',
    category: 'malware',
    date: '2 days ago',
    url: '#'
  },
  {
    id: '5',
    title: 'Social Media Privacy Settings You Should Check',
    summary: 'Essential privacy settings to protect your personal information on social platforms.',
    category: 'tips',
    date: '3 days ago',
    url: '#'
  },
  {
    id: '6',
    title: 'Major Data Breach Affects 50M Users',
    summary: 'Popular online service confirms security breach. Check if your account was affected.',
    category: 'breach',
    date: '4 days ago',
    url: '#'
  }
];

export function SecurityNews() {
  const getCategoryBadge = (category: NewsItem['category']) => {
    const config = {
      breach: { label: 'Breach', variant: 'destructive' as const },
      vulnerability: { label: 'Vulnerability', variant: 'destructive' as const },
      malware: { label: 'Malware', variant: 'destructive' as const },
      tips: { label: 'Tips', variant: 'default' as const },
      update: { label: 'Update', variant: 'secondary' as const }
    };

    const { label, variant } = config[category];
    return <Badge variant={variant} className="text-xs">{label}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Newspaper className="h-5 w-5 text-primary" />
          <CardTitle>Security News</CardTitle>
        </div>
        <CardDescription>
          Latest cybersecurity news and updates
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {mockNews.map((news) => (
              <div
                key={news.id}
                className="group rounded-lg border p-3 hover:border-primary/50 hover:bg-accent/50 transition-colors cursor-pointer"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-medium text-sm leading-tight group-hover:text-primary transition-colors">
                      {news.title}
                    </h4>
                    <ExternalLink className="h-3 w-3 text-muted-foreground shrink-0 mt-0.5" />
                  </div>
                  
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {news.summary}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    {getCategoryBadge(news.category)}
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{news.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="mt-4 rounded-lg bg-muted p-3 text-sm">
          <p className="font-medium mb-1">📰 Stay Informed</p>
          <p className="text-muted-foreground text-xs">
            Follow trusted cybersecurity news sources like Krebs on Security, 
            The Hacker News, and CISA alerts to stay updated on the latest threats.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
