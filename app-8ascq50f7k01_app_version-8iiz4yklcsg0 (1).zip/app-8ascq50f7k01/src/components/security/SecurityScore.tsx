import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Trophy, Target, TrendingUp, Award } from 'lucide-react';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';

interface SecurityScoreData {
  totalScore: number;
  level: string;
  quizzesCompleted: number;
  phishingChecks: number;
  chatSessions: number;
  achievements: string[];
}

export function SecurityScore() {
  const [scoreData, setScoreData] = useState<SecurityScoreData>({
    totalScore: 0,
    level: 'Beginner',
    quizzesCompleted: 0,
    phishingChecks: 0,
    chatSessions: 0,
    achievements: []
  });

  useEffect(() => {
    loadSecurityScore();
  }, []);

  const loadSecurityScore = async () => {
    const userId = await userManager.getCurrentUserId();
    
    // Get quiz results
    const quizResults = await api.quizResults.getByUserId(userId);
    const quizzesCompleted = quizResults.length;
    const avgScore = quizResults.length > 0 
      ? quizResults.reduce((sum, r) => sum + r.score, 0) / quizResults.length 
      : 0;

    // Get phishing detections
    const phishingDetections = await api.phishingDetections.getByUserId(userId);
    const phishingChecks = phishingDetections.length;

    // Get chat sessions
    const chatSessions = await api.chatSessions.getByUserId(userId);
    const sessionCount = chatSessions.length;

    // Calculate total score
    const quizPoints = quizzesCompleted * 10 + avgScore * 2;
    const phishingPoints = phishingChecks * 5;
    const chatPoints = sessionCount * 3;
    const totalScore = Math.min(100, Math.round(quizPoints + phishingPoints + chatPoints));

    // Determine level
    let level = 'Beginner';
    if (totalScore >= 80) level = 'Expert';
    else if (totalScore >= 60) level = 'Advanced';
    else if (totalScore >= 40) level = 'Intermediate';
    else if (totalScore >= 20) level = 'Novice';

    // Determine achievements
    const achievements: string[] = [];
    if (quizzesCompleted >= 1) achievements.push('First Quiz');
    if (quizzesCompleted >= 5) achievements.push('Quiz Master');
    if (phishingChecks >= 1) achievements.push('Phishing Hunter');
    if (phishingChecks >= 10) achievements.push('Security Analyst');
    if (sessionCount >= 5) achievements.push('Active Learner');
    if (totalScore >= 50) achievements.push('Security Aware');
    if (totalScore >= 80) achievements.push('Cyber Guardian');

    setScoreData({
      totalScore,
      level,
      quizzesCompleted,
      phishingChecks,
      chatSessions: sessionCount,
      achievements
    });
  };

  const getLevelColor = () => {
    switch (scoreData.level) {
      case 'Expert': return 'text-green-500';
      case 'Advanced': return 'text-primary';
      case 'Intermediate': return 'text-yellow-500';
      case 'Novice': return 'text-orange-500';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary" />
          <CardTitle>Security Score</CardTitle>
        </div>
        <CardDescription>
          Track your cybersecurity learning progress
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">{scoreData.totalScore}</span>
              <span className="text-sm text-muted-foreground">/ 100</span>
            </div>
            <Badge variant="outline" className={getLevelColor()}>
              {scoreData.level}
            </Badge>
          </div>
          <Progress value={scoreData.totalScore} className="h-3" />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="space-y-1 text-center">
            <div className="flex items-center justify-center">
              <Target className="h-4 w-4 text-primary" />
            </div>
            <div className="text-2xl font-bold">{scoreData.quizzesCompleted}</div>
            <div className="text-xs text-muted-foreground">Quizzes</div>
          </div>
          <div className="space-y-1 text-center">
            <div className="flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
            <div className="text-2xl font-bold">{scoreData.phishingChecks}</div>
            <div className="text-xs text-muted-foreground">Checks</div>
          </div>
          <div className="space-y-1 text-center">
            <div className="flex items-center justify-center">
              <Award className="h-4 w-4 text-primary" />
            </div>
            <div className="text-2xl font-bold">{scoreData.chatSessions}</div>
            <div className="text-xs text-muted-foreground">Sessions</div>
          </div>
        </div>

        {scoreData.achievements.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium">🏆 Achievements</p>
            <div className="flex flex-wrap gap-2">
              {scoreData.achievements.map((achievement, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {achievement}
                </Badge>
              ))}
            </div>
          </div>
        )}

        <div className="rounded-lg bg-muted p-3 text-sm">
          <p className="font-medium mb-1">💪 Keep Going!</p>
          <p className="text-muted-foreground">
            {scoreData.totalScore < 20 && 'Start by taking quizzes and chatting with the AI assistant!'}
            {scoreData.totalScore >= 20 && scoreData.totalScore < 50 && 'Great start! Keep learning about cybersecurity.'}
            {scoreData.totalScore >= 50 && scoreData.totalScore < 80 && 'Excellent progress! You\'re becoming security-aware.'}
            {scoreData.totalScore >= 80 && 'Outstanding! You\'re a cybersecurity expert!'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
