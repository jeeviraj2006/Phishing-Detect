import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Check, ChevronRight, ChevronLeft } from 'lucide-react';

interface Step {
  id: number;
  title: string;
  description: string;
  tips: string[];
}

const steps: Step[] = [
  {
    id: 1,
    title: 'What is Two-Factor Authentication?',
    description: '2FA adds an extra layer of security by requiring two forms of verification: something you know (password) and something you have (phone or security key).',
    tips: [
      'Makes your account 99.9% more secure',
      'Protects even if password is stolen',
      'Required by many organizations'
    ]
  },
  {
    id: 2,
    title: 'Choose Your 2FA Method',
    description: 'Select the most secure method available for your accounts.',
    tips: [
      '🥇 Best: Hardware security keys (YubiKey)',
      '🥈 Better: Authenticator apps (Google Authenticator, Authy)',
      '🥉 Good: SMS codes (less secure but better than nothing)',
      '❌ Avoid: Email codes (can be compromised)'
    ]
  },
  {
    id: 3,
    title: 'Set Up Authenticator App',
    description: 'Download an authenticator app and link it to your accounts.',
    tips: [
      'Download Google Authenticator or Authy',
      'Go to account security settings',
      'Scan the QR code with your app',
      'Save backup codes in a safe place',
      'Test the setup before closing settings'
    ]
  },
  {
    id: 4,
    title: 'Enable 2FA on Key Accounts',
    description: 'Prioritize enabling 2FA on your most important accounts.',
    tips: [
      '✅ Email accounts (Gmail, Outlook)',
      '✅ Banking and financial services',
      '✅ Social media accounts',
      '✅ Cloud storage (Google Drive, Dropbox)',
      '✅ University/school accounts',
      '✅ Shopping sites with saved payment info'
    ]
  },
  {
    id: 5,
    title: 'Secure Your Backup Codes',
    description: 'Store backup codes safely in case you lose access to your 2FA device.',
    tips: [
      'Print codes and store in a safe place',
      'Use a password manager to store codes',
      'Never share codes with anyone',
      'Generate new codes if compromised',
      'Keep codes separate from your device'
    ]
  }
];

export function TwoFactorGuide() {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const step = steps[currentStep];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Smartphone className="h-5 w-5 text-primary" />
          <CardTitle>Two-Factor Authentication Guide</CardTitle>
        </div>
        <CardDescription>
          Learn how to secure your accounts with 2FA
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Badge variant="outline">
            Step {step.id} of {steps.length}
          </Badge>
          <div className="flex gap-1">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 w-2 rounded-full transition-colors ${
                  index === currentStep ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-lg font-semibold">{step.title}</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {step.description}
          </p>

          <div className="rounded-lg bg-muted p-4 space-y-2">
            {step.tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-2 text-sm">
                <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span>{tip}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrevious}
            disabled={currentStep === 0}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Previous
          </Button>
          <Button
            size="sm"
            onClick={handleNext}
            disabled={currentStep === steps.length - 1}
          >
            Next
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        {currentStep === steps.length - 1 && (
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
            <p className="font-medium text-primary mb-1">🎉 Congratulations!</p>
            <p className="text-muted-foreground">
              You now know how to set up 2FA! Start enabling it on your most important 
              accounts today to significantly improve your security.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
