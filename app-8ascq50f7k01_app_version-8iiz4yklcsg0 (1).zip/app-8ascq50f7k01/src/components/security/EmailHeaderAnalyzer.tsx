import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Mail, CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-react';

interface AnalysisResult {
  isLegitimate: boolean;
  riskLevel: 'safe' | 'suspicious' | 'dangerous';
  findings: Array<{
    type: 'positive' | 'warning' | 'danger';
    message: string;
  }>;
  recommendations: string[];
}

export function EmailHeaderAnalyzer() {
  const [headers, setHeaders] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeHeaders = (headerText: string): AnalysisResult => {
    const findings: AnalysisResult['findings'] = [];
    let riskScore = 0;

    // Check for SPF
    if (headerText.toLowerCase().includes('spf=pass')) {
      findings.push({
        type: 'positive',
        message: 'SPF authentication passed - sender domain is verified'
      });
    } else if (headerText.toLowerCase().includes('spf=fail')) {
      findings.push({
        type: 'danger',
        message: 'SPF authentication failed - sender may be spoofed'
      });
      riskScore += 30;
    }

    // Check for DKIM
    if (headerText.toLowerCase().includes('dkim=pass')) {
      findings.push({
        type: 'positive',
        message: 'DKIM signature valid - email content is authentic'
      });
    } else if (headerText.toLowerCase().includes('dkim=fail')) {
      findings.push({
        type: 'danger',
        message: 'DKIM signature failed - email may be tampered'
      });
      riskScore += 30;
    }

    // Check for DMARC
    if (headerText.toLowerCase().includes('dmarc=pass')) {
      findings.push({
        type: 'positive',
        message: 'DMARC policy passed - strong authentication'
      });
    } else if (headerText.toLowerCase().includes('dmarc=fail')) {
      findings.push({
        type: 'warning',
        message: 'DMARC policy failed - proceed with caution'
      });
      riskScore += 20;
    }

    // Check for suspicious patterns
    if (headerText.match(/received:.*\[(\d+\.){3}\d+\]/gi)) {
      const ipMatches = headerText.match(/\[(\d+\.){3}\d+\]/g);
      if (ipMatches && ipMatches.length > 5) {
        findings.push({
          type: 'warning',
          message: 'Multiple server hops detected - unusual routing'
        });
        riskScore += 15;
      }
    }

    // Check for mismatched domains
    const fromMatch = headerText.match(/from:.*?<(.+?)>/i);
    const returnPathMatch = headerText.match(/return-path:.*?<(.+?)>/i);
    if (fromMatch && returnPathMatch) {
      const fromDomain = fromMatch[1].split('@')[1];
      const returnDomain = returnPathMatch[1].split('@')[1];
      if (fromDomain !== returnDomain) {
        findings.push({
          type: 'warning',
          message: 'From address and Return-Path domains don\'t match'
        });
        riskScore += 20;
      }
    }

    // Check for suspicious keywords
    const suspiciousKeywords = ['urgent', 'verify', 'suspended', 'confirm', 'click here'];
    const subjectMatch = headerText.match(/subject:(.*)/i);
    if (subjectMatch) {
      const subject = subjectMatch[1].toLowerCase();
      const foundKeywords = suspiciousKeywords.filter(kw => subject.includes(kw));
      if (foundKeywords.length > 0) {
        findings.push({
          type: 'warning',
          message: `Subject contains suspicious keywords: ${foundKeywords.join(', ')}`
        });
        riskScore += 10;
      }
    }

    // If no findings, add default message
    if (findings.length === 0) {
      findings.push({
        type: 'warning',
        message: 'Unable to extract authentication information from headers'
      });
      riskScore += 25;
    }

    // Determine risk level
    let riskLevel: AnalysisResult['riskLevel'];
    if (riskScore === 0) riskLevel = 'safe';
    else if (riskScore < 40) riskLevel = 'suspicious';
    else riskLevel = 'dangerous';

    // Generate recommendations
    const recommendations: string[] = [];
    if (riskLevel === 'dangerous') {
      recommendations.push('Do not click any links or download attachments');
      recommendations.push('Report this email as phishing');
      recommendations.push('Delete the email immediately');
      recommendations.push('Contact the supposed sender through official channels');
    } else if (riskLevel === 'suspicious') {
      recommendations.push('Verify the sender through another channel');
      recommendations.push('Be cautious with links and attachments');
      recommendations.push('Look for other signs of phishing');
      recommendations.push('When in doubt, don\'t interact with the email');
    } else {
      recommendations.push('Email appears legitimate based on authentication');
      recommendations.push('Still verify unexpected requests');
      recommendations.push('Use caution with sensitive information');
    }

    return {
      isLegitimate: riskLevel === 'safe',
      riskLevel,
      findings,
      recommendations
    };
  };

  const handleAnalyze = () => {
    if (!headers.trim()) return;

    setIsAnalyzing(true);
    setTimeout(() => {
      const analysisResult = analyzeHeaders(headers);
      setResult(analysisResult);
      setIsAnalyzing(false);
    }, 1000);
  };

  const getRiskBadge = () => {
    if (!result) return null;

    const config = {
      safe: { variant: 'default' as const, icon: CheckCircle, label: 'Safe', color: 'text-green-500' },
      suspicious: { variant: 'secondary' as const, icon: AlertTriangle, label: 'Suspicious', color: 'text-yellow-500' },
      dangerous: { variant: 'destructive' as const, icon: XCircle, label: 'Dangerous', color: 'text-destructive' }
    };

    const { variant, icon: Icon, label, color } = config[result.riskLevel];

    return (
      <Badge variant={variant} className="gap-1">
        <Icon className={`h-3 w-3 ${color}`} />
        {label}
      </Badge>
    );
  };

  const getIcon = (type: 'positive' | 'warning' | 'danger') => {
    switch (type) {
      case 'positive':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'danger':
        return <XCircle className="h-4 w-4 text-destructive" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Mail className="h-5 w-5 text-primary" />
          <CardTitle>Email Header Analyzer</CardTitle>
        </div>
        <CardDescription>
          Analyze email headers to verify authenticity and detect spoofing
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Textarea
            placeholder="Paste email headers here...

Example headers include:
From: sender@example.com
To: you@example.com
Subject: Important Message
Received: from mail.example.com
SPF: pass
DKIM: pass
DMARC: pass"
            value={headers}
            onChange={(e) => setHeaders(e.target.value)}
            rows={8}
            className="font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">
            Paste the full email headers (View → Show Original in most email clients)
          </p>
        </div>

        <Button onClick={handleAnalyze} disabled={isAnalyzing || !headers.trim()} className="w-full">
          {isAnalyzing ? 'Analyzing...' : 'Analyze Headers'}
        </Button>

        {result && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Analysis Result</span>
              {getRiskBadge()}
            </div>

            <Alert variant={result.riskLevel === 'dangerous' ? 'destructive' : 'default'}>
              <Info className="h-4 w-4" />
              <AlertDescription>
                {result.riskLevel === 'safe' && 'This email appears to be legitimate based on authentication checks.'}
                {result.riskLevel === 'suspicious' && 'This email shows some suspicious characteristics. Proceed with caution.'}
                {result.riskLevel === 'dangerous' && 'This email shows multiple red flags. Do not interact with it.'}
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <p className="text-sm font-medium">Findings:</p>
              <div className="space-y-2">
                {result.findings.map((finding, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm">
                    {getIcon(finding.type)}
                    <span className="text-muted-foreground">{finding.message}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-lg bg-muted p-3 space-y-2">
              <p className="text-sm font-medium">📋 Recommendations:</p>
              <ul className="space-y-1 text-xs text-muted-foreground">
                {result.recommendations.map((rec, index) => (
                  <li key={index}>• {rec}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
              <p className="font-medium text-primary mb-1">ℹ️ Understanding Email Authentication:</p>
              <ul className="space-y-1 text-xs text-muted-foreground">
                <li>• <strong>SPF</strong>: Verifies the sender's mail server is authorized</li>
                <li>• <strong>DKIM</strong>: Confirms the email content hasn't been tampered with</li>
                <li>• <strong>DMARC</strong>: Combines SPF and DKIM for stronger authentication</li>
              </ul>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
