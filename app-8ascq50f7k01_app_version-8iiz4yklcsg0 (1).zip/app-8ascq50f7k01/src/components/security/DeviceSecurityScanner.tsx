import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Smartphone, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

interface SecurityCheck {
  id: string;
  category: 'critical' | 'important' | 'recommended';
  question: string;
  description: string;
  tip: string;
}

const securityChecks: SecurityCheck[] = [
  {
    id: 'os-updated',
    category: 'critical',
    question: 'Is your operating system up to date?',
    description: 'Latest OS version with security patches installed',
    tip: 'Check Settings → System → Software Update'
  },
  {
    id: 'screen-lock',
    category: 'critical',
    question: 'Do you have a screen lock enabled?',
    description: 'PIN, password, fingerprint, or face recognition',
    tip: 'Settings → Security → Screen Lock'
  },
  {
    id: 'antivirus',
    category: 'critical',
    question: 'Is antivirus software installed and active?',
    description: 'Real-time protection against malware',
    tip: 'Use Windows Defender, Malwarebytes, or similar'
  },
  {
    id: 'firewall',
    category: 'critical',
    question: 'Is your firewall enabled?',
    description: 'Blocks unauthorized network access',
    tip: 'Settings → Security → Firewall'
  },
  {
    id: 'auto-updates',
    category: 'important',
    question: 'Are automatic updates enabled?',
    description: 'Apps and system update automatically',
    tip: 'Enable in system settings and app stores'
  },
  {
    id: 'strong-password',
    category: 'critical',
    question: 'Do you use strong, unique passwords?',
    description: 'Different passwords for each account',
    tip: 'Use a password manager like Bitwarden or 1Password'
  },
  {
    id: '2fa-enabled',
    category: 'critical',
    question: 'Is 2FA enabled on important accounts?',
    description: 'Two-factor authentication adds extra security',
    tip: 'Enable on email, banking, and social media'
  },
  {
    id: 'backup',
    category: 'important',
    question: 'Do you regularly backup your data?',
    description: 'Recent backup of important files',
    tip: 'Use cloud storage or external drives'
  },
  {
    id: 'wifi-secure',
    category: 'important',
    question: 'Is your Wi-Fi network secured?',
    description: 'WPA3 or WPA2 encryption with strong password',
    tip: 'Change default router password'
  },
  {
    id: 'bluetooth-off',
    category: 'recommended',
    question: 'Do you turn off Bluetooth when not in use?',
    description: 'Reduces attack surface',
    tip: 'Disable in quick settings when not needed'
  },
  {
    id: 'app-permissions',
    category: 'important',
    question: 'Have you reviewed app permissions?',
    description: 'Apps only have necessary access',
    tip: 'Settings → Privacy → App Permissions'
  },
  {
    id: 'browser-updated',
    category: 'important',
    question: 'Is your web browser up to date?',
    description: 'Latest browser version installed',
    tip: 'Check browser settings for updates'
  },
  {
    id: 'vpn-available',
    category: 'recommended',
    question: 'Do you use a VPN on public Wi-Fi?',
    description: 'Encrypts your internet connection',
    tip: 'Use reputable VPN services'
  },
  {
    id: 'email-verified',
    category: 'recommended',
    question: 'Do you verify suspicious emails?',
    description: 'Check sender before clicking links',
    tip: 'Hover over links to see real destination'
  },
  {
    id: 'downloads-careful',
    category: 'important',
    question: 'Are you careful with downloads?',
    description: 'Only download from trusted sources',
    tip: 'Scan downloads with antivirus'
  }
];

export function DeviceSecurityScanner() {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());
  const [showResults, setShowResults] = useState(false);

  const toggleCheck = (id: string) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(id)) {
      newChecked.delete(id);
    } else {
      newChecked.add(id);
    }
    setCheckedItems(newChecked);
  };

  const calculateScore = () => {
    const criticalChecks = securityChecks.filter(c => c.category === 'critical');
    const importantChecks = securityChecks.filter(c => c.category === 'important');
    const recommendedChecks = securityChecks.filter(c => c.category === 'recommended');

    const criticalScore = criticalChecks.filter(c => checkedItems.has(c.id)).length / criticalChecks.length;
    const importantScore = importantChecks.filter(c => checkedItems.has(c.id)).length / importantChecks.length;
    const recommendedScore = recommendedChecks.filter(c => checkedItems.has(c.id)).length / recommendedChecks.length;

    // Weighted score: critical 50%, important 30%, recommended 20%
    return Math.round((criticalScore * 50 + importantScore * 30 + recommendedScore * 20));
  };

  const handleScan = () => {
    setShowResults(true);
  };

  const handleReset = () => {
    setCheckedItems(new Set());
    setShowResults(false);
  };

  const score = calculateScore();
  const criticalMissing = securityChecks
    .filter(c => c.category === 'critical' && !checkedItems.has(c.id))
    .length;

  const getScoreStatus = () => {
    if (score >= 80) return { icon: CheckCircle2, color: 'text-green-500', label: 'Excellent', message: 'Your device security is strong!' };
    if (score >= 60) return { icon: AlertTriangle, color: 'text-yellow-500', label: 'Good', message: 'Your device is fairly secure, but there\'s room for improvement.' };
    return { icon: XCircle, color: 'text-destructive', label: 'Needs Improvement', message: 'Your device has security vulnerabilities that need attention.' };
  };

  const getCategoryBadge = (category: SecurityCheck['category']) => {
    const config = {
      critical: { variant: 'destructive' as const, label: 'Critical' },
      important: { variant: 'secondary' as const, label: 'Important' },
      recommended: { variant: 'outline' as const, label: 'Recommended' }
    };
    const { variant, label } = config[category];
    return <Badge variant={variant} className="text-xs">{label}</Badge>;
  };

  if (showResults) {
    const status = getScoreStatus();
    const StatusIcon = status.icon;

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Smartphone className="h-5 w-5 text-primary" />
            <CardTitle>Security Scan Results</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center">
              <StatusIcon className={`h-16 w-16 ${status.color}`} />
            </div>
            <div>
              <h3 className="text-2xl font-bold">{score}%</h3>
              <p className="text-lg font-medium">{status.label}</p>
              <p className="text-sm text-muted-foreground mt-2">{status.message}</p>
            </div>
          </div>

          <div className="space-y-2">
            <Progress value={score} className="h-3" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Security Score</span>
              <span>{checkedItems.size} / {securityChecks.length} checks passed</span>
            </div>
          </div>

          {criticalMissing > 0 && (
            <div className="rounded-lg border border-destructive bg-destructive/10 p-4">
              <p className="font-medium text-destructive mb-2">
                ⚠️ {criticalMissing} Critical Security Issue{criticalMissing > 1 ? 's' : ''}
              </p>
              <p className="text-sm text-muted-foreground">
                Address these critical issues immediately to protect your device.
              </p>
            </div>
          )}

          <div className="space-y-2">
            <p className="font-medium text-sm">Priority Actions:</p>
            <div className="space-y-2">
              {securityChecks
                .filter(check => !checkedItems.has(check.id))
                .sort((a, b) => {
                  const order = { critical: 0, important: 1, recommended: 2 };
                  return order[a.category] - order[b.category];
                })
                .slice(0, 5)
                .map((check) => (
                  <div key={check.id} className="rounded-lg border p-3 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-medium">{check.question}</p>
                      {getCategoryBadge(check.category)}
                    </div>
                    <p className="text-xs text-muted-foreground">{check.tip}</p>
                  </div>
                ))}
            </div>
          </div>

          <Button onClick={handleReset} variant="outline" className="w-full">
            Scan Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Smartphone className="h-5 w-5 text-primary" />
          <CardTitle>Device Security Scanner</CardTitle>
        </div>
        <CardDescription>
          Check your device security with this comprehensive checklist
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-lg bg-muted p-3 text-sm">
          <p className="font-medium mb-1">📱 How to use:</p>
          <p className="text-muted-foreground text-xs">
            Check each item that applies to your device. Be honest for an accurate security assessment.
          </p>
        </div>

        <div className="space-y-3">
          {securityChecks.map((check) => (
            <div
              key={check.id}
              className="flex items-start gap-3 rounded-lg border p-3 hover:bg-accent/50 transition-colors"
            >
              <Checkbox
                id={check.id}
                checked={checkedItems.has(check.id)}
                onCheckedChange={() => toggleCheck(check.id)}
                className="mt-1"
              />
              <div className="flex-1 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <Label htmlFor={check.id} className="cursor-pointer font-medium text-sm">
                    {check.question}
                  </Label>
                  {getCategoryBadge(check.category)}
                </div>
                <p className="text-xs text-muted-foreground">{check.description}</p>
                <p className="text-xs text-primary">💡 {check.tip}</p>
              </div>
            </div>
          ))}
        </div>

        <Button onClick={handleScan} className="w-full">
          Analyze Security ({checkedItems.size}/{securityChecks.length})
        </Button>
      </CardContent>
    </Card>
  );
}
