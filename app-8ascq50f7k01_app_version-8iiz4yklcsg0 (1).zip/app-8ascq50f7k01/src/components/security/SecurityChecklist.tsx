import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ClipboardCheck, Calendar, TrendingUp } from 'lucide-react';

interface ChecklistItem {
  id: string;
  task: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
}

const dailyTasks: ChecklistItem[] = [
  {
    id: 'd1',
    task: 'Check for suspicious emails',
    description: 'Review your inbox for phishing attempts',
    priority: 'high'
  },
  {
    id: 'd2',
    task: 'Verify recent account activity',
    description: 'Check login history on important accounts',
    priority: 'high'
  },
  {
    id: 'd3',
    task: 'Update antivirus definitions',
    description: 'Ensure your antivirus is up to date',
    priority: 'medium'
  },
  {
    id: 'd4',
    task: 'Lock your devices when away',
    description: 'Always lock screen when leaving your device',
    priority: 'high'
  },
  {
    id: 'd5',
    task: 'Use secure connections',
    description: 'Avoid public Wi-Fi for sensitive tasks',
    priority: 'medium'
  }
];

const weeklyTasks: ChecklistItem[] = [
  {
    id: 'w1',
    task: 'Review app permissions',
    description: 'Check what data apps can access',
    priority: 'high'
  },
  {
    id: 'w2',
    task: 'Update software and apps',
    description: 'Install security patches and updates',
    priority: 'high'
  },
  {
    id: 'w3',
    task: 'Backup important data',
    description: 'Create backups of critical files',
    priority: 'high'
  },
  {
    id: 'w4',
    task: 'Review privacy settings',
    description: 'Check social media and account privacy',
    priority: 'medium'
  },
  {
    id: 'w5',
    task: 'Clear browser cache and cookies',
    description: 'Remove tracking data from browsers',
    priority: 'low'
  },
  {
    id: 'w6',
    task: 'Check credit card statements',
    description: 'Look for unauthorized transactions',
    priority: 'high'
  }
];

const monthlyTasks: ChecklistItem[] = [
  {
    id: 'm1',
    task: 'Change important passwords',
    description: 'Rotate passwords for critical accounts',
    priority: 'high'
  },
  {
    id: 'm2',
    task: 'Review connected devices',
    description: 'Remove old or unused device connections',
    priority: 'medium'
  },
  {
    id: 'm3',
    task: 'Check for data breaches',
    description: 'Use breach checker tools',
    priority: 'high'
  },
  {
    id: 'm4',
    task: 'Review and delete old accounts',
    description: 'Close unused online accounts',
    priority: 'medium'
  },
  {
    id: 'm5',
    task: 'Test backup restoration',
    description: 'Verify your backups work correctly',
    priority: 'high'
  },
  {
    id: 'm6',
    task: 'Security awareness training',
    description: 'Complete a security training module',
    priority: 'medium'
  }
];

export function SecurityChecklist() {
  const [dailyChecked, setDailyChecked] = useState<Set<string>>(new Set());
  const [weeklyChecked, setWeeklyChecked] = useState<Set<string>>(new Set());
  const [monthlyChecked, setMonthlyChecked] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Load from localStorage
    const daily = localStorage.getItem('security-checklist-daily');
    const weekly = localStorage.getItem('security-checklist-weekly');
    const monthly = localStorage.getItem('security-checklist-monthly');

    if (daily) setDailyChecked(new Set(JSON.parse(daily)));
    if (weekly) setWeeklyChecked(new Set(JSON.parse(weekly)));
    if (monthly) setMonthlyChecked(new Set(JSON.parse(monthly)));
  }, []);

  const toggleTask = (taskId: string, type: 'daily' | 'weekly' | 'monthly') => {
    const setters = {
      daily: setDailyChecked,
      weekly: setWeeklyChecked,
      monthly: setMonthlyChecked
    };

    const sets = {
      daily: dailyChecked,
      weekly: weeklyChecked,
      monthly: monthlyChecked
    };

    const currentSet = new Set(sets[type]);
    if (currentSet.has(taskId)) {
      currentSet.delete(taskId);
    } else {
      currentSet.add(taskId);
    }

    setters[type](currentSet);
    localStorage.setItem(`security-checklist-${type}`, JSON.stringify([...currentSet]));
  };

  const getProgress = (checked: Set<string>, total: number) => {
    return (checked.size / total) * 100;
  };

  const getPriorityBadge = (priority: ChecklistItem['priority']) => {
    const config = {
      high: { variant: 'destructive' as const, label: 'High' },
      medium: { variant: 'secondary' as const, label: 'Medium' },
      low: { variant: 'outline' as const, label: 'Low' }
    };
    const { variant, label } = config[priority];
    return <Badge variant={variant} className="text-xs">{label}</Badge>;
  };

  const renderChecklist = (
    tasks: ChecklistItem[],
    checked: Set<string>,
    type: 'daily' | 'weekly' | 'monthly'
  ) => (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Progress</span>
          <span className="text-muted-foreground">
            {checked.size} / {tasks.length} completed
          </span>
        </div>
        <Progress value={getProgress(checked, tasks.length)} />
      </div>

      <div className="space-y-2">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="flex items-start gap-3 rounded-lg border p-3 hover:bg-accent/50 transition-colors"
          >
            <Checkbox
              id={task.id}
              checked={checked.has(task.id)}
              onCheckedChange={() => toggleTask(task.id, type)}
              className="mt-1"
            />
            <div className="flex-1 space-y-1">
              <div className="flex items-start justify-between gap-2">
                <label
                  htmlFor={task.id}
                  className={`text-sm font-medium cursor-pointer ${
                    checked.has(task.id) ? 'line-through text-muted-foreground' : ''
                  }`}
                >
                  {task.task}
                </label>
                {getPriorityBadge(task.priority)}
              </div>
              <p className="text-xs text-muted-foreground">{task.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <ClipboardCheck className="h-5 w-5 text-primary" />
          <CardTitle>Security Checklist</CardTitle>
        </div>
        <CardDescription>
          Track your daily, weekly, and monthly security tasks
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="daily" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="daily" className="gap-1 text-xs">
              <Calendar className="h-3 w-3" />
              Daily
            </TabsTrigger>
            <TabsTrigger value="weekly" className="gap-1 text-xs">
              <TrendingUp className="h-3 w-3" />
              Weekly
            </TabsTrigger>
            <TabsTrigger value="monthly" className="gap-1 text-xs">
              <ClipboardCheck className="h-3 w-3" />
              Monthly
            </TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="mt-4">
            {renderChecklist(dailyTasks, dailyChecked, 'daily')}
          </TabsContent>

          <TabsContent value="weekly" className="mt-4">
            {renderChecklist(weeklyTasks, weeklyChecked, 'weekly')}
          </TabsContent>

          <TabsContent value="monthly" className="mt-4">
            {renderChecklist(monthlyTasks, monthlyChecked, 'monthly')}
          </TabsContent>
        </Tabs>

        <div className="mt-4 rounded-lg bg-muted p-3 text-sm">
          <p className="font-medium mb-1">💡 Pro Tip:</p>
          <p className="text-muted-foreground text-xs">
            Set reminders on your phone to complete these tasks regularly. 
            Consistent security habits are the best defense against cyber threats.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
