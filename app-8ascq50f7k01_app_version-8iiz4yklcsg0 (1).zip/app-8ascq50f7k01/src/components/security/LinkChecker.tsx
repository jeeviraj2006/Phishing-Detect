import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link2, Shield, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface LinkAnalysis {
  url: string;
  isSafe: boolean;
  risk: 'safe' | 'suspicious' | 'dangerous';
  warnings: string[];
  recommendations: string[];
}

export function LinkChecker() {
  const [url, setUrl] = useState('');
  const [analysis, setAnalysis] = useState<LinkAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeLink = (link: string): LinkAnalysis => {
    const warnings: string[] = [];
    const recommendations: string[] = [];
    let riskScore = 0;

    try {
      const urlObj = new URL(link);

      // Check protocol
      if (urlObj.protocol !== 'https:') {
        warnings.push('Not using secure HTTPS protocol');
        riskScore += 30;
      }

      // Check for suspicious TLDs
      const suspiciousTLDs = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top'];
      if (suspiciousTLDs.some(tld => urlObj.hostname.endsWith(tld))) {
        warnings.push('Using a suspicious top-level domain');
        riskScore += 25;
      }

      // Check for IP address instead of domain
      if (/^\d+\.\d+\.\d+\.\d+$/.test(urlObj.hostname)) {
        warnings.push('Using IP address instead of domain name');
        riskScore += 35;
      }

      // Check for excessive subdomains
      const subdomains = urlObj.hostname.split('.');
      if (subdomains.length > 4) {
        warnings.push('Unusually long domain with many subdomains');
        riskScore += 20;
      }

      // Check for suspicious keywords
      const suspiciousKeywords = ['login', 'verify', 'account', 'secure', 'update', 'confirm', 'banking'];
      const hasKeyword = suspiciousKeywords.some(keyword => 
        urlObj.hostname.toLowerCase().includes(keyword) || urlObj.pathname.toLowerCase().includes(keyword)
      );
      if (hasKeyword) {
        warnings.push('Contains keywords commonly used in phishing (login, verify, etc.)');
        riskScore += 15;
      }

      // Check for URL shorteners
      const shorteners = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly'];
      if (shorteners.some(shortener => urlObj.hostname.includes(shortener))) {
        warnings.push('URL shortener detected - destination is hidden');
        riskScore += 20;
      }

      // Check for unusual characters
      if (/[^\x00-\x7F]/.test(urlObj.hostname)) {
        warnings.push('Contains non-ASCII characters (possible homograph attack)');
        riskScore += 40;
      }

      // Check for @ symbol (can hide real domain)
      if (link.includes('@')) {
        warnings.push('Contains @ symbol which can hide the real destination');
        riskScore += 35;
      }

      // Provide recommendations
      if (riskScore === 0) {
        recommendations.push('This URL appears safe based on basic checks');
        recommendations.push('Always verify the sender before clicking links');
      } else {
        recommendations.push('Be cautious when visiting this link');
        recommendations.push('Verify the link with the sender through another channel');
        recommendations.push('Use a link preview service before visiting');
        recommendations.push('Consider using a virtual machine or sandbox');
      }

      // Determine risk level
      let risk: LinkAnalysis['risk'];
      if (riskScore === 0) risk = 'safe';
      else if (riskScore < 50) risk = 'suspicious';
      else risk = 'dangerous';

      return {
        url: link,
        isSafe: riskScore === 0,
        risk,
        warnings: warnings.length > 0 ? warnings : ['No obvious red flags detected'],
        recommendations
      };
    } catch {
      return {
        url: link,
        isSafe: false,
        risk: 'dangerous',
        warnings: ['Invalid URL format'],
        recommendations: ['Enter a valid URL starting with http:// or https://']
      };
    }
  };

  const handleAnalyze = () => {
    if (!url.trim()) return;
    
    setIsAnalyzing(true);
    setTimeout(() => {
      const result = analyzeLink(url);
      setAnalysis(result);
      setIsAnalyzing(false);
    }, 500);
  };

  const getRiskBadge = () => {
    if (!analysis) return null;

    const config = {
      safe: { variant: 'default' as const, icon: CheckCircle, color: 'text-green-500' },
      suspicious: { variant: 'secondary' as const, icon: AlertTriangle, color: 'text-yellow-500' },
      dangerous: { variant: 'destructive' as const, icon: XCircle, color: 'text-destructive' }
    };

    const { variant, icon: Icon, color } = config[analysis.risk];

    return (
      <Badge variant={variant} className="gap-1">
        <Icon className={`h-3 w-3 ${color}`} />
        {analysis.risk.toUpperCase()}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Link2 className="h-5 w-5 text-primary" />
          <CardTitle>Safe Link Checker</CardTitle>
        </div>
        <CardDescription>
          Analyze URLs for potential security risks before clicking
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            type="url"
            placeholder="https://example.com"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
            className="font-mono text-sm"
          />
          <Button onClick={handleAnalyze} disabled={isAnalyzing || !url.trim()}>
            {isAnalyzing ? 'Analyzing...' : 'Check'}
          </Button>
        </div>

        {analysis && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Risk Assessment</span>
              {getRiskBadge()}
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Analysis Results:</p>
              <ul className="space-y-1">
                {analysis.warnings.map((warning, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    {analysis.isSafe ? (
                      <Shield className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 shrink-0" />
                    )}
                    <span className="text-muted-foreground">{warning}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg bg-muted p-3 text-sm space-y-2">
              <p className="font-medium">🛡️ Recommendations:</p>
              <ul className="space-y-1 text-muted-foreground">
                {analysis.recommendations.map((rec, index) => (
                  <li key={index}>• {rec}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
              <p className="font-medium text-primary mb-1">⚠️ Important Note:</p>
              <p className="text-muted-foreground">
                This is a basic analysis tool. For comprehensive security checks, use professional 
                services like VirusTotal or Google Safe Browsing.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
