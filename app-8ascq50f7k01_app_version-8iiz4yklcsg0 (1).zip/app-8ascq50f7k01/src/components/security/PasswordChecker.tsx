import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Shield, Check, X, AlertTriangle } from 'lucide-react';

interface PasswordStrength {
  score: number;
  feedback: string[];
  strength: 'weak' | 'fair' | 'good' | 'strong' | 'very-strong';
}

export function PasswordChecker() {
  const [password, setPassword] = useState('');
  const [strength, setStrength] = useState<PasswordStrength | null>(null);

  const analyzePassword = (pwd: string): PasswordStrength => {
    let score = 0;
    const feedback: string[] = [];

    if (pwd.length === 0) {
      return { score: 0, feedback: ['Enter a password to check its strength'], strength: 'weak' };
    }

    // Length check
    if (pwd.length >= 8) {
      score += 20;
    } else {
      feedback.push('Use at least 8 characters');
    }

    if (pwd.length >= 12) {
      score += 10;
    }

    if (pwd.length >= 16) {
      score += 10;
    }

    // Uppercase check
    if (/[A-Z]/.test(pwd)) {
      score += 15;
    } else {
      feedback.push('Add uppercase letters (A-Z)');
    }

    // Lowercase check
    if (/[a-z]/.test(pwd)) {
      score += 15;
    } else {
      feedback.push('Add lowercase letters (a-z)');
    }

    // Number check
    if (/\d/.test(pwd)) {
      score += 15;
    } else {
      feedback.push('Add numbers (0-9)');
    }

    // Special character check
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd)) {
      score += 15;
    } else {
      feedback.push('Add special characters (!@#$%^&*)');
    }

    // No common patterns
    const commonPatterns = ['123', 'abc', 'password', 'qwerty', '111', '000'];
    const hasCommonPattern = commonPatterns.some(pattern => pwd.toLowerCase().includes(pattern));
    if (!hasCommonPattern) {
      score += 10;
    } else {
      feedback.push('Avoid common patterns like "123" or "password"');
    }

    // Determine strength level
    let strengthLevel: PasswordStrength['strength'];
    if (score < 30) strengthLevel = 'weak';
    else if (score < 50) strengthLevel = 'fair';
    else if (score < 70) strengthLevel = 'good';
    else if (score < 90) strengthLevel = 'strong';
    else strengthLevel = 'very-strong';

    if (feedback.length === 0) {
      feedback.push('Excellent! Your password is very strong');
    }

    return { score, feedback, strength: strengthLevel };
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);
    setStrength(analyzePassword(value));
  };

  const getStrengthColor = () => {
    if (!strength) return 'bg-muted';
    switch (strength.strength) {
      case 'weak': return 'bg-destructive';
      case 'fair': return 'bg-orange-500';
      case 'good': return 'bg-yellow-500';
      case 'strong': return 'bg-primary';
      case 'very-strong': return 'bg-green-500';
      default: return 'bg-muted';
    }
  };

  const getStrengthBadge = () => {
    if (!strength || password.length === 0) return null;
    
    const variants: Record<string, 'destructive' | 'secondary' | 'default'> = {
      'weak': 'destructive',
      'fair': 'secondary',
      'good': 'secondary',
      'strong': 'default',
      'very-strong': 'default'
    };

    return (
      <Badge variant={variants[strength.strength] || 'secondary'} className="ml-2">
        {strength.strength.replace('-', ' ').toUpperCase()}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <CardTitle>Password Strength Checker</CardTitle>
        </div>
        <CardDescription>
          Test your password strength and get instant feedback
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Enter Password</label>
            {getStrengthBadge()}
          </div>
          <Input
            type="password"
            placeholder="Type your password here..."
            value={password}
            onChange={(e) => handlePasswordChange(e.target.value)}
            className="font-mono"
          />
        </div>

        {strength && password.length > 0 && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Strength Score</span>
                <span className="font-semibold">{strength.score}/100</span>
              </div>
              <Progress value={strength.score} className={getStrengthColor()} />
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Recommendations:</p>
              <ul className="space-y-1">
                {strength.feedback.map((item, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    {strength.score >= 90 ? (
                      <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    ) : strength.score >= 50 ? (
                      <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 shrink-0" />
                    ) : (
                      <X className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
                    )}
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg bg-muted p-3 text-sm">
              <p className="font-medium mb-1">💡 Pro Tips:</p>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Use a unique password for each account</li>
                <li>• Consider using a password manager</li>
                <li>• Enable two-factor authentication (2FA)</li>
                <li>• Never share your passwords with anyone</li>
              </ul>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
