import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export function IncidentReporter() {
  const [incidentType, setIncidentType] = useState('phishing');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const incidentTypes = [
    { value: 'phishing', label: 'Phishing Email/Message', description: 'Suspicious emails or messages' },
    { value: 'malware', label: 'Malware/Virus', description: 'Suspected malicious software' },
    { value: 'breach', label: 'Data Breach', description: 'Unauthorized access to data' },
    { value: 'social', label: 'Social Engineering', description: 'Manipulation attempts' },
    { value: 'identity', label: 'Identity Theft', description: 'Stolen personal information' },
    { value: 'other', label: 'Other Security Concern', description: 'Any other security issue' }
  ];

  const handleSubmit = async () => {
    if (!description.trim()) {
      toast({
        title: 'Description Required',
        description: 'Please provide details about the security incident.',
        variant: 'destructive'
      });
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: 'Report Submitted Successfully',
        description: 'Your security incident report has been received. Our team will review it shortly.',
      });

      // Reset form
      setDescription('');
      setIncidentType('phishing');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-primary" />
          <CardTitle>Security Incident Reporter</CardTitle>
        </div>
        <CardDescription>
          Report suspicious activities or security concerns
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <Label>Incident Type</Label>
          <RadioGroup value={incidentType} onValueChange={setIncidentType}>
            {incidentTypes.map((type) => (
              <div key={type.value} className="flex items-start space-x-2">
                <RadioGroupItem value={type.value} id={type.value} className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor={type.value} className="font-medium cursor-pointer">
                    {type.label}
                  </Label>
                  <p className="text-xs text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Incident Description</Label>
          <Textarea
            id="description"
            placeholder="Describe the security incident in detail. Include:
• What happened?
• When did it occur?
• What information was involved?
• Any suspicious links or attachments?
• Steps you've already taken?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={8}
            className="resize-none"
          />
          <p className="text-xs text-muted-foreground">
            {description.length}/1000 characters
          </p>
        </div>

        <div className="rounded-lg bg-muted p-3 space-y-2">
          <p className="text-sm font-medium flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            What to Include:
          </p>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li>• Detailed description of the incident</li>
            <li>• Date and time when it occurred</li>
            <li>• Any suspicious email addresses, phone numbers, or URLs</li>
            <li>• Screenshots (if available)</li>
            <li>• Impact on your accounts or data</li>
          </ul>
        </div>

        <Button 
          onClick={handleSubmit} 
          disabled={isSubmitting || !description.trim()}
          className="w-full"
        >
          {isSubmitting ? 'Submitting Report...' : 'Submit Security Report'}
        </Button>

        <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
          <p className="font-medium text-primary mb-1">🔒 Privacy Notice:</p>
          <p className="text-muted-foreground text-xs">
            Your report will be reviewed by security professionals. Do not include sensitive 
            information like passwords or credit card numbers in your description.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
