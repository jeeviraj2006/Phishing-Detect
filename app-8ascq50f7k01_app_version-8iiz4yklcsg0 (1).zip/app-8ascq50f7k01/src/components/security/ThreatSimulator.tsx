import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Target, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';

interface Scenario {
  id: number;
  title: string;
  description: string;
  situation: string;
  options: Array<{
    id: string;
    text: string;
    isCorrect: boolean;
    explanation: string;
  }>;
  category: 'phishing' | 'social-engineering' | 'malware' | 'password';
}

const scenarios: Scenario[] = [
  {
    id: 1,
    title: 'Suspicious Email from "IT Department"',
    description: 'You receive an urgent email',
    situation: 'You receive an email claiming to be from your university IT department saying: "Your account will be suspended in 24 hours. Click here to verify your credentials immediately."',
    options: [
      {
        id: 'a',
        text: 'Click the link and enter my credentials',
        isCorrect: false,
        explanation: 'Never click suspicious links! This is a classic phishing attempt. Legitimate IT departments never ask for credentials via email.'
      },
      {
        id: 'b',
        text: 'Ignore the email completely',
        isCorrect: false,
        explanation: 'While ignoring is better than clicking, you should report phishing attempts to help protect others.'
      },
      {
        id: 'c',
        text: 'Contact IT department directly using official contact info',
        isCorrect: true,
        explanation: 'Correct! Always verify urgent requests through official channels. Never use contact information from suspicious emails.'
      },
      {
        id: 'd',
        text: 'Reply to the email asking if it\'s legitimate',
        isCorrect: false,
        explanation: 'Replying confirms your email is active and may lead to more phishing attempts. Use official channels instead.'
      }
    ],
    category: 'phishing'
  },
  {
    id: 2,
    title: 'USB Drive in Parking Lot',
    description: 'You find a USB drive',
    situation: 'You find a USB drive labeled "Confidential - Salary Information" in your university parking lot. What should you do?',
    options: [
      {
        id: 'a',
        text: 'Plug it into my computer to see what\'s on it',
        isCorrect: false,
        explanation: 'Dangerous! Unknown USB drives can contain malware that automatically installs when plugged in. This is a common attack vector.'
      },
      {
        id: 'b',
        text: 'Turn it in to campus security without plugging it in',
        isCorrect: true,
        explanation: 'Correct! This is the safest approach. Unknown USB drives can contain malware. Let security professionals handle it.'
      },
      {
        id: 'c',
        text: 'Plug it into a public computer at the library',
        isCorrect: false,
        explanation: 'Still dangerous! You\'re now potentially infecting a public computer and putting others at risk.'
      },
      {
        id: 'd',
        text: 'Take it home and scan it with antivirus first',
        isCorrect: false,
        explanation: 'Some malware can bypass antivirus software. It\'s not worth the risk to your personal device.'
      }
    ],
    category: 'malware'
  },
  {
    id: 3,
    title: 'Social Media Friend Request',
    description: 'Suspicious connection request',
    situation: 'You receive a friend request from someone claiming to be a recruiter from a major tech company. Their profile has few connections and was created recently. They\'re asking about your current projects.',
    options: [
      {
        id: 'a',
        text: 'Accept and share my project details',
        isCorrect: false,
        explanation: 'This could be social engineering! Attackers create fake profiles to gather information about targets.'
      },
      {
        id: 'b',
        text: 'Verify their identity through the company\'s official website',
        isCorrect: true,
        explanation: 'Correct! Always verify identities through official channels. Real recruiters will understand your caution.'
      },
      {
        id: 'c',
        text: 'Ignore the request',
        isCorrect: false,
        explanation: 'While safe, reporting suspicious profiles helps protect others. Consider reporting before ignoring.'
      },
      {
        id: 'd',
        text: 'Ask them to prove their identity via direct message',
        isCorrect: false,
        explanation: 'Attackers can easily fabricate "proof" in messages. Use official company channels for verification.'
      }
    ],
    category: 'social-engineering'
  },
  {
    id: 4,
    title: 'Public Wi-Fi at Coffee Shop',
    description: 'Using public network',
    situation: 'You\'re at a coffee shop and need to check your bank account. The shop offers free Wi-Fi. What\'s the safest approach?',
    options: [
      {
        id: 'a',
        text: 'Connect to Wi-Fi and access my bank normally',
        isCorrect: false,
        explanation: 'Dangerous! Public Wi-Fi can be monitored. Your banking credentials could be intercepted.'
      },
      {
        id: 'b',
        text: 'Use my phone\'s mobile data instead',
        isCorrect: true,
        explanation: 'Correct! Mobile data is much more secure than public Wi-Fi for sensitive transactions.'
      },
      {
        id: 'c',
        text: 'Connect to Wi-Fi but use incognito mode',
        isCorrect: false,
        explanation: 'Incognito mode doesn\'t protect your connection. Your data can still be intercepted on public Wi-Fi.'
      },
      {
        id: 'd',
        text: 'Wait until I get home',
        isCorrect: true,
        explanation: 'Also correct! If it\'s not urgent, waiting for a secure connection is the safest option.'
      }
    ],
    category: 'password'
  },
  {
    id: 5,
    title: 'Urgent Payment Request',
    description: 'Message from "friend"',
    situation: 'You receive a message on social media from a friend saying they\'re stranded abroad and need you to send money urgently via wire transfer.',
    options: [
      {
        id: 'a',
        text: 'Send the money immediately to help',
        isCorrect: false,
        explanation: 'Stop! This is a common scam. Accounts get hacked and used to scam friends.'
      },
      {
        id: 'b',
        text: 'Call your friend directly to verify',
        isCorrect: true,
        explanation: 'Correct! Always verify urgent requests through a different communication channel. Their account may be compromised.'
      },
      {
        id: 'c',
        text: 'Ask them security questions via message',
        isCorrect: false,
        explanation: 'If their account is hacked, the attacker might know personal information. Use a different channel.'
      },
      {
        id: 'd',
        text: 'Send a small amount first to test',
        isCorrect: false,
        explanation: 'Any amount sent is lost! Always verify through official channels before sending money.'
      }
    ],
    category: 'social-engineering'
  }
];

export function ThreatSimulator() {
  const [currentScenario, setCurrentScenario] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);

  const scenario = scenarios[currentScenario];
  const progress = ((currentScenario + 1) / scenarios.length) * 100;

  const handleSubmit = () => {
    const selected = scenario.options.find(opt => opt.id === selectedAnswer);
    if (selected?.isCorrect) {
      setScore(score + 1);
    }
    setShowResult(true);
  };

  const handleNext = () => {
    if (currentScenario < scenarios.length - 1) {
      setCurrentScenario(currentScenario + 1);
      setSelectedAnswer('');
      setShowResult(false);
    } else {
      setCompleted(true);
    }
  };

  const handleRestart = () => {
    setCurrentScenario(0);
    setSelectedAnswer('');
    setShowResult(false);
    setScore(0);
    setCompleted(false);
  };

  const getCategoryBadge = (category: Scenario['category']) => {
    const config = {
      phishing: { variant: 'destructive' as const, label: 'Phishing' },
      'social-engineering': { variant: 'secondary' as const, label: 'Social Engineering' },
      malware: { variant: 'destructive' as const, label: 'Malware' },
      password: { variant: 'default' as const, label: 'Password Security' }
    };
    const { variant, label } = config[category];
    return <Badge variant={variant}>{label}</Badge>;
  };

  if (completed) {
    const percentage = (score / scenarios.length) * 100;
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            <CardTitle>Threat Simulator - Results</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center">
              {percentage >= 80 ? (
                <CheckCircle2 className="h-16 w-16 text-green-500" />
              ) : percentage >= 60 ? (
                <AlertTriangle className="h-16 w-16 text-yellow-500" />
              ) : (
                <XCircle className="h-16 w-16 text-destructive" />
              )}
            </div>
            <div>
              <h3 className="text-2xl font-bold">
                {score} / {scenarios.length} Correct
              </h3>
              <p className="text-muted-foreground">
                {percentage >= 80 && 'Excellent! You have strong security awareness.'}
                {percentage >= 60 && percentage < 80 && 'Good job! Keep learning to improve.'}
                {percentage < 60 && 'Keep practicing! Review the explanations to learn more.'}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Progress value={percentage} className="h-3" />
            <p className="text-sm text-center text-muted-foreground">
              Security Awareness Score: {percentage.toFixed(0)}%
            </p>
          </div>

          <div className="rounded-lg bg-muted p-4 space-y-2">
            <p className="font-medium">📊 Performance Breakdown:</p>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• Phishing scenarios: {scenarios.filter(s => s.category === 'phishing').length}</li>
              <li>• Social engineering: {scenarios.filter(s => s.category === 'social-engineering').length}</li>
              <li>• Malware threats: {scenarios.filter(s => s.category === 'malware').length}</li>
              <li>• Password security: {scenarios.filter(s => s.category === 'password').length}</li>
            </ul>
          </div>

          <Button onClick={handleRestart} className="w-full">
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          <CardTitle>Threat Simulator</CardTitle>
        </div>
        <CardDescription>
          Test your security knowledge with real-world scenarios
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Scenario {currentScenario + 1} of {scenarios.length}</span>
            <span className="text-muted-foreground">Score: {score}</span>
          </div>
          <Progress value={progress} />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">{scenario.title}</h3>
            {getCategoryBadge(scenario.category)}
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {scenario.situation}
          </p>
        </div>

        <div className="space-y-3">
          <p className="text-sm font-medium">What should you do?</p>
          <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} disabled={showResult}>
            {scenario.options.map((option) => (
              <div
                key={option.id}
                className={`flex items-start space-x-2 rounded-lg border p-3 ${
                  showResult
                    ? option.isCorrect
                      ? 'border-green-500 bg-green-50 dark:bg-green-950'
                      : option.id === selectedAnswer
                      ? 'border-destructive bg-destructive/10'
                      : ''
                    : ''
                }`}
              >
                <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor={option.id} className="cursor-pointer">
                    {option.text}
                  </Label>
                  {showResult && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      {option.explanation}
                    </p>
                  )}
                </div>
                {showResult && option.isCorrect && (
                  <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0" />
                )}
                {showResult && !option.isCorrect && option.id === selectedAnswer && (
                  <XCircle className="h-5 w-5 text-destructive shrink-0" />
                )}
              </div>
            ))}
          </RadioGroup>
        </div>

        {!showResult ? (
          <Button onClick={handleSubmit} disabled={!selectedAnswer} className="w-full">
            Submit Answer
          </Button>
        ) : (
          <Button onClick={handleNext} className="w-full">
            {currentScenario < scenarios.length - 1 ? 'Next Scenario' : 'View Results'}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
