import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Mail, AlertTriangle, CheckCircle, Loader2, Shield, Info } from 'lucide-react';
import { llmService } from '@/lib/llmService';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import { useToast } from '@/hooks/use-toast';

interface EmailAnalysisResult {
  riskLevel: 'low' | 'medium' | 'high';
  analysis: string;
  redFlags: string[];
  recommendations: string[];
}

export function EmailAnalyzer() {
  const [senderEmail, setSenderEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<EmailAnalysisResult | null>(null);
  const { toast } = useToast();

  const detectRedFlags = (sender: string, subj: string, content: string) => {
    const flags: string[] = [];

    if (sender && !sender.match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)) {
      flags.push('Invalid email format');
    }

    const urgencyWords = ['urgent', 'immediate', 'act now', 'limited time', 'expires', 'suspended', 'verify now'];
    if (urgencyWords.some(word => (subj + content).toLowerCase().includes(word))) {
      flags.push('Urgency tactics detected');
    }

    const moneyWords = ['prize', 'winner', 'lottery', 'inheritance', 'million', 'claim', 'refund'];
    if (moneyWords.some(word => (subj + content).toLowerCase().includes(word))) {
      flags.push('Financial incentive language');
    }

    if (content.match(/click here|click this|download now|open attachment/gi)) {
      flags.push('Suspicious call-to-action');
    }

    if (content.match(/password|account|verify|confirm|update|suspend/gi)) {
      flags.push('Requests sensitive information');
    }

    const urlCount = (content.match(/https?:\/\//g) || []).length;
    if (urlCount > 3) {
      flags.push('Multiple links detected');
    }

    if (content.match(/[A-Z]{10,}/)) {
      flags.push('Excessive capitalization');
    }

    return flags;
  };

  const handleAnalyze = async () => {
    if (!body.trim()) {
      toast({
        title: 'Email Body Required',
        description: 'Please enter the email content to analyze.',
        variant: 'destructive'
      });
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    try {
      const redFlags = detectRedFlags(senderEmail, subject, body);
      
      const emailContent = `
Sender: ${senderEmail || 'Not provided'}
Subject: ${subject || 'Not provided'}
Body:
${body}

Detected red flags: ${redFlags.join(', ') || 'None'}
`;

      const analysis = await llmService.analyzePhishing(emailContent);
      
      const recommendations: string[] = [];
      if (analysis.riskLevel === 'high') {
        recommendations.push('Do not click any links in this email');
        recommendations.push('Do not reply or provide any information');
        recommendations.push('Delete this email immediately');
        recommendations.push('Report to your IT department or email provider');
      } else if (analysis.riskLevel === 'medium') {
        recommendations.push('Verify the sender through official channels');
        recommendations.push('Do not click links without verification');
        recommendations.push('Check for spelling and grammar errors');
        recommendations.push('Contact the organization directly if unsure');
      } else {
        recommendations.push('Still exercise caution with any links');
        recommendations.push('Verify sender identity if requesting action');
        recommendations.push('Keep your security software updated');
      }

      setResult({
        ...analysis,
        redFlags,
        recommendations
      });

      const userId = await userManager.getCurrentUserId();
      await api.phishingDetections.create(
        userId,
        `Email from: ${senderEmail}\nSubject: ${subject}\n\n${body}`,
        analysis.riskLevel,
        analysis.analysis
      );

      toast({
        title: 'Analysis Complete',
        description: 'Email analysis results are ready.',
      });
    } catch (error) {
      console.error('Email analysis error:', error);
      toast({
        title: 'Analysis Failed',
        description: 'Failed to analyze email. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRiskIcon = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return <CheckCircle className="h-5 w-5 text-success" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-warning" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
    }
  };

  const getRiskColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return 'border-success/50 bg-success/10';
      case 'medium':
        return 'border-warning/50 bg-warning/10';
      case 'high':
        return 'border-destructive/50 bg-destructive/10';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5 text-primary" />
          Email Phishing Analyzer
        </CardTitle>
        <CardDescription>
          Analyze suspicious emails for phishing indicators. Paste the email details below for a comprehensive security assessment.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="sender">Sender Email (Optional)</Label>
          <Input
            id="sender"
            type="email"
            value={senderEmail}
            onChange={(e) => setSenderEmail(e.target.value)}
            placeholder="sender@example.com"
            disabled={isAnalyzing}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="subject">Email Subject (Optional)</Label>
          <Input
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Urgent: Verify your account"
            disabled={isAnalyzing}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="body">Email Body *</Label>
          <Textarea
            id="body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Paste the email content here..."
            className="min-h-[200px]"
            disabled={isAnalyzing}
          />
        </div>

        <Button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !body.trim()}
          className="w-full"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing Email...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-4 w-4" />
              Analyze Email
            </>
          )}
        </Button>

        {result && (
          <div className="space-y-4">
            <Alert className={getRiskColor(result.riskLevel)}>
              <div className="flex items-start gap-3">
                {getRiskIcon(result.riskLevel)}
                <div className="flex-1 space-y-2">
                  <AlertTitle className="text-lg font-semibold capitalize">
                    {result.riskLevel} Risk Level
                  </AlertTitle>
                  <AlertDescription className="text-sm leading-relaxed">
                    {result.analysis}
                  </AlertDescription>
                </div>
              </div>
            </Alert>

            {result.redFlags.length > 0 && (
              <Card className="border-destructive/20 bg-destructive/5">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    Red Flags Detected
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    {result.redFlags.map((flag, index) => (
                      <li key={index} className="text-sm flex items-start gap-2">
                        <span className="text-destructive mt-0.5">•</span>
                        <span>{flag}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-primary" />
                  Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {result.recommendations.map((rec, index) => (
                    <li key={index} className="text-sm flex items-start gap-2">
                      <span className="text-primary mt-0.5">✓</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <h4 className="font-semibold text-sm mb-2">🎯 Common Phishing Tactics</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Creating false sense of urgency ("Act now or lose access!")</li>
                <li>• Impersonating trusted organizations (banks, tech companies)</li>
                <li>• Requesting sensitive information (passwords, SSN, credit cards)</li>
                <li>• Using threatening language ("Your account will be suspended")</li>
                <li>• Offering too-good-to-be-true rewards or prizes</li>
              </ul>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
