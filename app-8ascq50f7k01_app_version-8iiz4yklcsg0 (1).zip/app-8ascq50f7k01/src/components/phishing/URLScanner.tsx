import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Link2, AlertTriangle, CheckCircle, Loader2, ExternalLink, Shield, XCircle } from 'lucide-react';
import { llmService } from '@/lib/llmService';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import { useToast } from '@/hooks/use-toast';

interface URLAnalysis {
  riskLevel: 'low' | 'medium' | 'high';
  analysis: string;
  indicators: {
    suspiciousDomain: boolean;
    httpsEnabled: boolean;
    unusualCharacters: boolean;
    shortenerDetected: boolean;
    ipAddress: boolean;
  };
}

export function URLScanner() {
  const [url, setUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState<URLAnalysis | null>(null);
  const { toast } = useToast();

  const analyzeURL = (urlString: string) => {
    const indicators = {
      suspiciousDomain: false,
      httpsEnabled: false,
      unusualCharacters: false,
      shortenerDetected: false,
      ipAddress: false
    };

    try {
      const urlObj = new URL(urlString);
      
      indicators.httpsEnabled = urlObj.protocol === 'https:';
      
      const suspiciousTLDs = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top'];
      indicators.suspiciousDomain = suspiciousTLDs.some(tld => urlObj.hostname.endsWith(tld));
      
      indicators.unusualCharacters = /[^\w.-]/.test(urlObj.hostname) || urlObj.hostname.includes('--');
      
      const shorteners = ['bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'ow.ly', 'is.gd'];
      indicators.shortenerDetected = shorteners.some(s => urlObj.hostname.includes(s));
      
      indicators.ipAddress = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(urlObj.hostname);
    } catch (e) {
      // Invalid URL
    }

    return indicators;
  };

  const handleScan = async () => {
    if (!url.trim()) {
      toast({
        title: 'URL Required',
        description: 'Please enter a URL to scan.',
        variant: 'destructive'
      });
      return;
    }

    let urlToScan = url.trim();
    if (!urlToScan.startsWith('http://') && !urlToScan.startsWith('https://')) {
      urlToScan = 'https://' + urlToScan;
    }

    try {
      new URL(urlToScan);
    } catch (e) {
      toast({
        title: 'Invalid URL',
        description: 'Please enter a valid URL.',
        variant: 'destructive'
      });
      return;
    }

    setIsScanning(true);
    setResult(null);

    try {
      const indicators = analyzeURL(urlToScan);
      
      const prompt = `Analyze this URL for phishing indicators: ${urlToScan}
      
Technical indicators detected:
- HTTPS: ${indicators.httpsEnabled ? 'Yes' : 'No'}
- Suspicious domain: ${indicators.suspiciousDomain ? 'Yes' : 'No'}
- Unusual characters: ${indicators.unusualCharacters ? 'Yes' : 'No'}
- URL shortener: ${indicators.shortenerDetected ? 'Yes' : 'No'}
- IP address: ${indicators.ipAddress ? 'Yes' : 'No'}`;

      const analysis = await llmService.analyzePhishing(prompt);
      
      setResult({
        ...analysis,
        indicators
      });

      const userId = await userManager.getCurrentUserId();
      await api.phishingDetections.create(
        userId,
        urlToScan,
        analysis.riskLevel,
        analysis.analysis
      );

      toast({
        title: 'Scan Complete',
        description: 'URL analysis results are ready.',
      });
    } catch (error) {
      console.error('URL scan error:', error);
      toast({
        title: 'Scan Failed',
        description: 'Failed to scan URL. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsScanning(false);
    }
  };

  const getRiskIcon = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return <CheckCircle className="h-5 w-5 text-success" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-warning" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
    }
  };

  const getRiskColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return 'border-success/50 bg-success/10';
      case 'medium':
        return 'border-warning/50 bg-warning/10';
      case 'high':
        return 'border-destructive/50 bg-destructive/10';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Link2 className="h-5 w-5 text-primary" />
          URL Security Scanner
        </CardTitle>
        <CardDescription>
          Check if a URL is safe before clicking. Detects phishing sites, malicious links, and suspicious domains.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com or example.com"
            disabled={isScanning}
            onKeyDown={(e) => e.key === 'Enter' && handleScan()}
          />
          <Button
            onClick={handleScan}
            disabled={isScanning || !url.trim()}
          >
            {isScanning ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Scanning...
              </>
            ) : (
              <>
                <Shield className="mr-2 h-4 w-4" />
                Scan
              </>
            )}
          </Button>
        </div>

        {result && (
          <div className="space-y-4">
            <Alert className={getRiskColor(result.riskLevel)}>
              <div className="flex items-start gap-3">
                {getRiskIcon(result.riskLevel)}
                <div className="flex-1 space-y-2">
                  <AlertTitle className="text-lg font-semibold capitalize">
                    {result.riskLevel} Risk Level
                  </AlertTitle>
                  <AlertDescription className="text-sm leading-relaxed">
                    {result.analysis}
                  </AlertDescription>
                </div>
              </div>
            </Alert>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Security Indicators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">HTTPS Enabled</span>
                  {result.indicators.httpsEnabled ? (
                    <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3" />
                      Yes
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 bg-destructive/10 text-destructive border-destructive/20">
                      <XCircle className="h-3 w-3" />
                      No
                    </Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Suspicious Domain</span>
                  {result.indicators.suspiciousDomain ? (
                    <Badge variant="outline" className="gap-1 bg-destructive/10 text-destructive border-destructive/20">
                      <AlertTriangle className="h-3 w-3" />
                      Detected
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3" />
                      Clean
                    </Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Unusual Characters</span>
                  {result.indicators.unusualCharacters ? (
                    <Badge variant="outline" className="gap-1 bg-warning/10 text-warning border-warning/20">
                      <AlertTriangle className="h-3 w-3" />
                      Found
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3" />
                      None
                    </Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">URL Shortener</span>
                  {result.indicators.shortenerDetected ? (
                    <Badge variant="outline" className="gap-1 bg-warning/10 text-warning border-warning/20">
                      <AlertTriangle className="h-3 w-3" />
                      Yes
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3" />
                      No
                    </Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">IP Address URL</span>
                  {result.indicators.ipAddress ? (
                    <Badge variant="outline" className="gap-1 bg-warning/10 text-warning border-warning/20">
                      <AlertTriangle className="h-3 w-3" />
                      Yes
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 bg-success/10 text-success border-success/20">
                      <CheckCircle className="h-3 w-3" />
                      No
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <h4 className="font-semibold text-sm mb-2">⚠️ Safety Tips</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Always verify the URL matches the official website</li>
                <li>• Look for HTTPS and a padlock icon in your browser</li>
                <li>• Be cautious of shortened URLs from unknown sources</li>
                <li>• Hover over links to preview the destination before clicking</li>
              </ul>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
