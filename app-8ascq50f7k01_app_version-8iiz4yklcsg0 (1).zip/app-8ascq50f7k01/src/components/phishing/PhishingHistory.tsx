import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { History, AlertTriangle, CheckCircle, Trash2, Eye, EyeOff } from 'lucide-react';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import { useToast } from '@/hooks/use-toast';
import type { PhishingDetection } from '@/types/types';

export function PhishingHistory() {
  const [detections, setDetections] = useState<PhishingDetection[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      setIsLoading(true);
      const userId = await userManager.getCurrentUserId();
      const history = await api.phishingDetections.getByUser(userId);
      setDetections(history);
    } catch (error) {
      console.error('Failed to load history:', error);
      toast({
        title: 'Load Failed',
        description: 'Failed to load detection history.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.phishingDetections.delete(id);
      setDetections(detections.filter(d => d.id !== id));
      toast({
        title: 'Deleted',
        description: 'Detection record removed.',
      });
    } catch (error) {
      console.error('Failed to delete:', error);
      toast({
        title: 'Delete Failed',
        description: 'Failed to delete record.',
        variant: 'destructive'
      });
    }
  };

  const getRiskBadge = (risk: string) => {
    const colors = {
      low: 'bg-success/10 text-success border-success/20',
      medium: 'bg-warning/10 text-warning border-warning/20',
      high: 'bg-destructive/10 text-destructive border-destructive/20'
    };
    const color = colors[risk as keyof typeof colors] || colors.medium;
    return (
      <Badge variant="outline" className={color}>
        {risk.toUpperCase()}
      </Badge>
    );
  };

  const getRiskIcon = (risk: string) => {
    if (risk === 'low') return <CheckCircle className="h-4 w-4 text-success" />;
    return <AlertTriangle className="h-4 w-4 text-warning" />;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const truncateContent = (content: string, maxLength: number = 100) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Detection History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            Loading history...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (detections.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Detection History
          </CardTitle>
          <CardDescription>
            Your phishing detection history will appear here
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription className="text-center py-4">
              No detection history yet. Start analyzing suspicious content to build your history.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Detection History
          </CardTitle>
          <CardDescription>
            View your past phishing detection scans ({detections.length} total)
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {detections.map((detection) => (
          <Card key={detection.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  {getRiskIcon(detection.risk_level)}
                  {getRiskBadge(detection.risk_level)}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleDelete(detection.id)}
                >
                  <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                </Button>
              </div>
              <div className="text-xs text-muted-foreground">
                {formatDate(detection.created_at)}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="text-sm font-medium">Analyzed Content:</div>
                <div className="p-3 rounded-lg bg-muted/50 border border-border text-xs font-mono break-all">
                  {expandedId === detection.id
                    ? detection.content
                    : truncateContent(detection.content)}
                </div>
                {detection.content.length > 100 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => setExpandedId(expandedId === detection.id ? null : detection.id)}
                  >
                    {expandedId === detection.id ? (
                      <>
                        <EyeOff className="h-3 w-3 mr-1" />
                        Show Less
                      </>
                    ) : (
                      <>
                        <Eye className="h-3 w-3 mr-1" />
                        Show More
                      </>
                    )}
                  </Button>
                )}
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium">Analysis Result:</div>
                <div className="text-xs text-muted-foreground leading-relaxed">
                  {expandedId === detection.id
                    ? detection.analysis
                    : truncateContent(detection.analysis, 150)}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
