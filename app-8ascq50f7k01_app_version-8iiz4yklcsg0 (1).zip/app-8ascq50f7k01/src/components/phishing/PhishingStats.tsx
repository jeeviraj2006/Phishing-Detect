import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, TrendingUp, Shield, AlertTriangle, CheckCircle } from 'lucide-react';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import type { PhishingDetection } from '@/types/types';

export function PhishingStats() {
  const [detections, setDetections] = useState<PhishingDetection[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setIsLoading(true);
      const userId = await userManager.getCurrentUserId();
      const history = await api.phishingDetections.getByUser(userId);
      setDetections(history);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateStats = () => {
    const total = detections.length;
    const high = detections.filter(d => d.risk_level === 'high').length;
    const medium = detections.filter(d => d.risk_level === 'medium').length;
    const low = detections.filter(d => d.risk_level === 'low').length;

    const last7Days = detections.filter(d => {
      const date = new Date(d.created_at);
      const now = new Date();
      const diff = now.getTime() - date.getTime();
      return diff < 7 * 24 * 60 * 60 * 1000;
    }).length;

    const last30Days = detections.filter(d => {
      const date = new Date(d.created_at);
      const now = new Date();
      const diff = now.getTime() - date.getTime();
      return diff < 30 * 24 * 60 * 60 * 1000;
    }).length;

    return {
      total,
      high,
      medium,
      low,
      last7Days,
      last30Days,
      highPercentage: total > 0 ? Math.round((high / total) * 100) : 0,
      mediumPercentage: total > 0 ? Math.round((medium / total) * 100) : 0,
      lowPercentage: total > 0 ? Math.round((low / total) * 100) : 0
    };
  };

  const stats = calculateStats();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Detection Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            Loading statistics...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (stats.total === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Detection Statistics
          </CardTitle>
          <CardDescription>
            Your detection statistics will appear here
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            No data yet. Start analyzing content to see your statistics.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Detection Statistics
          </CardTitle>
          <CardDescription>
            Overview of your phishing detection activity
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-primary/20 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Scans
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.total}</div>
              <Shield className="h-8 w-8 text-primary opacity-50" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              All-time detection scans
            </p>
          </CardContent>
        </Card>

        <Card className="border-warning/20 bg-warning/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Last 7 Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.last7Days}</div>
              <TrendingUp className="h-8 w-8 text-warning opacity-50" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Recent activity
            </p>
          </CardContent>
        </Card>

        <Card className="border-success/20 bg-success/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Last 30 Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.last30Days}</div>
              <BarChart3 className="h-8 w-8 text-success opacity-50" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Monthly activity
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Risk Level Distribution</CardTitle>
          <CardDescription>
            Breakdown of detected threat levels
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  <span className="font-medium">High Risk</span>
                </div>
                <span className="text-muted-foreground">
                  {stats.high} ({stats.highPercentage}%)
                </span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-destructive transition-all"
                  style={{ width: `${stats.highPercentage}%` }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  <span className="font-medium">Medium Risk</span>
                </div>
                <span className="text-muted-foreground">
                  {stats.medium} ({stats.mediumPercentage}%)
                </span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-warning transition-all"
                  style={{ width: `${stats.mediumPercentage}%` }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  <span className="font-medium">Low Risk</span>
                </div>
                <span className="text-muted-foreground">
                  {stats.low} ({stats.lowPercentage}%)
                </span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-success transition-all"
                  style={{ width: `${stats.lowPercentage}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-base">🎯 Your Security Awareness</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            {stats.total >= 10 && (
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>You've performed {stats.total} security scans - great vigilance!</span>
              </div>
            )}
            {stats.high > 0 && (
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>You've identified {stats.high} high-risk threats - excellent detection!</span>
              </div>
            )}
            {stats.last7Days > 0 && (
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>You're actively protecting yourself with {stats.last7Days} scans this week</span>
              </div>
            )}
            <div className="flex items-start gap-2">
              <span className="text-primary">💡</span>
              <span>Keep scanning suspicious content to stay protected from phishing attacks</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
