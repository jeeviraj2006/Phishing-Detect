import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Shield, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { llmService } from '@/lib/llmService';
import { api } from '@/db/api';
import { userManager } from '@/lib/userManager';
import { useToast } from '@/hooks/use-toast';

export function PhishingDetector() {
  const [content, setContent] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{
    riskLevel: 'low' | 'medium' | 'high';
    analysis: string;
  } | null>(null);
  const { toast } = useToast();

  const handleAnalyze = async () => {
    if (!content.trim()) {
      toast({
        title: 'Input Required',
        description: 'Please enter content to analyze.',
        variant: 'destructive'
      });
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    try {
      const analysis = await llmService.analyzePhishing(content);
      setResult(analysis);

      const userId = await userManager.getCurrentUserId();
      await api.phishingDetections.create(
        userId,
        content,
        analysis.riskLevel,
        analysis.analysis
      );

      toast({
        title: 'Analysis Complete',
        description: 'Phishing detection results are ready.',
      });
    } catch (error) {
      console.error('Phishing analysis error:', error);
      toast({
        title: 'Analysis Failed',
        description: 'Failed to analyze content. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRiskIcon = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return <CheckCircle className="h-5 w-5 text-success" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-warning" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
    }
  };

  const getRiskColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return 'border-success/50 bg-success/10';
      case 'medium':
        return 'border-warning/50 bg-warning/10';
      case 'high':
        return 'border-destructive/50 bg-destructive/10';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          Phishing Detection
        </CardTitle>
        <CardDescription>
          Paste suspicious emails, messages, or URLs to check for phishing indicators
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Paste email content, message, or URL here..."
          className="min-h-[150px]"
          disabled={isAnalyzing}
        />
        <Button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !content.trim()}
          className="w-full"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-4 w-4" />
              Analyze for Phishing
            </>
          )}
        </Button>

        {result && (
          <Alert className={getRiskColor(result.riskLevel)}>
            <div className="flex items-start gap-3">
              {getRiskIcon(result.riskLevel)}
              <div className="flex-1 space-y-2">
                <AlertTitle className="text-lg font-semibold capitalize">
                  {result.riskLevel} Risk Level
                </AlertTitle>
                <AlertDescription className="text-sm leading-relaxed">
                  {result.analysis}
                </AlertDescription>
              </div>
            </div>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
