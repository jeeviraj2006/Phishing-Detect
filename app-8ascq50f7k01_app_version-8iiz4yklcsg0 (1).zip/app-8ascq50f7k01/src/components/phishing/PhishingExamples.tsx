import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, Mail, Link2, MessageSquare, CreditCard, Shield } from 'lucide-react';

export function PhishingExamples() {
  const emailExamples = [
    {
      title: 'Fake Bank Alert',
      risk: 'high' as const,
      from: 'security@bankofamerica-verify.com',
      subject: 'URGENT: Your account has been suspended',
      body: 'Dear Customer,\n\nWe have detected unusual activity on your account. Your account has been temporarily suspended for your protection.\n\nClick here immediately to verify your identity and restore access: http://bankofamerica-secure.tk/verify\n\nYou have 24 hours to respond or your account will be permanently closed.\n\nBank of America Security Team',
      redFlags: [
        'Suspicious domain (bankofamerica-verify.com)',
        'Creates urgency and fear',
        'Requests immediate action',
        'Uses threatening language',
        'Link goes to .tk domain (suspicious TLD)',
        'Generic greeting ("Dear Customer")'
      ]
    },
    {
      title: 'Prize Winner Scam',
      risk: 'high' as const,
      from: 'notifications@amazon-winner.com',
      subject: 'Congratulations! You\'ve won $5,000 Amazon Gift Card',
      body: 'CONGRATULATIONS!!!\n\nYou have been selected as our lucky winner for a $5,000 Amazon Gift Card!\n\nTo claim your prize, click here and enter your personal information:\nhttp://bit.ly/amazon-prize-claim\n\nThis offer expires in 2 hours!\n\nAmazon Rewards Team',
      redFlags: [
        'Too good to be true offer',
        'Fake domain (amazon-winner.com)',
        'URL shortener hides real destination',
        'Excessive capitalization and exclamation marks',
        'Creates artificial time pressure',
        'Requests personal information'
      ]
    },
    {
      title: 'IT Department Impersonation',
      risk: 'medium' as const,
      from: 'it-support@company-internal.com',
      subject: 'Password Reset Required',
      body: 'Hello,\n\nOur IT department is performing a security upgrade. All employees must reset their passwords within 24 hours.\n\nPlease click the link below to update your password:\nhttps://company-portal-login.com/reset\n\nIf you do not complete this within 24 hours, your email access will be disabled.\n\nIT Support Team',
      redFlags: [
        'Impersonates internal IT department',
        'External domain pretending to be internal',
        'Requests password reset via email',
        'Threatens account suspension',
        'Legitimate IT rarely sends mass password reset emails'
      ]
    }
  ];

  const urlExamples = [
    {
      url: 'http://paypal-secure-login.tk/verify',
      legitimate: 'https://www.paypal.com',
      issues: [
        'Uses .tk domain (free, often used for phishing)',
        'No HTTPS encryption',
        'Adds "secure" to appear trustworthy',
        'Not the official PayPal domain'
      ]
    },
    {
      url: 'https://www.g00gle.com/signin',
      legitimate: 'https://www.google.com',
      issues: [
        'Uses zeros (0) instead of letter O',
        'Typosquatting attack',
        'Looks similar at quick glance',
        'Different domain registration'
      ]
    },
    {
      url: 'https://192.168.1.100/login',
      legitimate: 'https://yourbank.com',
      issues: [
        'Uses IP address instead of domain name',
        'Legitimate sites use domain names',
        'Harder to verify authenticity',
        'Common in phishing attacks'
      ]
    }
  ];

  const textExamples = [
    {
      message: 'Your package delivery failed. Confirm your address: http://usps-redelivery.tk/track',
      type: 'SMS Phishing (Smishing)',
      issues: [
        'Fake delivery notification',
        'Suspicious shortened URL',
        'Creates urgency',
        'USPS uses official domain'
      ]
    },
    {
      message: 'Hi! I\'m stuck and need help. Can you send me $200 via Venmo? I\'ll pay you back tomorrow. -Sarah',
      type: 'Friend Impersonation',
      issues: [
        'Impersonates someone you know',
        'Requests money urgently',
        'Uses casual tone to seem legitimate',
        'Verify through another channel'
      ]
    }
  ];

  const getRiskBadge = (risk: 'low' | 'medium' | 'high') => {
    const colors = {
      low: 'bg-success/10 text-success border-success/20',
      medium: 'bg-warning/10 text-warning border-warning/20',
      high: 'bg-destructive/10 text-destructive border-destructive/20'
    };
    return (
      <Badge variant="outline" className={colors[risk]}>
        {risk.toUpperCase()} RISK
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Learn to Spot Phishing
          </CardTitle>
          <CardDescription>
            Study these real-world examples to recognize phishing attempts. Understanding common tactics is your best defense.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="emails" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="emails" className="gap-2">
            <Mail className="h-4 w-4" />
            Email Examples
          </TabsTrigger>
          <TabsTrigger value="urls" className="gap-2">
            <Link2 className="h-4 w-4" />
            Malicious URLs
          </TabsTrigger>
          <TabsTrigger value="texts" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            Text/SMS
          </TabsTrigger>
        </TabsList>

        <TabsContent value="emails" className="space-y-4 mt-6">
          {emailExamples.map((example, index) => (
            <Card key={index} className="border-destructive/20">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{example.title}</CardTitle>
                    <CardDescription className="text-xs">
                      <div>From: {example.from}</div>
                      <div>Subject: {example.subject}</div>
                    </CardDescription>
                  </div>
                  {getRiskBadge(example.risk)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50 border border-border font-mono text-xs whitespace-pre-wrap">
                  {example.body}
                </div>
                <Alert className="border-destructive/50 bg-destructive/5">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  <AlertTitle>Red Flags Detected</AlertTitle>
                  <AlertDescription>
                    <ul className="mt-2 space-y-1 text-xs">
                      {example.redFlags.map((flag, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-destructive">•</span>
                          <span>{flag}</span>
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="urls" className="space-y-4 mt-6">
          {urlExamples.map((example, index) => (
            <Card key={index} className="border-warning/20">
              <CardHeader>
                <CardTitle className="text-base">Example {index + 1}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Phishing URL:</div>
                    <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 font-mono text-sm break-all">
                      {example.url}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Legitimate URL:</div>
                    <div className="p-3 rounded-lg bg-success/10 border border-success/20 font-mono text-sm break-all">
                      {example.legitimate}
                    </div>
                  </div>
                </div>
                <Alert className="border-warning/50 bg-warning/5">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  <AlertTitle>Issues Identified</AlertTitle>
                  <AlertDescription>
                    <ul className="mt-2 space-y-1 text-xs">
                      {example.issues.map((issue, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-warning">•</span>
                          <span>{issue}</span>
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="texts" className="space-y-4 mt-6">
          {textExamples.map((example, index) => (
            <Card key={index} className="border-warning/20">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <CardTitle className="text-base">{example.type}</CardTitle>
                  <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                    MEDIUM RISK
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50 border border-border text-sm">
                  {example.message}
                </div>
                <Alert className="border-warning/50 bg-warning/5">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  <AlertTitle>Warning Signs</AlertTitle>
                  <AlertDescription>
                    <ul className="mt-2 space-y-1 text-xs">
                      {example.issues.map((issue, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-warning">•</span>
                          <span>{issue}</span>
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-base">🎓 Key Takeaways</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">✓</span>
              <span><strong>Verify the sender:</strong> Check email addresses and domains carefully</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">✓</span>
              <span><strong>Hover before clicking:</strong> Preview link destinations before clicking</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">✓</span>
              <span><strong>Question urgency:</strong> Legitimate organizations don't create artificial pressure</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">✓</span>
              <span><strong>Protect credentials:</strong> Never enter passwords from email links</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">✓</span>
              <span><strong>When in doubt, verify:</strong> Contact organizations through official channels</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
