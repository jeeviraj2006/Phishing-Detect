import { supabase } from './supabase';
import type { 
  User, 
  ChatSession, 
  ChatMessage, 
  PhishingDetection,
  MonitoredEmail,
  QuizResult,
  SecurityChecklistItem,
  ThreatSimulatorResult,
  SecurityIncidentReport,
  DeviceSecurityScan,
  QuizLevel,
  QuizModule,
  QuizQuestion,
  UserQuizProgress,
  UserBadge
} from '@/types/types';

export const api = {
  users: {
    async create(): Promise<User | null> {
      const { data, error } = await supabase
        .from('users')
        .insert({})
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating user:', error);
        return null;
      }
      return data;
    },

    async updateLastActive(userId: string): Promise<void> {
      await supabase
        .from('users')
        .update({ last_active: new Date().toISOString() })
        .eq('id', userId);
    },

    async getById(userId: string): Promise<User | null> {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching user:', error);
        return null;
      }
      return data;
    }
  },

  chatSessions: {
    async create(userId: string, title: string = 'New Chat'): Promise<ChatSession | null> {
      const { data, error } = await supabase
        .from('chat_sessions')
        .insert({ user_id: userId, title })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating chat session:', error);
        return null;
      }
      return data;
    },

    async getByUserId(userId: string): Promise<ChatSession[]> {
      const { data, error } = await supabase
        .from('chat_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching chat sessions:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async updateTitle(sessionId: string, title: string): Promise<void> {
      await supabase
        .from('chat_sessions')
        .update({ title, updated_at: new Date().toISOString() })
        .eq('id', sessionId);
    },

    async delete(sessionId: string): Promise<void> {
      await supabase
        .from('chat_sessions')
        .delete()
        .eq('id', sessionId);
    }
  },

  chatMessages: {
    async create(sessionId: string, role: 'user' | 'model', content: string, imageUrl?: string): Promise<ChatMessage | null> {
      const { data, error } = await supabase
        .from('chat_messages')
        .insert({ session_id: sessionId, role, content, image_url: imageUrl })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating chat message:', error);
        return null;
      }

      await supabase
        .from('chat_sessions')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', sessionId);
      
      return data;
    },

    async getBySessionId(sessionId: string): Promise<ChatMessage[]> {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true });
      
      if (error) {
        console.error('Error fetching chat messages:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  phishingDetections: {
    async create(userId: string, content: string, riskLevel: 'low' | 'medium' | 'high', analysis: string): Promise<PhishingDetection | null> {
      const { data, error } = await supabase
        .from('phishing_detections')
        .insert({ user_id: userId, content, risk_level: riskLevel, analysis })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating phishing detection:', error);
        return null;
      }
      return data;
    },

    async getByUser(userId: string, limit: number = 100): Promise<PhishingDetection[]> {
      const { data, error } = await supabase
        .from('phishing_detections')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit);
      
      if (error) {
        console.error('Error fetching phishing detections:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async getByUserId(userId: string, limit: number = 20): Promise<PhishingDetection[]> {
      return this.getByUser(userId, limit);
    },

    async delete(id: string): Promise<boolean> {
      const { error } = await supabase
        .from('phishing_detections')
        .delete()
        .eq('id', id);
      
      if (error) {
        console.error('Error deleting phishing detection:', error);
        return false;
      }
      return true;
    }
  },

  quizResults: {
    async create(userId: string, quizType: string, score: number, totalQuestions: number): Promise<QuizResult | null> {
      const { data, error } = await supabase
        .from('quiz_results')
        .insert({ user_id: userId, quiz_type: quizType, score, total_questions: totalQuestions })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating quiz result:', error);
        return null;
      }
      return data;
    },

    async getByUserId(userId: string): Promise<QuizResult[]> {
      const { data, error } = await supabase
        .from('quiz_results')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching quiz results:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  securityChecklist: {
    async markComplete(userId: string, itemId: string, itemType: 'daily' | 'weekly' | 'monthly'): Promise<SecurityChecklistItem | null> {
      const { data, error } = await supabase
        .from('security_checklist_items')
        .insert({ user_id: userId, item_id: itemId, item_type: itemType })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error marking checklist item complete:', error);
        return null;
      }
      return data;
    },

    async markIncomplete(userId: string, itemId: string): Promise<void> {
      await supabase
        .from('security_checklist_items')
        .delete()
        .eq('user_id', userId)
        .eq('item_id', itemId);
    },

    async getByUserId(userId: string, itemType?: 'daily' | 'weekly' | 'monthly'): Promise<SecurityChecklistItem[]> {
      let query = supabase
        .from('security_checklist_items')
        .select('*')
        .eq('user_id', userId);
      
      if (itemType) {
        query = query.eq('item_type', itemType);
      }
      
      const { data, error } = await query.order('completed_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching checklist items:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  threatSimulator: {
    async saveResult(userId: string, score: number, totalQuestions: number): Promise<ThreatSimulatorResult | null> {
      const { data, error } = await supabase
        .from('threat_simulator_results')
        .insert({ user_id: userId, score, total_questions: totalQuestions })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error saving threat simulator result:', error);
        return null;
      }
      return data;
    },

    async getByUserId(userId: string, limit: number = 10): Promise<ThreatSimulatorResult[]> {
      const { data, error } = await supabase
        .from('threat_simulator_results')
        .select('*')
        .eq('user_id', userId)
        .order('completed_at', { ascending: false })
        .limit(limit);
      
      if (error) {
        console.error('Error fetching threat simulator results:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  incidentReports: {
    async create(userId: string, incidentType: string, description: string): Promise<SecurityIncidentReport | null> {
      const { data, error } = await supabase
        .from('security_incident_reports')
        .insert({ user_id: userId, incident_type: incidentType, description })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating incident report:', error);
        return null;
      }
      return data;
    },

    async getByUserId(userId: string): Promise<SecurityIncidentReport[]> {
      const { data, error } = await supabase
        .from('security_incident_reports')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching incident reports:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  deviceScans: {
    async save(userId: string, score: number, totalChecks: number, passedChecks: number, scanData: Record<string, boolean>): Promise<DeviceSecurityScan | null> {
      const { data, error } = await supabase
        .from('device_security_scans')
        .insert({ 
          user_id: userId, 
          score, 
          total_checks: totalChecks, 
          passed_checks: passedChecks, 
          scan_data: scanData 
        })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error saving device scan:', error);
        return null;
      }
      return data;
    },

    async getByUserId(userId: string, limit: number = 10): Promise<DeviceSecurityScan[]> {
      const { data, error } = await supabase
        .from('device_security_scans')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit);
      
      if (error) {
        console.error('Error fetching device scans:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    }
  },

  quiz: {
    async getLevels(): Promise<QuizLevel[]> {
      const { data, error } = await supabase
        .from('quiz_levels')
        .select('*')
        .order('id', { ascending: true });
      
      if (error) {
        console.error('Error fetching quiz levels:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async getModulesByLevel(levelId: number): Promise<QuizModule[]> {
      const { data, error } = await supabase
        .from('quiz_modules')
        .select('*')
        .eq('level_id', levelId)
        .order('module_number', { ascending: true });
      
      if (error) {
        console.error('Error fetching quiz modules:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async getQuestionsByModule(moduleId: string): Promise<QuizQuestion[]> {
      const { data, error } = await supabase
        .from('quiz_questions')
        .select('*')
        .eq('module_id', moduleId)
        .order('created_at', { ascending: true });
      
      if (error) {
        console.error('Error fetching quiz questions:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async getUserProgress(userId: string): Promise<UserQuizProgress[]> {
      const { data, error } = await supabase
        .from('user_quiz_progress')
        .select('*')
        .eq('user_id', userId);
      
      if (error) {
        console.error('Error fetching user progress:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async saveProgress(userId: string, moduleId: string, score: number, completed: boolean): Promise<UserQuizProgress | null> {
      const { data, error } = await supabase
        .from('user_quiz_progress')
        .upsert({
          user_id: userId,
          module_id: moduleId,
          score,
          completed,
          completed_at: completed ? new Date().toISOString() : null
        }, {
          onConflict: 'user_id,module_id'
        })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error saving progress:', error);
        return null;
      }
      return data;
    },

    async getUserBadges(userId: string): Promise<UserBadge[]> {
      const { data, error } = await supabase
        .from('user_badges')
        .select('*')
        .eq('user_id', userId)
        .order('earned_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching user badges:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async awardBadge(userId: string, levelId: number): Promise<UserBadge | null> {
      const { data, error } = await supabase
        .from('user_badges')
        .upsert({
          user_id: userId,
          level_id: levelId
        }, {
          onConflict: 'user_id,level_id'
        })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error awarding badge:', error);
        return null;
      }
      return data;
    },

    async checkLevelCompletion(userId: string, levelId: number): Promise<boolean> {
      const modules = await this.getModulesByLevel(levelId);
      const progress = await this.getUserProgress(userId);
      
      const completedModules = progress.filter(p => 
        p.completed && modules.some(m => m.id === p.module_id)
      );
      
      return completedModules.length === modules.length;
    }
  },

  monitoredEmails: {
    async create(userId: string, sender: string, subject: string, content: string, riskLevel: 'low' | 'medium' | 'high', analysis: string): Promise<MonitoredEmail | null> {
      const { data, error } = await supabase
        .from('monitored_emails')
        .insert({ 
          user_id: userId, 
          sender, 
          subject, 
          content, 
          risk_level: riskLevel, 
          analysis,
          is_read: false
        })
        .select()
        .maybeSingle();
      
      if (error) {
        console.error('Error creating monitored email:', error);
        return null;
      }
      return data;
    },

    async getByUser(userId: string, limit: number = 100): Promise<MonitoredEmail[]> {
      const { data, error } = await supabase
        .from('monitored_emails')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit);
      
      if (error) {
        console.error('Error fetching monitored emails:', error);
        return [];
      }
      return Array.isArray(data) ? data : [];
    },

    async markAsRead(id: string): Promise<boolean> {
      const { error } = await supabase
        .from('monitored_emails')
        .update({ is_read: true })
        .eq('id', id);
      
      if (error) {
        console.error('Error marking email as read:', error);
        return false;
      }
      return true;
    },

    async delete(id: string): Promise<boolean> {
      const { error } = await supabase
        .from('monitored_emails')
        .delete()
        .eq('id', id);
      
      if (error) {
        console.error('Error deleting monitored email:', error);
        return false;
      }
      return true;
    },

    async getUnreadCount(userId: string): Promise<number> {
      const { data, error } = await supabase
        .rpc('get_unread_email_count', { uid: userId });
      
      if (error) {
        console.error('Error getting unread count:', error);
        return 0;
      }
      return data || 0;
    }
  }
};

