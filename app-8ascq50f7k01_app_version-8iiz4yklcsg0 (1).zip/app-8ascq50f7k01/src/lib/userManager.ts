import { api } from '@/db/api';

const USER_ID_KEY = 'cyberguard_user_id';

export const userManager = {
  async getCurrentUserId(): Promise<string> {
    let userId = localStorage.getItem(USER_ID_KEY);
    
    if (!userId) {
      const newUser = await api.users.create();
      if (newUser) {
        userId = newUser.id;
        localStorage.setItem(USER_ID_KEY, userId);
      } else {
        throw new Error('Failed to create user');
      }
    } else {
      await api.users.updateLastActive(userId);
    }
    
    return userId;
  },

  clearUserId(): void {
    localStorage.removeItem(USER_ID_KEY);
  }
};
