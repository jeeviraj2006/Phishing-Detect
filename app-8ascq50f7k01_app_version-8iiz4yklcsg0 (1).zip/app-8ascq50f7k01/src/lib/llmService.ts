import type { LLMMessage } from '@/types/types';
import { supabase, supabaseUrl, supabaseAnonKey } from '@/db/supabase';

export interface StreamCallbacks {
  onChunk: (text: string) => void;
  onComplete: () => void;
  onError: (error: string) => void;
}

export const llmService = {
  async streamChat(messages: LLMMessage[], callbacks: StreamCallbacks): Promise<void> {
    try {
      console.log('Calling Edge Function with messages:', messages.length);

      // Make a direct fetch call to the Edge Function for streaming support
      const functionUrl = `${supabaseUrl}/functions/v1/chat-stream`;

      const response = await fetch(functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseAnonKey}`,
        },
        body: JSON.stringify({ messages })
      });

      console.log('Edge Function response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Edge Function HTTP error:', errorText);
        
        let errorMessage = `Edge Function failed (${response.status})`;
        try {
          const errorJson = JSON.parse(errorText);
          if (errorJson.error) {
            errorMessage = errorJson.error;
          }
        } catch {
          if (errorText) {
            errorMessage += `: ${errorText}`;
          }
        }
        
        throw new Error(errorMessage);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error('No response body available');
      }

      let buffer = '';
      let hasReceivedData = false;

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) {
          if (hasReceivedData) {
            callbacks.onComplete();
          }
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (trimmedLine.startsWith('data: ')) {
            const data = trimmedLine.slice(6);
            
            if (data === '[DONE]') {
              callbacks.onComplete();
              return;
            }
            
            try {
              const parsed = JSON.parse(data);
              const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
              if (text) {
                hasReceivedData = true;
                callbacks.onChunk(text);
              }
            } catch (e) {
              console.error('Error parsing SSE data:', e, 'Data:', data);
            }
          }
        }
      }

      if (!hasReceivedData) {
        throw new Error('No data received from API');
      }
    } catch (error) {
      console.error('LLM streaming error:', error);
      
      let errorMessage = 'Failed to connect to AI service. Please try again.';
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage = 'Network error: Unable to connect to AI service. Please check your internet connection.';
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      callbacks.onError(errorMessage);
    }
  },

  async analyzePhishing(content: string): Promise<{ riskLevel: 'low' | 'medium' | 'high'; analysis: string }> {
    const prompt = `You are a cybersecurity expert. Analyze the following content for phishing indicators and provide:
1. Risk level (low, medium, or high)
2. Detailed explanation of why it's suspicious or safe

Content to analyze:
${content}

Respond in this exact format:
RISK_LEVEL: [low/medium/high]
ANALYSIS: [Your detailed analysis]`;

    let fullResponse = '';
    let error: string | null = null;

    await this.streamChat(
      [{ role: 'user', parts: [{ text: prompt }] }],
      {
        onChunk: (text) => {
          fullResponse += text;
        },
        onComplete: () => {},
        onError: (err) => {
          error = err;
        }
      }
    );

    if (error) {
      throw new Error(error);
    }

    const riskMatch = fullResponse.match(/RISK_LEVEL:\s*(low|medium|high)/i);
    const analysisMatch = fullResponse.match(/ANALYSIS:\s*(.+)/is);

    const riskLevel = (riskMatch?.[1]?.toLowerCase() as 'low' | 'medium' | 'high') || 'medium';
    const analysis = analysisMatch?.[1]?.trim() || fullResponse;

    return { riskLevel, analysis };
  },

  async generateImage(prompt: string): Promise<string> {
    try {
      console.log('Generating image with prompt:', prompt);

      const functionUrl = `${supabaseUrl}/functions/v1/generate-image`;

      const response = await fetch(functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseAnonKey}`,
        },
        body: JSON.stringify({ prompt })
      });

      console.log('Image generation response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Image generation HTTP error:', response.status, errorText);
        
        let errorMessage = 'Failed to generate image';
        try {
          const errorJson = JSON.parse(errorText);
          if (errorJson.error) {
            errorMessage = errorJson.error;
          }
        } catch {
          // Use default message
        }
        
        throw new Error(errorMessage);
      }

      const data = await response.json();
      console.log('Image generation response received:', data.success ? 'success' : 'failed');
      
      if (!data.success || !data.imageUrl) {
        const errorMsg = data.error || 'No image data received from API';
        console.error('Image generation failed:', errorMsg);
        throw new Error(errorMsg);
      }

      // Return data URL (already in correct format from Edge Function)
      return data.imageUrl;
    } catch (error) {
      console.error('Image generation error:', error);
      
      // Provide user-friendly error messages
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error('Network error: Unable to connect to image generation service. Please check your internet connection and try again.');
      }
      
      throw error instanceof Error ? error : new Error('Failed to generate image. Please try again later.');
    }
  }
};
