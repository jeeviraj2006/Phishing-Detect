import Home from './pages/Home';
import SecurityTools from './pages/SecurityTools';
import PhishingDetection from './pages/PhishingDetection';
import EmailMonitor from './pages/EmailMonitor';
import LoginPage from './pages/LoginPage';
import LearningResource from './pages/LearningResource';
import Settings from './pages/Settings';
import Feedback from './pages/Feedback';
import HelpSupport from './pages/HelpSupport';
import Quiz from './pages/Quiz';
import QuizLevel from './pages/QuizLevel';
import QuizModule from './pages/QuizModule';
import Badges from './pages/Badges';
import type { ComponentType } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  component: ComponentType;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    component: Home,
    visible: true
  },
  {
    name: 'Phishing Detection',
    path: '/phishing',
    component: PhishingDetection,
    visible: true
  },
  {
    name: 'Email Monitor',
    path: '/email-monitor',
    component: EmailMonitor,
    visible: true
  },
  {
    name: 'Security Tools',
    path: '/tools',
    component: SecurityTools,
    visible: true
  },
  {
    name: 'Quiz',
    path: '/quiz',
    component: Quiz,
    visible: true
  },
  {
    name: 'Badges',
    path: '/badges',
    component: Badges,
    visible: true
  },
  {
    name: 'Quiz Level',
    path: '/quiz/level/:levelId',
    component: QuizLevel,
    visible: false
  },
  {
    name: 'Quiz Module',
    path: '/quiz/:levelId/:moduleNumber',
    component: QuizModule,
    visible: false
  },
  {
    name: 'Learning Resource',
    path: '/learn/:resourceId',
    component: LearningResource,
    visible: false
  },
  {
    name: 'Settings',
    path: '/settings',
    component: Settings,
    visible: false
  },
  {
    name: 'Feedback',
    path: '/feedback',
    component: Feedback,
    visible: false
  },
  {
    name: 'Help & Support',
    path: '/help',
    component: HelpSupport,
    visible: false
  },
  {
    name: 'Login',
    path: '/login',
    component: LoginPage,
    visible: false
  }
];

export default routes;
