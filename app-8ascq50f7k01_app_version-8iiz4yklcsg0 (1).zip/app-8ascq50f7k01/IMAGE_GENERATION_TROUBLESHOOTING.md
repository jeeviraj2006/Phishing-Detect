# Image Generation Troubleshooting Guide

## Current Status

**API**: Advanced Image Generation API (Task-based)
**Edge Function**: generate-image (Version 6)
**Status**: ACTIVE
**Plugin ID**: 91679aa4-d5c4-478e-bd7a-4f7f1ad52eec

---

## How Image Generation Works

### Step-by-Step Process

1. **User sends prompt** with trigger words (e.g., "generate image of...")
2. **Frontend detects** image generation request
3. **Calls Edge Function** (`generate-image`)
4. **Edge Function submits task** to Image Generation API
5. **Receives task ID** from API
6. **Polls for completion** every 10 seconds (max 60 attempts = 10 minutes)
7. **Extracts image** from response when status = SUCCESS
8. **Returns data URL** to frontend
9. **Displays image** in chat interface

### Expected Timeline

- **Fast**: 30-60 seconds
- **Average**: 1-2 minutes
- **Slow**: 2-5 minutes
- **Maximum**: 10 minutes (then timeout)

---

## Common Issues and Solutions

### Issue 1: "Network error: Unable to connect to image generation service"

**Cause**: Cannot reach the API endpoint

**Solutions**:
1. Check internet connection
2. Verify Supabase Edge Function is deployed and ACTIVE
3. Check if API endpoint is accessible
4. Wait a few minutes and try again (API might be temporarily down)

**How to verify**:
```bash
# Check Edge Function status
curl -X POST https://[your-supabase-url]/functions/v1/generate-image \
  -H "Authorization: Bearer [anon-key]" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"test"}'
```

---

### Issue 2: "Image generation timeout"

**Cause**: Task took longer than 10 minutes

**Solutions**:
1. Try a simpler prompt
2. Try again later (API might be overloaded)
3. Check if the API service is experiencing issues

**Prevention**:
- Use clear, concise prompts
- Avoid overly complex descriptions
- Try during off-peak hours

---

### Issue 3: "Image generation failed: NO_IMAGE"

**Cause**: API couldn't generate image from prompt

**Solutions**:
1. Rephrase your prompt to be more specific
2. Avoid prompts that might violate content policies
3. Try a different subject or style

**Good prompts**:
- ✅ "A blue shield icon with a lock symbol, cybersecurity theme"
- ✅ "A cartoon hacker character with a laptop, friendly style"
- ✅ "A network diagram showing secure connections, professional"

**Problematic prompts**:
- ❌ Vague descriptions
- ❌ Inappropriate content
- ❌ Copyrighted characters or brands

---

### Issue 4: "Failed to generate image: 500"

**Cause**: Internal server error in Edge Function or API

**Solutions**:
1. Check Edge Function logs in Supabase dashboard
2. Verify Edge Function is properly deployed
3. Check if APP_ID environment variable is set
4. Redeploy Edge Function if needed

**How to check logs**:
1. Go to Supabase Dashboard
2. Navigate to Edge Functions
3. Select `generate-image`
4. View logs for error details

---

### Issue 5: "No image data received from API"

**Cause**: API returned success but no image in response

**Solutions**:
1. Check API response format
2. Verify markdown extraction regex is correct
3. Check if API changed response format
4. Try again with a different prompt

**Expected response format**:
```json
{
  "status": 0,
  "data": {
    "status": "SUCCESS",
    "result": {
      "candidates": [{
        "content": {
          "parts": [{
            "text": "![image](data:image/jpeg;base64,...)"
          }]
        }
      }]
    }
  }
}
```

---

## Debugging Steps

### Step 1: Check Edge Function Status

```bash
# In Supabase Dashboard:
1. Go to Edge Functions
2. Find "generate-image"
3. Verify status is ACTIVE
4. Check version number (should be 6 or higher)
```

### Step 2: Test Edge Function Directly

```bash
curl -X POST https://[your-project].supabase.co/functions/v1/generate-image \
  -H "Authorization: Bearer [your-anon-key]" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"A simple blue circle"}'
```

**Expected**: Should return task submission confirmation or start polling

### Step 3: Check Browser Console

1. Open browser DevTools (F12)
2. Go to Console tab
3. Try generating an image
4. Look for error messages

**Key logs to check**:
- "Generating image with prompt: ..."
- "Image generation response status: ..."
- "Image generation error: ..."

### Step 4: Check Network Tab

1. Open browser DevTools (F12)
2. Go to Network tab
3. Try generating an image
4. Find the `generate-image` request
5. Check request/response details

**What to look for**:
- Request payload contains prompt
- Response status code (200 = success, 4xx/5xx = error)
- Response body contains error message

---

## API Endpoints

### Submit Task
```
POST https://api-integrations.appmedo.com/app-8ascq50f7k01/api-BYdwzE2qzDDL/image-generation/submit
```

**Request**:
```json
{
  "contents": [{
    "parts": [{
      "text": "your prompt here"
    }]
  }]
}
```

**Response**:
```json
{
  "status": 0,
  "data": {
    "taskId": "task-...",
    "status": "PENDING",
    "estimatedTime": 600
  }
}
```

### Query Task
```
POST https://api-integrations.appmedo.com/app-8ascq50f7k01/api-eLMlJRg7r4j9/image-generation/task
```

**Request**:
```json
{
  "taskId": "task-..."
}
```

**Response (Success)**:
```json
{
  "status": 0,
  "data": {
    "taskId": "task-...",
    "status": "SUCCESS",
    "result": {
      "candidates": [{
        "content": {
          "parts": [{
            "text": "![image](data:image/jpeg;base64,...)"
          }]
        }
      }]
    }
  }
}
```

---

## Error Messages Explained

### Frontend Error Messages

| Error Message | Meaning | Action |
|--------------|---------|--------|
| "Network error: Unable to connect..." | Cannot reach API | Check internet, wait and retry |
| "Image generation timeout" | Took longer than 10 minutes | Try simpler prompt, retry later |
| "Image generation failed: NO_IMAGE" | API couldn't create image | Rephrase prompt, avoid problematic content |
| "Failed to generate image: 500" | Server error | Check logs, redeploy function |
| "No image data received from API" | Invalid response format | Check API response, contact support |

### Edge Function Error Messages

| Error Message | Meaning | Action |
|--------------|---------|--------|
| "Invalid request: prompt string required" | Missing or invalid prompt | Check request payload |
| "Failed to submit task: 4xx/5xx" | API rejected submission | Check API status, verify credentials |
| "No task ID received" | API didn't return taskId | Check API response format |
| "Query API HTTP error: ..." | Polling request failed | Temporary issue, will retry |
| "Task failed: ..." | API reported failure | Check error code/message |

---

## Performance Optimization

### Tips for Faster Generation

1. **Use simple prompts**: Shorter, clearer prompts generate faster
2. **Avoid complex scenes**: Single objects generate faster than complex scenes
3. **Try during off-peak hours**: Less API load = faster generation
4. **Be patient**: First poll is after 5 seconds, then every 10 seconds

### Prompt Best Practices

**Fast prompts** (30-60 seconds):
- "A blue shield icon"
- "A simple lock symbol"
- "A red warning sign"

**Slower prompts** (1-2 minutes):
- "A detailed cybersecurity dashboard with multiple charts"
- "A complex network diagram with servers and connections"
- "A realistic hacker in a dark room with multiple monitors"

---

## Monitoring and Maintenance

### Regular Checks

1. **Weekly**: Check Edge Function status in Supabase dashboard
2. **Monthly**: Review error logs for patterns
3. **As needed**: Redeploy Edge Function if issues persist

### When to Redeploy

- After API endpoint changes
- After error handling improvements
- If Edge Function shows as INACTIVE
- If persistent errors occur

### How to Redeploy

```bash
# From project root
cd /workspace/app-8ascq50f7k01

# Deploy Edge Function
# (This is done automatically by the system)
```

---

## Contact and Support

### If Issues Persist

1. **Check API Status**: Verify the Image Generation API is operational
2. **Review Logs**: Check Supabase Edge Function logs for detailed errors
3. **Test Manually**: Use curl to test API endpoints directly
4. **Simplify Prompt**: Try with a very simple prompt like "a blue circle"
5. **Wait and Retry**: Sometimes API is temporarily overloaded

### Useful Resources

- **Supabase Dashboard**: Monitor Edge Function status and logs
- **Browser DevTools**: Check network requests and console errors
- **API Documentation**: Review API requirements and response formats

---

## Version History

### Version 6 (Current)
- **Date**: December 2024
- **Changes**: 
  - Improved error handling with try-catch for network errors
  - Better logging for debugging
  - More detailed error messages
  - Graceful handling of API failures

### Version 5
- **Date**: December 2024
- **Changes**: 
  - Switched to Advanced Image Generation API
  - Implemented task-based polling system
  - Added 10-minute timeout
  - Improved status handling

### Version 4 and Earlier
- Used Nano Banana API (deprecated)

---

## FAQ

### Q: Why does image generation take so long?

**A**: AI image generation is computationally intensive. The API needs to:
1. Process your prompt
2. Generate the image using AI models
3. Encode the image as base64
4. Return the result

This typically takes 1-2 minutes, which is normal for AI image generation.

---

### Q: Can I generate multiple images at once?

**A**: Currently, the system processes one image at a time. You can request multiple images sequentially, but each will take 1-2 minutes.

---

### Q: What image formats are supported?

**A**: The API returns images as base64-encoded data URLs in JPEG or PNG format. These are automatically displayed in the chat interface.

---

### Q: Are there any content restrictions?

**A**: Yes, the API may reject prompts that:
- Violate content policies
- Request inappropriate content
- Use copyrighted characters or brands
- Are too vague or unclear

---

### Q: How can I improve image quality?

**A**: Use detailed, specific prompts:
- Describe the subject clearly
- Mention the style (e.g., "cartoon", "realistic", "professional")
- Include important details (colors, composition, mood)
- Add quality keywords (e.g., "high definition", "detailed")

---

### Q: What happens if generation fails?

**A**: The system will:
1. Show an error message with details
2. Save the error message to chat history
3. Allow you to try again
4. Continue working for other chat functions

---

## Conclusion

Image generation is a powerful feature that enhances the CyberGuard AI Assistant. While it may take 1-2 minutes to generate images, the results are worth the wait. If you encounter issues, follow the troubleshooting steps above or try again with a simpler prompt.

**Remember**: The image generation feature is optional. The chatbot continues to work perfectly for cybersecurity questions and advice even if image generation is temporarily unavailable.

---

*Last Updated: December 2024*
*Edge Function Version: 6*
*Status: ACTIVE*
