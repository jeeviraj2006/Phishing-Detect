/*
# Update Quiz System Structure: 8 Levels with 7 Modules Each

## Overview
This migration updates the quiz system to:
- 8 levels (increased from 6)
- 7 modules per level (changed from 8)
- Total: 56 modules (8 × 7)

## Changes
1. Clear existing data
2. Add 2 new levels (Level 7 and Level 8)
3. Recreate all modules with 7 per level
4. Clear existing questions (will be repopulated with 10 per module)

## New Level Structure
- Level 1: Cybersecurity Fundamentals
- Level 2: Password & Authentication Security
- Level 3: Phishing & Social Engineering Defense
- Level 4: Network & Wi-Fi Security
- Level 5: Data Privacy & Encryption
- Level 6: Mobile & IoT Security
- Level 7: Advanced Threat Protection
- Level 8: Security Operations & Incident Response
*/

-- Clear existing data
DELETE FROM user_badges;
DELETE FROM user_quiz_progress;
DELETE FROM quiz_questions;
DELETE FROM quiz_modules;
DELETE FROM quiz_levels;

-- Insert 8 levels
INSERT INTO quiz_levels (id, title, description, badge_name, badge_icon) VALUES
(1, 'Cybersecurity Fundamentals', 'Master the essential concepts and principles of cybersecurity', 'Security Novice', '🛡️'),
(2, 'Password & Authentication Security', 'Learn advanced password management and authentication techniques', 'Password Guardian', '🔐'),
(3, 'Phishing & Social Engineering Defense', 'Identify and defend against manipulation and deception attacks', 'Phishing Detector', '🎣'),
(4, 'Network & Wi-Fi Security', 'Secure networks, connections, and wireless communications', 'Network Defender', '🌐'),
(5, 'Data Privacy & Encryption', 'Protect personal data and understand encryption technologies', 'Privacy Champion', '🔒'),
(6, 'Mobile & IoT Security', 'Secure mobile devices and Internet of Things ecosystems', 'Mobile Guardian', '📱'),
(7, 'Advanced Threat Protection', 'Defend against sophisticated malware and cyber attacks', 'Threat Hunter', '⚡'),
(8, 'Security Operations & Incident Response', 'Master security monitoring and incident management', 'Cyber Expert', '🏆');

-- Insert modules for Level 1: Cybersecurity Fundamentals (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(1, 1, 'Introduction to Cybersecurity', 'Understanding what cybersecurity is and why it matters'),
(1, 2, 'Common Cyber Threats', 'Learn about viruses, malware, and other digital threats'),
(1, 3, 'Safe Browsing Habits', 'Best practices for browsing the internet safely'),
(1, 4, 'Email Security Basics', 'Protecting yourself from email-based threats'),
(1, 5, 'Social Media Safety', 'Protecting your privacy on social platforms'),
(1, 6, 'Software Updates & Patches', 'Why updates matter and how to manage them'),
(1, 7, 'Basic Security Tools', 'Essential security software and tools');

-- Insert modules for Level 2: Password & Authentication Security (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(2, 1, 'Password Fundamentals', 'What makes a password strong or weak'),
(2, 2, 'Creating Strong Passwords', 'Techniques for generating secure passwords'),
(2, 3, 'Password Managers', 'Using tools to manage your passwords safely'),
(2, 4, 'Two-Factor Authentication', 'Adding an extra layer of security'),
(2, 5, 'Multi-Factor Authentication', 'Advanced authentication methods and biometrics'),
(2, 6, 'Password Recovery & Reset', 'Safe methods for recovering lost passwords'),
(2, 7, 'Common Password Mistakes', 'Avoiding dangerous password practices');

-- Insert modules for Level 3: Phishing & Social Engineering Defense (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(3, 1, 'What is Phishing?', 'Understanding phishing attacks and their goals'),
(3, 2, 'Email Phishing Detection', 'Identifying fake emails and suspicious messages'),
(3, 3, 'SMS & Voice Phishing', 'Recognizing phone and text message scams'),
(3, 4, 'Website Spoofing & Fake Sites', 'Detecting fake websites and URLs'),
(3, 5, 'Social Engineering Tactics', 'How attackers manipulate people'),
(3, 6, 'Spear Phishing & Targeted Attacks', 'Defending against personalized attacks'),
(3, 7, 'Reporting & Response', 'What to do when you encounter phishing');

-- Insert modules for Level 4: Network & Wi-Fi Security (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(4, 1, 'Network Basics', 'Understanding how networks work'),
(4, 2, 'Wi-Fi Security Protocols', 'WPA, WPA2, WPA3 and encryption standards'),
(4, 3, 'Public Wi-Fi Risks', 'Dangers of public networks and how to stay safe'),
(4, 4, 'VPN Technology', 'Using Virtual Private Networks for security'),
(4, 5, 'Firewall Protection', 'How firewalls protect your devices'),
(4, 6, 'Router Security', 'Securing your home network router'),
(4, 7, 'Network Monitoring', 'Detecting suspicious network activity');

-- Insert modules for Level 5: Data Privacy & Encryption (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(5, 1, 'Understanding Data Privacy', 'What is personal data and why it matters'),
(5, 2, 'Encryption Fundamentals', 'How encryption protects your data'),
(5, 3, 'Privacy Laws & Regulations', 'GDPR, CCPA, and your rights'),
(5, 4, 'Data Backup Strategies', 'Protecting your data from loss'),
(5, 5, 'Cloud Storage Security', 'Safely using cloud services'),
(5, 6, 'Digital Footprint Management', 'Managing your online presence'),
(5, 7, 'Data Breach Response', 'What to do if your data is compromised');

-- Insert modules for Level 6: Mobile & IoT Security (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(6, 1, 'Mobile Device Security Basics', 'Securing smartphones and tablets'),
(6, 2, 'App Permissions & Privacy', 'Understanding and managing app access'),
(6, 3, 'Mobile Malware & Threats', 'Protecting against mobile-specific attacks'),
(6, 4, 'Secure Mobile Communications', 'Encrypted messaging and calls'),
(6, 5, 'IoT Device Security', 'Securing smart home and IoT devices'),
(6, 6, 'Mobile Payment Security', 'Safe mobile banking and payments'),
(6, 7, 'Device Loss & Theft Protection', 'Remote wipe and tracking features');

-- Insert modules for Level 7: Advanced Threat Protection (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(7, 1, 'Advanced Malware Types', 'Ransomware, trojans, and sophisticated threats'),
(7, 2, 'Zero-Day Exploits', 'Understanding unknown vulnerabilities'),
(7, 3, 'APT Attacks', 'Advanced Persistent Threats and nation-state actors'),
(7, 4, 'Cryptojacking & Mining Malware', 'Detecting unauthorized cryptocurrency mining'),
(7, 5, 'Supply Chain Attacks', 'Understanding third-party security risks'),
(7, 6, 'Threat Intelligence', 'Staying informed about emerging threats'),
(7, 7, 'Security Auditing', 'Assessing and improving security posture');

-- Insert modules for Level 8: Security Operations & Incident Response (7 modules)
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(8, 1, 'Incident Response Planning', 'Preparing for security incidents'),
(8, 2, 'Security Monitoring', 'Continuous monitoring and alerting'),
(8, 3, 'Log Analysis & SIEM', 'Security Information and Event Management'),
(8, 4, 'Digital Forensics', 'Investigating cyber attacks'),
(8, 5, 'Vulnerability Management', 'Identifying and patching vulnerabilities'),
(8, 6, 'Security Compliance', 'Meeting regulatory requirements'),
(8, 7, 'Career in Cybersecurity', 'Paths to becoming a security professional');