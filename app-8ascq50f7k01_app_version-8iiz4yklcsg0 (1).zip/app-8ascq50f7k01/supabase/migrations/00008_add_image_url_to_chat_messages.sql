/*
# Add image_url column to chat_messages table

## Changes
- Add optional `image_url` column to `chat_messages` table to store generated images

## Purpose
- Enable chatbot to generate and display images
- Store image data URLs in chat history
- Support multimodal chat experience
*/

ALTER TABLE chat_messages 
ADD COLUMN IF NOT EXISTS image_url text;
