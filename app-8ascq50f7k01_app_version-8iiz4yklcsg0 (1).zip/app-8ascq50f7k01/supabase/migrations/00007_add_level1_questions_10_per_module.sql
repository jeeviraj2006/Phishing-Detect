/*
# Add Level 1 Questions - 10 Questions Per Module

## Overview
This migration adds 10 questions for each of the 7 modules in Level 1.
Total: 70 questions for Level 1 (Cybersecurity Fundamentals)

## Module Coverage
- Module 1: Introduction to Cybersecurity (10 questions)
- Module 2: Common Cyber Threats (10 questions)
- Module 3: Safe Browsing Habits (10 questions)
- Module 4: Email Security Basics (10 questions)
- Module 5: Social Media Safety (10 questions)
- Module 6: Software Updates & Patches (10 questions)
- Module 7: Basic Security Tools (10 questions)
*/

-- Module 1: Introduction to Cybersecurity (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is cybersecurity?', 
'["A type of computer game", "Protection of computer systems and networks from digital attacks", "A social media platform", "A programming language"]'::jsonb,
1,
'Cybersecurity is the practice of protecting computer systems, networks, and data from digital attacks, unauthorized access, and damage.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why is cybersecurity important for college students?',
'["It is not important", "To protect personal data and academic information", "Only for computer science majors", "To play online games"]'::jsonb,
1,
'College students handle sensitive personal and academic information online, making cybersecurity essential to protect against identity theft, data breaches, and academic fraud.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is the CIA triad in cybersecurity?',
'["Central Intelligence Agency", "Confidentiality, Integrity, Availability", "Computer Internet Access", "Cyber Investigation Agency"]'::jsonb,
1,
'The CIA triad represents the three core principles of information security: Confidentiality (keeping data private), Integrity (keeping data accurate), and Availability (ensuring authorized access).'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Which of the following is a cybersecurity threat?',
'["Antivirus software", "Malware", "Firewall", "Encryption"]'::jsonb,
1,
'Malware (malicious software) is a cybersecurity threat designed to damage, disrupt, or gain unauthorized access to computer systems. The other options are security tools.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do first if you suspect a security breach?',
'["Ignore it", "Disconnect from the network and report it", "Delete all files", "Share it on social media"]'::jsonb,
1,
'If you suspect a security breach, immediately disconnect from the network to prevent further damage and report it to your IT department or security team for proper investigation.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What does "confidentiality" mean in cybersecurity?',
'["Making data available to everyone", "Keeping sensitive information private and protected", "Deleting all data", "Sharing passwords"]'::jsonb,
1,
'Confidentiality means ensuring that sensitive information is accessible only to authorized individuals and protected from unauthorized disclosure.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is "integrity" in the context of data security?',
'["Data is colorful", "Data is accurate and has not been tampered with", "Data is deleted", "Data is shared publicly"]'::jsonb,
1,
'Integrity ensures that data remains accurate, complete, and unaltered except by authorized users through approved methods.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What does "availability" mean in cybersecurity?',
'["Data is deleted permanently", "Authorized users can access data when needed", "Everyone can access everything", "Data is hidden forever"]'::jsonb,
1,
'Availability ensures that information and resources are accessible to authorized users when they need them, without unnecessary delays or disruptions.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Who is responsible for cybersecurity?',
'["Only IT professionals", "Only the government", "Everyone who uses technology", "Only hackers"]'::jsonb,
2,
'Cybersecurity is everyone''s responsibility. Every user plays a role in protecting systems and data through safe practices and awareness.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a "cyber attack"?',
'["A video game", "An attempt to damage, disrupt, or gain unauthorized access to computer systems", "A type of computer", "A security tool"]'::jsonb,
1,
'A cyber attack is any deliberate attempt to compromise computer systems, networks, or data, often for malicious purposes like theft, disruption, or espionage.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

-- Module 2: Common Cyber Threats (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is malware?',
'["A type of hardware", "Malicious software designed to harm computers", "A security tool", "An email service"]'::jsonb,
1,
'Malware is short for malicious software - any program designed to harm, exploit, or otherwise compromise computer systems, networks, or data.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is ransomware?',
'["Free software", "Malware that encrypts files and demands payment", "A type of antivirus", "A cloud storage service"]'::jsonb,
1,
'Ransomware is malicious software that encrypts your files and demands payment (ransom) to restore access. It is one of the most dangerous types of malware.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a computer virus?',
'["A hardware problem", "Malware that replicates by inserting copies into other programs", "A type of email", "A security update"]'::jsonb,
1,
'A computer virus is malware that replicates itself by inserting copies into other programs or files, spreading from one computer to another like a biological virus.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a trojan horse in cybersecurity?',
'["A type of firewall", "Malware disguised as legitimate software", "A secure password", "An encryption method"]'::jsonb,
1,
'A trojan horse is malware that disguises itself as legitimate software to trick users into installing it, similar to the Greek myth of the Trojan Horse.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is spyware?',
'["Software that protects privacy", "Malware that secretly monitors user activity", "A type of browser", "A gaming application"]'::jsonb,
1,
'Spyware is malware that secretly monitors and collects information about user activities, browsing habits, and personal data without consent.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a worm in cybersecurity?',
'["A type of cable", "Self-replicating malware that spreads without user action", "A security feature", "A password"]'::jsonb,
1,
'A worm is self-replicating malware that can spread automatically across networks without requiring user action, unlike viruses which need a host program.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is adware?',
'["Software that blocks ads", "Software that displays unwanted advertisements", "A type of firewall", "An antivirus program"]'::jsonb,
1,
'Adware is software that automatically displays or downloads unwanted advertisements, often bundled with free software and can slow down your system.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a rootkit?',
'["A gardening tool", "Malware that hides its presence and gives attackers control", "A type of password", "A security certificate"]'::jsonb,
1,
'A rootkit is malware designed to hide its presence on a system while giving attackers privileged access and control, making it very difficult to detect and remove.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a botnet?',
'["A fishing net", "A network of infected computers controlled by attackers", "A type of browser", "A security tool"]'::jsonb,
1,
'A botnet is a network of infected computers (bots) controlled by attackers, often used to launch large-scale attacks, send spam, or mine cryptocurrency.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a keylogger?',
'["A door lock", "Malware that records keystrokes to steal passwords", "A keyboard shortcut", "A typing tutor"]'::jsonb,
1,
'A keylogger is malware that records every keystroke you type, allowing attackers to steal passwords, credit card numbers, and other sensitive information.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

-- Module 3: Safe Browsing Habits (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What does HTTPS stand for?',
'["Hyper Text Transfer Protocol Secure", "High Tech Transfer Protocol System", "Hyper Transfer Text Protocol Safe", "Home Text Transfer Protocol Secure"]'::jsonb,
0,
'HTTPS stands for Hyper Text Transfer Protocol Secure. The "S" indicates that the connection is encrypted, making it safer for transmitting sensitive information.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you look for to verify a website is secure?',
'["Colorful design", "Padlock icon and HTTPS in the URL", "Many advertisements", "Pop-up windows"]'::jsonb,
1,
'A secure website displays a padlock icon in the address bar and uses HTTPS in the URL, indicating that the connection is encrypted and authenticated.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is browser cache?',
'["A virus", "Temporary storage of web pages and files", "A type of malware", "A security tool"]'::jsonb,
1,
'Browser cache is temporary storage where your browser saves copies of web pages, images, and files to load websites faster on future visits.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you clear your browser cookies regularly?',
'["To make browsing slower", "To protect privacy and remove tracking data", "To delete bookmarks", "To uninstall the browser"]'::jsonb,
1,
'Clearing cookies regularly helps protect your privacy by removing tracking data that websites use to monitor your browsing behavior and build profiles about you.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is private/incognito browsing mode?',
'["A mode that makes you invisible online", "A mode that does not save browsing history locally", "A mode that prevents all tracking", "A mode that speeds up internet"]'::jsonb,
1,
'Private or incognito mode prevents your browser from saving your browsing history, cookies, and form data locally. However, it does not make you anonymous to websites or your internet provider.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What are browser extensions?',
'["Physical devices", "Add-on programs that enhance browser functionality", "Types of websites", "Computer viruses"]'::jsonb,
1,
'Browser extensions are add-on programs that enhance your browser''s functionality, but they can also pose security risks if they request excessive permissions or come from untrusted sources.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a secure DNS?',
'["A type of virus", "A system that translates domain names to IP addresses securely", "A password manager", "A social media platform"]'::jsonb,
1,
'Secure DNS (like DNS over HTTPS) encrypts domain name lookups, preventing attackers from seeing which websites you visit or redirecting you to malicious sites.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do if your browser warns about an unsafe website?',
'["Ignore the warning and proceed", "Close the tab and do not visit the site", "Disable security warnings", "Share the link with friends"]'::jsonb,
1,
'Browser security warnings indicate potential threats. Always close the tab and avoid visiting sites flagged as unsafe to protect your device and data.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is typosquatting?',
'["A typing exercise", "Registering misspelled domain names to trick users", "A security feature", "A browser setting"]'::jsonb,
1,
'Typosquatting is when attackers register domain names that are common misspellings of popular websites to trick users into visiting malicious sites.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you avoid clicking on pop-up ads?',
'["They are entertaining", "They may contain malware or lead to malicious sites", "They provide useful information", "They speed up browsing"]'::jsonb,
1,
'Pop-up ads can contain malware, lead to phishing sites, or trick you into downloading malicious software. Use a pop-up blocker and avoid clicking on them.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

-- Module 4: Email Security Basics (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is email spoofing?',
'["Sending too many emails", "Faking the sender address to appear from someone else", "Deleting emails", "Forwarding emails"]'::jsonb,
1,
'Email spoofing is when attackers fake the sender address to make an email appear to come from someone else, often used in phishing attacks.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do with suspicious email attachments?',
'["Open them immediately", "Do not open them and report to IT", "Forward to friends", "Download and scan later"]'::jsonb,
1,
'Never open suspicious email attachments as they may contain malware. Report them to your IT department or email provider instead.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is spam email?',
'["Important work emails", "Unsolicited bulk emails, often advertising or malicious", "Emails from friends", "Calendar invitations"]'::jsonb,
1,
'Spam is unsolicited bulk email, often containing advertisements, scams, or malicious content. Most email providers have filters to detect and block spam.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'How can you verify an email sender is legitimate?',
'["Trust all emails", "Check the full email address and look for inconsistencies", "Only read the subject line", "Click all links to verify"]'::jsonb,
1,
'Always check the full email address (not just the display name) and look for inconsistencies, spelling errors, or suspicious domains that might indicate a fake sender.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is BCC in email?',
'["Big Carbon Copy", "Blind Carbon Copy - hides recipients from each other", "Basic Computer Code", "Bulk Communication Channel"]'::jsonb,
1,
'BCC (Blind Carbon Copy) allows you to send emails to multiple recipients without revealing their email addresses to each other, protecting privacy.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is email encryption?',
'["Deleting emails", "Converting email content into unreadable code for security", "Sending emails faster", "Blocking spam"]'::jsonb,
1,
'Email encryption converts the content of your emails into unreadable code that can only be decrypted by the intended recipient, protecting sensitive information.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you check before clicking a link in an email?',
'["Nothing, just click", "Hover over the link to see the actual URL", "The email subject", "The sender name only"]'::jsonb,
1,
'Always hover over links to see the actual URL before clicking. Phishing emails often hide malicious URLs behind legitimate-looking text.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a phishing email?',
'["A legitimate business email", "A fraudulent email designed to steal information", "A newsletter", "An automated response"]'::jsonb,
1,
'A phishing email is a fraudulent message designed to trick you into revealing sensitive information like passwords, credit card numbers, or personal data.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is SPF in email security?',
'["Spam Protection Filter", "Sender Policy Framework - verifies sender authenticity", "Special Password Format", "Secure Personal Files"]'::jsonb,
1,
'SPF (Sender Policy Framework) is an email authentication method that helps verify that emails claiming to be from a domain are actually authorized by that domain''s owner.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you be cautious of urgent or threatening emails?',
'["They are always legitimate", "Attackers use urgency to pressure quick action without thinking", "They are from friends", "They contain important news"]'::jsonb,
1,
'Attackers often create a sense of urgency or fear to pressure you into acting quickly without thinking critically, making you more likely to fall for scams.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

-- Module 5: Social Media Safety (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What information should you avoid sharing on social media?',
'["Your favorite color", "Home address, phone number, and location", "Your hobbies", "Your favorite movies"]'::jsonb,
1,
'Avoid sharing sensitive personal information like home address, phone number, real-time location, financial details, or anything that could be used for identity theft or stalking.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What are privacy settings on social media?',
'["Settings to delete your account", "Controls for who can see your posts and information", "Settings to change your username", "Settings to block advertisements"]'::jsonb,
1,
'Privacy settings allow you to control who can see your posts, profile information, and activity on social media platforms. Always review and adjust these settings.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is oversharing on social media?',
'["Posting too many cat videos", "Sharing too much personal information publicly", "Following too many people", "Liking too many posts"]'::jsonb,
1,
'Oversharing is posting too much personal information publicly, which can be exploited by criminals for identity theft, social engineering, or physical threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you be careful about accepting friend requests from strangers?',
'["They might post boring content", "They could be fake accounts used for scams or data harvesting", "They might unfriend you later", "They might have different interests"]'::jsonb,
1,
'Fake accounts are often used for scams, phishing, data harvesting, or catfishing. Only accept friend requests from people you know and trust in real life.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is geotagging in social media posts?',
'["Adding hashtags", "Embedding location data in photos and posts", "Tagging friends", "Adding filters to photos"]'::jsonb,
1,
'Geotagging embeds your location data in photos and posts, revealing where you are or have been. Disable this feature to protect your privacy and physical security.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is catfishing?',
'["A fishing technique", "Creating fake online identities to deceive people", "A type of malware", "A social media feature"]'::jsonb,
1,
'Catfishing is when someone creates a fake online identity to deceive others, often for romance scams, financial fraud, or emotional manipulation.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you think before you post on social media?',
'["It is not necessary", "Posts can be permanent and affect your reputation", "To save time", "To get more likes"]'::jsonb,
1,
'Social media posts can be permanent, screenshot, and shared. They can affect your reputation, job prospects, and relationships. Always think before posting.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is doxxing?',
'["A social media feature", "Publicly revealing someone private information without consent", "A type of post", "A privacy setting"]'::jsonb,
1,
'Doxxing is the malicious act of publicly revealing someone''s private information (address, phone, workplace) without consent, often for harassment or intimidation.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do if you experience cyberbullying?',
'["Respond with insults", "Block the person, save evidence, and report to platform", "Delete your account", "Ignore it completely"]'::jsonb,
1,
'If you experience cyberbullying, block the person, save evidence (screenshots), report to the platform, and seek support from trusted adults or authorities.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is two-factor authentication on social media?',
'["Using two passwords", "An extra security layer requiring a second verification method", "Having two accounts", "Posting twice"]'::jsonb,
1,
'Two-factor authentication adds an extra security layer by requiring a second verification method (like a code sent to your phone) in addition to your password.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

-- Module 6: Software Updates & Patches (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why are software updates important for security?',
'["They make software slower", "They fix security vulnerabilities and bugs", "They change the interface", "They cost money"]'::jsonb,
1,
'Software updates fix security vulnerabilities, patch bugs, and improve protection against new threats. Keeping software updated is one of the most important security practices.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a security patch?',
'["A physical repair", "An update that fixes security vulnerabilities", "A type of antivirus", "A hardware component"]'::jsonb,
1,
'A security patch is a software update specifically designed to fix security vulnerabilities that could be exploited by attackers.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'How often should you check for software updates?',
'["Never", "Regularly, ideally enable automatic updates", "Once a year", "Only when the computer breaks"]'::jsonb,
1,
'Check for updates regularly and enable automatic updates when possible to ensure you have the latest security patches and protection against new threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is end-of-life (EOL) software?',
'["Software that is too expensive", "Software that no longer receives updates or support", "Software that is very popular", "Software that is open source"]'::jsonb,
1,
'End-of-life software no longer receives security updates or support from the developer, making it vulnerable to attacks. Stop using EOL software and upgrade to supported versions.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do before installing a major software update?',
'["Nothing", "Backup your important data", "Delete all files", "Uninstall all programs"]'::jsonb,
1,
'Always backup your important data before installing major updates in case something goes wrong during the update process.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a zero-day vulnerability?',
'["A vulnerability that costs nothing", "A security flaw unknown to the software vendor", "A vulnerability that takes zero days to fix", "A type of malware"]'::jsonb,
1,
'A zero-day vulnerability is a security flaw that is unknown to the software vendor, meaning there is no patch available yet, making it particularly dangerous.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why do operating system updates matter?',
'["They only change colors", "They fix critical security flaws in the core system", "They are optional", "They slow down computers"]'::jsonb,
1,
'Operating system updates fix critical security flaws in the core system that protects all your applications and data. They are essential for overall security.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is automatic update?',
'["Manual installation", "Software updates installed automatically without user intervention", "A type of malware", "A security threat"]'::jsonb,
1,
'Automatic updates allow software to download and install updates automatically, ensuring you always have the latest security patches without manual intervention.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do if an update fails to install?',
'["Ignore it", "Try again, check for errors, or contact support", "Uninstall the software", "Buy a new computer"]'::jsonb,
1,
'If an update fails, try installing it again, check for error messages, ensure you have enough storage space, or contact technical support for assistance.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is firmware?',
'["A type of virus", "Low-level software that controls hardware devices", "A social media platform", "A web browser"]'::jsonb,
1,
'Firmware is low-level software that controls hardware devices. Firmware updates are important for security and should be installed when available.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

-- Module 7: Basic Security Tools (10 questions)
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is antivirus software?',
'["Software that creates viruses", "Software that detects and removes malware", "A type of operating system", "A web browser"]'::jsonb,
1,
'Antivirus software detects, prevents, and removes malware from your computer, providing real-time protection against various threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a firewall?',
'["A physical wall", "A security system that monitors and controls network traffic", "A type of password", "An email filter"]'::jsonb,
1,
'A firewall is a security system that monitors and controls incoming and outgoing network traffic based on security rules, acting as a barrier between trusted and untrusted networks.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a password manager?',
'["A person who remembers passwords", "Software that securely stores and manages passwords", "A type of lock", "A security guard"]'::jsonb,
1,
'A password manager is software that securely stores, generates, and manages your passwords, allowing you to use strong unique passwords for each account without memorizing them all.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is two-factor authentication (2FA)?',
'["Using two passwords", "A security method requiring two forms of verification", "A type of firewall", "A backup system"]'::jsonb,
1,
'Two-factor authentication (2FA) requires two different forms of verification to access an account, typically something you know (password) and something you have (phone or security key).'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is encryption?',
'["Deleting files", "Converting data into unreadable code to protect it", "Backing up data", "Compressing files"]'::jsonb,
1,
'Encryption converts data into unreadable code that can only be decrypted with the correct key, protecting sensitive information from unauthorized access even if intercepted.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a VPN?',
'["A type of virus", "Virtual Private Network - encrypts internet connection", "A social media platform", "A password"]'::jsonb,
1,
'A VPN (Virtual Private Network) encrypts your internet connection and routes it through a secure server, protecting your privacy and data from eavesdropping.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is anti-malware software?',
'["Software that creates malware", "Software that detects and removes various types of malware", "A type of game", "A web browser"]'::jsonb,
1,
'Anti-malware software is designed to detect and remove various types of malicious software including viruses, trojans, spyware, and ransomware.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a security suite?',
'["A hotel room", "Comprehensive security software with multiple protection tools", "A type of password", "A social media platform"]'::jsonb,
1,
'A security suite is comprehensive security software that combines multiple protection tools like antivirus, firewall, anti-spam, and parental controls in one package.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a backup tool?',
'["A spare tire", "Software that creates copies of your data for recovery", "A type of malware", "A web browser"]'::jsonb,
1,
'A backup tool creates copies of your data and stores them safely, allowing you to recover your files if they are lost, deleted, or encrypted by ransomware.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a security scanner?',
'["A physical device", "Software that checks systems for vulnerabilities", "A type of printer", "A password"]'::jsonb,
1,
'A security scanner is software that checks your systems, networks, and applications for vulnerabilities, misconfigurations, and security weaknesses that need to be addressed.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;