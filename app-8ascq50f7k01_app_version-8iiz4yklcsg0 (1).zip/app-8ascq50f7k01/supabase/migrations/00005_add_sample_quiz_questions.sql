/*
# Add Sample Quiz Questions for Level 1

## Overview
This migration adds 5 sample questions for each of the 8 modules in Level 1 (Cybersecurity Basics).
Total: 40 questions for Level 1.

## Question Format
- Multiple choice with 4 options
- Options stored as JSON array
- Correct answer index (0-3)
- Explanation provided for learning

## Coverage
- Module 1: Introduction to Cybersecurity (5 questions)
- Module 2: Common Cyber Threats (5 questions)
- Module 3: Safe Browsing Habits (5 questions)
- Module 4: Email Security Basics (5 questions)
- Module 5: Mobile Device Security (5 questions)
- Module 6: Social Media Safety (5 questions)
- Module 7: Software Updates (5 questions)
- Module 8: Basic Security Tools (5 questions)
*/

-- Module 1: Introduction to Cybersecurity
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is cybersecurity?', 
'["A type of computer game", "Protection of computer systems and networks from digital attacks", "A social media platform", "A programming language"]'::jsonb,
1,
'Cybersecurity is the practice of protecting computer systems, networks, and data from digital attacks, unauthorized access, and damage.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why is cybersecurity important for college students?',
'["It is not important", "To protect personal data and academic information", "Only for computer science majors", "To play online games"]'::jsonb,
1,
'College students handle sensitive personal and academic information online, making cybersecurity essential to protect against identity theft, data breaches, and academic fraud.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is the CIA triad in cybersecurity?',
'["Central Intelligence Agency", "Confidentiality, Integrity, Availability", "Computer Internet Access", "Cyber Investigation Agency"]'::jsonb,
1,
'The CIA triad represents the three core principles of information security: Confidentiality (keeping data private), Integrity (keeping data accurate), and Availability (ensuring authorized access).'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Which of the following is a cybersecurity threat?',
'["Antivirus software", "Malware", "Firewall", "Encryption"]'::jsonb,
1,
'Malware (malicious software) is a cybersecurity threat designed to damage, disrupt, or gain unauthorized access to computer systems. The other options are security tools.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do first if you suspect a security breach?',
'["Ignore it", "Disconnect from the network and report it", "Delete all files", "Share it on social media"]'::jsonb,
1,
'If you suspect a security breach, immediately disconnect from the network to prevent further damage and report it to your IT department or security team for proper investigation.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 1;

-- Module 2: Common Cyber Threats
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is malware?',
'["A type of hardware", "Malicious software designed to harm computers", "A security tool", "An email service"]'::jsonb,
1,
'Malware is short for malicious software - any program designed to harm, exploit, or otherwise compromise computer systems, networks, or data.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is ransomware?',
'["Free software", "Malware that encrypts files and demands payment", "A type of antivirus", "A cloud storage service"]'::jsonb,
1,
'Ransomware is malicious software that encrypts your files and demands payment (ransom) to restore access. It is one of the most dangerous types of malware.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a computer virus?',
'["A hardware problem", "Malware that replicates by inserting copies into other programs", "A type of email", "A security update"]'::jsonb,
1,
'A computer virus is malware that replicates itself by inserting copies into other programs or files, spreading from one computer to another like a biological virus.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a trojan horse in cybersecurity?',
'["A type of firewall", "Malware disguised as legitimate software", "A secure password", "An encryption method"]'::jsonb,
1,
'A trojan horse is malware that disguises itself as legitimate software to trick users into installing it, similar to the Greek myth of the Trojan Horse.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is spyware?',
'["Software that protects privacy", "Malware that secretly monitors user activity", "A type of browser", "A gaming application"]'::jsonb,
1,
'Spyware is malware that secretly monitors and collects information about user activities, browsing habits, and personal data without consent.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 2;

-- Module 3: Safe Browsing Habits
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What does HTTPS stand for?',
'["Hyper Text Transfer Protocol Secure", "High Tech Transfer Protocol System", "Hyper Transfer Text Protocol Safe", "Home Text Transfer Protocol Secure"]'::jsonb,
0,
'HTTPS stands for Hyper Text Transfer Protocol Secure. The "S" indicates that the connection is encrypted, making it safer for transmitting sensitive information.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you look for to verify a website is secure?',
'["Colorful design", "Padlock icon and HTTPS in the URL", "Many advertisements", "Pop-up windows"]'::jsonb,
1,
'A secure website displays a padlock icon in the address bar and uses HTTPS in the URL, indicating that the connection is encrypted and authenticated.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is browser cache?',
'["A virus", "Temporary storage of web pages and files", "A type of malware", "A security tool"]'::jsonb,
1,
'Browser cache is temporary storage where your browser saves copies of web pages, images, and files to load websites faster on future visits.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you clear your browser cookies regularly?',
'["To make browsing slower", "To protect privacy and remove tracking data", "To delete bookmarks", "To uninstall the browser"]'::jsonb,
1,
'Clearing cookies regularly helps protect your privacy by removing tracking data that websites use to monitor your browsing behavior and build profiles about you.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is private/incognito browsing mode?',
'["A mode that makes you invisible online", "A mode that does not save browsing history locally", "A mode that prevents all tracking", "A mode that speeds up internet"]'::jsonb,
1,
'Private or incognito mode prevents your browser from saving your browsing history, cookies, and form data locally. However, it does not make you anonymous to websites or your internet provider.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 3;

-- Module 4: Email Security Basics
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is email spoofing?',
'["Sending too many emails", "Faking the sender address to appear from someone else", "Deleting emails", "Forwarding emails"]'::jsonb,
1,
'Email spoofing is when attackers fake the sender address to make an email appear to come from someone else, often used in phishing attacks.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do with suspicious email attachments?',
'["Open them immediately", "Do not open them and report to IT", "Forward to friends", "Download and scan later"]'::jsonb,
1,
'Never open suspicious email attachments as they may contain malware. Report them to your IT department or email provider instead.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is spam email?',
'["Important work emails", "Unsolicited bulk emails, often advertising or malicious", "Emails from friends", "Calendar invitations"]'::jsonb,
1,
'Spam is unsolicited bulk email, often containing advertisements, scams, or malicious content. Most email providers have filters to detect and block spam.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'How can you verify an email sender is legitimate?',
'["Trust all emails", "Check the full email address and look for inconsistencies", "Only read the subject line", "Click all links to verify"]'::jsonb,
1,
'Always check the full email address (not just the display name) and look for inconsistencies, spelling errors, or suspicious domains that might indicate a fake sender.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is BCC in email?',
'["Big Carbon Copy", "Blind Carbon Copy - hides recipients from each other", "Basic Computer Code", "Bulk Communication Channel"]'::jsonb,
1,
'BCC (Blind Carbon Copy) allows you to send emails to multiple recipients without revealing their email addresses to each other, protecting privacy.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 4;

-- Module 5: Mobile Device Security
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you use a screen lock on your mobile device?',
'["To save battery", "To prevent unauthorized access if lost or stolen", "To make it look cool", "To slow down the device"]'::jsonb,
1,
'A screen lock (PIN, password, pattern, or biometric) prevents unauthorized access to your device and data if it is lost, stolen, or left unattended.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What are app permissions?',
'["App prices", "Access rights apps request to device features and data", "App ratings", "App updates"]'::jsonb,
1,
'App permissions are access rights that apps request to use device features (camera, microphone, location) and data (contacts, photos). Always review and limit permissions.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Where should you download mobile apps from?',
'["Any website", "Official app stores only (Google Play, App Store)", "Email attachments", "Social media links"]'::jsonb,
1,
'Only download apps from official app stores (Google Play Store, Apple App Store) as they have security screening processes to detect malicious apps.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is mobile device encryption?',
'["A way to hide apps", "Converting data into unreadable code to protect it", "A type of screen protector", "A battery saving feature"]'::jsonb,
1,
'Mobile device encryption converts your data into unreadable code that can only be accessed with the correct password or biometric authentication, protecting it if the device is compromised.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do before selling or disposing of your mobile device?',
'["Just delete some photos", "Factory reset and remove all accounts", "Give it away as is", "Only remove the SIM card"]'::jsonb,
1,
'Before selling or disposing of a mobile device, perform a factory reset to erase all data and remove all accounts to prevent the next owner from accessing your personal information.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 5;

-- Module 6: Social Media Safety
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What information should you avoid sharing on social media?',
'["Your favorite color", "Home address, phone number, and location", "Your hobbies", "Your favorite movies"]'::jsonb,
1,
'Avoid sharing sensitive personal information like home address, phone number, real-time location, financial details, or anything that could be used for identity theft or stalking.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What are privacy settings on social media?',
'["Settings to delete your account", "Controls for who can see your posts and information", "Settings to change your username", "Settings to block advertisements"]'::jsonb,
1,
'Privacy settings allow you to control who can see your posts, profile information, and activity on social media platforms. Always review and adjust these settings.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is oversharing on social media?',
'["Posting too many cat videos", "Sharing too much personal information publicly", "Following too many people", "Liking too many posts"]'::jsonb,
1,
'Oversharing is posting too much personal information publicly, which can be exploited by criminals for identity theft, social engineering, or physical threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why should you be careful about accepting friend requests from strangers?',
'["They might post boring content", "They could be fake accounts used for scams or data harvesting", "They might unfriend you later", "They might have different interests"]'::jsonb,
1,
'Fake accounts are often used for scams, phishing, data harvesting, or catfishing. Only accept friend requests from people you know and trust in real life.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is geotagging in social media posts?',
'["Adding hashtags", "Embedding location data in photos and posts", "Tagging friends", "Adding filters to photos"]'::jsonb,
1,
'Geotagging embeds your location data in photos and posts, revealing where you are or have been. Disable this feature to protect your privacy and physical security.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 6;

-- Module 7: Software Updates
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'Why are software updates important for security?',
'["They make software slower", "They fix security vulnerabilities and bugs", "They change the interface", "They cost money"]'::jsonb,
1,
'Software updates fix security vulnerabilities, patch bugs, and improve protection against new threats. Keeping software updated is one of the most important security practices.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a security patch?',
'["A physical repair", "An update that fixes security vulnerabilities", "A type of antivirus", "A hardware component"]'::jsonb,
1,
'A security patch is a software update specifically designed to fix security vulnerabilities that could be exploited by attackers.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'How often should you check for software updates?',
'["Never", "Regularly, ideally enable automatic updates", "Once a year", "Only when the computer breaks"]'::jsonb,
1,
'Check for updates regularly and enable automatic updates when possible to ensure you have the latest security patches and protection against new threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is end-of-life (EOL) software?',
'["Software that is too expensive", "Software that no longer receives updates or support", "Software that is very popular", "Software that is open source"]'::jsonb,
1,
'End-of-life software no longer receives security updates or support from the developer, making it vulnerable to attacks. Stop using EOL software and upgrade to supported versions.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What should you do before installing a major software update?',
'["Nothing", "Backup your important data", "Delete all files", "Uninstall all programs"]'::jsonb,
1,
'Always backup your important data before installing major updates in case something goes wrong during the update process.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 7;

-- Module 8: Basic Security Tools
INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is antivirus software?',
'["Software that creates viruses", "Software that detects and removes malware", "A type of operating system", "A web browser"]'::jsonb,
1,
'Antivirus software detects, prevents, and removes malware from your computer, providing real-time protection against various threats.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 8;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a firewall?',
'["A physical wall", "A security system that monitors and controls network traffic", "A type of password", "An email filter"]'::jsonb,
1,
'A firewall is a security system that monitors and controls incoming and outgoing network traffic based on security rules, acting as a barrier between trusted and untrusted networks.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 8;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is a password manager?',
'["A person who remembers passwords", "Software that securely stores and manages passwords", "A type of lock", "A security guard"]'::jsonb,
1,
'A password manager is software that securely stores, generates, and manages your passwords, allowing you to use strong unique passwords for each account without memorizing them all.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 8;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is two-factor authentication (2FA)?',
'["Using two passwords", "A security method requiring two forms of verification", "A type of firewall", "A backup system"]'::jsonb,
1,
'Two-factor authentication (2FA) requires two different forms of verification to access an account, typically something you know (password) and something you have (phone or security key).'
FROM quiz_modules WHERE level_id = 1 AND module_number = 8;

INSERT INTO quiz_questions (module_id, question_text, options, correct_answer, explanation)
SELECT id, 'What is encryption?',
'["Deleting files", "Converting data into unreadable code to protect it", "Backing up data", "Compressing files"]'::jsonb,
1,
'Encryption converts data into unreadable code that can only be decrypted with the correct key, protecting sensitive information from unauthorized access even if intercepted.'
FROM quiz_modules WHERE level_id = 1 AND module_number = 8;