/*
# Create monitored_emails table for automatic email phishing detection

## Purpose
Store emails forwarded by users for automatic phishing analysis and alerting.

## Tables Created

### `monitored_emails`
- `id` (uuid, primary key) - Unique identifier for each monitored email
- `user_id` (uuid, foreign key) - References auth.users, owner of the email
- `sender` (text) - Email sender address
- `subject` (text) - Email subject line
- `content` (text) - Full email content/body
- `risk_level` (text) - Risk assessment: 'low', 'medium', or 'high'
- `analysis` (text) - AI-generated phishing analysis
- `is_read` (boolean) - Whether user has viewed the alert
- `created_at` (timestamptz) - When email was received and analyzed

## Security
- RLS enabled: Users can only see their own monitored emails
- Public read access: Disabled (private data)
- Users have full CRUD access to their own emails

## Indexes
- Index on user_id for fast user-specific queries
- Index on created_at for chronological sorting
- Index on risk_level for filtering by threat level
*/

-- Create monitored_emails table
CREATE TABLE IF NOT EXISTS monitored_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  sender text NOT NULL,
  subject text,
  content text NOT NULL,
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  analysis text NOT NULL,
  is_read boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_monitored_emails_user_id ON monitored_emails(user_id);
CREATE INDEX IF NOT EXISTS idx_monitored_emails_created_at ON monitored_emails(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitored_emails_risk_level ON monitored_emails(risk_level);
CREATE INDEX IF NOT EXISTS idx_monitored_emails_is_read ON monitored_emails(is_read);

-- Enable RLS
ALTER TABLE monitored_emails ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own monitored emails
CREATE POLICY "Users can view own monitored emails" ON monitored_emails
  FOR SELECT
  USING (auth.uid() = user_id);

-- Policy: Users can insert their own monitored emails
CREATE POLICY "Users can insert own monitored emails" ON monitored_emails
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own monitored emails
CREATE POLICY "Users can update own monitored emails" ON monitored_emails
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy: Users can delete their own monitored emails
CREATE POLICY "Users can delete own monitored emails" ON monitored_emails
  FOR DELETE
  USING (auth.uid() = user_id);

-- Function to get unread count for a user
CREATE OR REPLACE FUNCTION get_unread_email_count(uid uuid)
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT COUNT(*)::integer
  FROM monitored_emails
  WHERE user_id = uid AND is_read = false;
$$;