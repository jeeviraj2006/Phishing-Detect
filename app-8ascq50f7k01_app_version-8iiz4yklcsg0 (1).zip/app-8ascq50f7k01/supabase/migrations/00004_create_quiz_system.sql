/*
# Create Quiz System with Levels, Modules, and Badges

## Overview
This migration creates a comprehensive quiz system for cybersecurity education with:
- 6 progressive levels
- 8 modules per level (48 total modules)
- Questions and answers for each module
- User progress tracking
- Badge/achievement system

## Tables Created

### 1. quiz_levels
Stores the 6 main levels of the quiz system.
- `id` (integer, primary key): Level number (1-6)
- `title` (text): Level title
- `description` (text): Level description
- `badge_name` (text): Badge awarded on completion
- `badge_icon` (text): Badge icon/emoji
- `created_at` (timestamptz): Creation timestamp

### 2. quiz_modules
Stores 8 modules for each level (48 total modules).
- `id` (uuid, primary key): Unique module identifier
- `level_id` (integer): References quiz_levels(id)
- `module_number` (integer): Module number within level (1-8)
- `title` (text): Module title
- `description` (text): Module description
- `created_at` (timestamptz): Creation timestamp

### 3. quiz_questions
Stores multiple-choice questions for each module.
- `id` (uuid, primary key): Unique question identifier
- `module_id` (uuid): References quiz_modules(id)
- `question_text` (text): The question
- `options` (jsonb): Array of answer options
- `correct_answer` (integer): Index of correct answer (0-3)
- `explanation` (text): Explanation of correct answer
- `created_at` (timestamptz): Creation timestamp

### 4. user_quiz_progress
Tracks user progress through modules.
- `id` (uuid, primary key): Unique progress record
- `user_id` (uuid): References auth.users(id)
- `module_id` (uuid): References quiz_modules(id)
- `score` (integer): Score achieved (0-100)
- `completed` (boolean): Module completion status
- `completed_at` (timestamptz): Completion timestamp
- `created_at` (timestamptz): Creation timestamp

### 5. user_badges
Stores badges earned by users.
- `id` (uuid, primary key): Unique badge record
- `user_id` (uuid): References auth.users(id)
- `level_id` (integer): References quiz_levels(id)
- `earned_at` (timestamptz): When badge was earned
- `created_at` (timestamptz): Creation timestamp

## Security
- All tables are public (no RLS) for easy access
- Users can view all quiz content
- Users can track their own progress
- Badge system tracks achievements

## Initial Data
- 6 levels with cybersecurity themes
- 8 modules per level (48 total)
- 5 questions per module (240 total questions)
- Progressive difficulty from Level 1 to Level 6
*/

-- Create quiz_levels table
CREATE TABLE IF NOT EXISTS quiz_levels (
  id integer PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  badge_name text NOT NULL,
  badge_icon text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create quiz_modules table
CREATE TABLE IF NOT EXISTS quiz_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  level_id integer NOT NULL REFERENCES quiz_levels(id) ON DELETE CASCADE,
  module_number integer NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(level_id, module_number)
);

-- Create quiz_questions table
CREATE TABLE IF NOT EXISTS quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid NOT NULL REFERENCES quiz_modules(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  options jsonb NOT NULL,
  correct_answer integer NOT NULL,
  explanation text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create user_quiz_progress table
CREATE TABLE IF NOT EXISTS user_quiz_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  module_id uuid NOT NULL REFERENCES quiz_modules(id) ON DELETE CASCADE,
  score integer NOT NULL DEFAULT 0,
  completed boolean DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, module_id)
);

-- Create user_badges table
CREATE TABLE IF NOT EXISTS user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  level_id integer NOT NULL REFERENCES quiz_levels(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, level_id)
);

-- Insert 6 levels
INSERT INTO quiz_levels (id, title, description, badge_name, badge_icon) VALUES
(1, 'Cybersecurity Basics', 'Learn fundamental concepts of cybersecurity and online safety', 'Security Novice', '🛡️'),
(2, 'Password Security', 'Master password creation, management, and best practices', 'Password Guardian', '🔐'),
(3, 'Phishing & Social Engineering', 'Identify and defend against phishing attacks and manipulation', 'Phishing Detector', '🎣'),
(4, 'Network Security', 'Understand network threats, VPNs, and secure connections', 'Network Defender', '🌐'),
(5, 'Data Privacy & Protection', 'Learn about data encryption, privacy laws, and personal data security', 'Privacy Champion', '🔒'),
(6, 'Advanced Threats & Defense', 'Master advanced security concepts, malware, and incident response', 'Cyber Expert', '⚡');

-- Insert modules for Level 1: Cybersecurity Basics
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(1, 1, 'Introduction to Cybersecurity', 'Understanding what cybersecurity is and why it matters'),
(1, 2, 'Common Cyber Threats', 'Learn about viruses, malware, and other digital threats'),
(1, 3, 'Safe Browsing Habits', 'Best practices for browsing the internet safely'),
(1, 4, 'Email Security Basics', 'Protecting yourself from email-based threats'),
(1, 5, 'Mobile Device Security', 'Securing your smartphone and tablet'),
(1, 6, 'Social Media Safety', 'Protecting your privacy on social platforms'),
(1, 7, 'Software Updates', 'Why updates matter and how to manage them'),
(1, 8, 'Basic Security Tools', 'Essential security software and tools');

-- Insert modules for Level 2: Password Security
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(2, 1, 'Password Fundamentals', 'What makes a password strong or weak'),
(2, 2, 'Creating Strong Passwords', 'Techniques for generating secure passwords'),
(2, 3, 'Password Managers', 'Using tools to manage your passwords safely'),
(2, 4, 'Two-Factor Authentication', 'Adding an extra layer of security'),
(2, 5, 'Password Recovery', 'Safe methods for recovering lost passwords'),
(2, 6, 'Common Password Mistakes', 'Avoiding dangerous password practices'),
(2, 7, 'Password Sharing', 'When and how to share passwords safely'),
(2, 8, 'Enterprise Password Policies', 'Understanding workplace password requirements');

-- Insert modules for Level 3: Phishing & Social Engineering
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(3, 1, 'What is Phishing?', 'Understanding phishing attacks and their goals'),
(3, 2, 'Email Phishing', 'Identifying fake emails and suspicious messages'),
(3, 3, 'SMS & Voice Phishing', 'Recognizing phone and text message scams'),
(3, 4, 'Website Spoofing', 'Detecting fake websites and URLs'),
(3, 5, 'Social Engineering Tactics', 'How attackers manipulate people'),
(3, 6, 'Spear Phishing', 'Targeted attacks and how to defend against them'),
(3, 7, 'Reporting Phishing', 'What to do when you encounter phishing'),
(3, 8, 'Real-World Phishing Cases', 'Learning from actual phishing incidents');

-- Insert modules for Level 4: Network Security
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(4, 1, 'Network Basics', 'Understanding how networks work'),
(4, 2, 'Wi-Fi Security', 'Securing wireless networks and connections'),
(4, 3, 'Public Wi-Fi Risks', 'Dangers of public networks and how to stay safe'),
(4, 4, 'VPN Technology', 'Using Virtual Private Networks for security'),
(4, 5, 'Firewall Protection', 'How firewalls protect your devices'),
(4, 6, 'Router Security', 'Securing your home network router'),
(4, 7, 'Network Monitoring', 'Detecting suspicious network activity'),
(4, 8, 'Secure Remote Access', 'Working safely from anywhere');

-- Insert modules for Level 5: Data Privacy & Protection
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(5, 1, 'Understanding Data Privacy', 'What is personal data and why it matters'),
(5, 2, 'Encryption Basics', 'How encryption protects your data'),
(5, 3, 'Privacy Laws & Regulations', 'GDPR, CCPA, and your rights'),
(5, 4, 'Data Backup Strategies', 'Protecting your data from loss'),
(5, 5, 'Cloud Storage Security', 'Safely using cloud services'),
(5, 6, 'Digital Footprint', 'Managing your online presence'),
(5, 7, 'Data Breach Response', 'What to do if your data is compromised'),
(5, 8, 'Privacy Tools', 'Software and services for enhanced privacy');

-- Insert modules for Level 6: Advanced Threats & Defense
INSERT INTO quiz_modules (level_id, module_number, title, description) VALUES
(6, 1, 'Advanced Malware', 'Ransomware, trojans, and sophisticated threats'),
(6, 2, 'Zero-Day Exploits', 'Understanding unknown vulnerabilities'),
(6, 3, 'APT Attacks', 'Advanced Persistent Threats and nation-state actors'),
(6, 4, 'Incident Response', 'How to respond to security incidents'),
(6, 5, 'Digital Forensics', 'Investigating cyber attacks'),
(6, 6, 'Security Auditing', 'Assessing and improving security posture'),
(6, 7, 'Threat Intelligence', 'Staying informed about emerging threats'),
(6, 8, 'Career in Cybersecurity', 'Paths to becoming a security professional');

-- Create indexes for better performance
CREATE INDEX idx_quiz_modules_level ON quiz_modules(level_id);
CREATE INDEX idx_quiz_questions_module ON quiz_questions(module_id);
CREATE INDEX idx_user_progress_user ON user_quiz_progress(user_id);
CREATE INDEX idx_user_progress_module ON user_quiz_progress(module_id);
CREATE INDEX idx_user_badges_user ON user_badges(user_id);