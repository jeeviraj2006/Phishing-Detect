/*
# Add Security Tools Tables

1. New Tables
  - `security_checklist_items`
    - `id` (uuid, primary key)
    - `user_id` (uuid, not null)
    - `item_id` (text, not null) - checklist item identifier
    - `item_type` (text, not null) - 'daily', 'weekly', 'monthly'
    - `completed_at` (timestamptz, not null)
    - `created_at` (timestamptz, default: now())
    
  - `threat_simulator_results`
    - `id` (uuid, primary key)
    - `user_id` (uuid, not null)
    - `score` (integer, not null)
    - `total_questions` (integer, not null)
    - `completed_at` (timestamptz, default: now())
    
  - `security_incident_reports`
    - `id` (uuid, primary key)
    - `user_id` (uuid, not null)
    - `incident_type` (text, not null)
    - `description` (text, not null)
    - `status` (text, default: 'pending')
    - `created_at` (timestamptz, default: now())
    
  - `device_security_scans`
    - `id` (uuid, primary key)
    - `user_id` (uuid, not null)
    - `score` (integer, not null)
    - `total_checks` (integer, not null)
    - `passed_checks` (integer, not null)
    - `scan_data` (jsonb, not null)
    - `created_at` (timestamptz, default: now())

2. Security
  - All tables are public (no RLS) for anonymous user access
  - Users identified by UUID stored in localStorage
*/

-- Security Checklist Items
CREATE TABLE IF NOT EXISTS security_checklist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  item_id text NOT NULL,
  item_type text NOT NULL CHECK (item_type IN ('daily', 'weekly', 'monthly')),
  completed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_checklist_user_id ON security_checklist_items(user_id);
CREATE INDEX idx_checklist_item_type ON security_checklist_items(item_type);

-- Threat Simulator Results
CREATE TABLE IF NOT EXISTS threat_simulator_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  score integer NOT NULL,
  total_questions integer NOT NULL,
  completed_at timestamptz DEFAULT now()
);

CREATE INDEX idx_simulator_user_id ON threat_simulator_results(user_id);

-- Security Incident Reports
CREATE TABLE IF NOT EXISTS security_incident_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  incident_type text NOT NULL,
  description text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'resolved')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_incident_user_id ON security_incident_reports(user_id);
CREATE INDEX idx_incident_status ON security_incident_reports(status);

-- Device Security Scans
CREATE TABLE IF NOT EXISTS device_security_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  score integer NOT NULL,
  total_checks integer NOT NULL,
  passed_checks integer NOT NULL,
  scan_data jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_scan_user_id ON device_security_scans(user_id);
