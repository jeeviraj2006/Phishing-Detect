/*
# Create CyberGuard AI Assistant Database Schema

## 1. New Tables

### `users`
- `id` (uuid, primary key, default: gen_random_uuid())
- `created_at` (timestamptz, default: now())
- `last_active` (timestamptz, default: now())

### `chat_sessions`
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references users.id)
- `title` (text, default: 'New Chat')
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

### `chat_messages`
- `id` (uuid, primary key, default: gen_random_uuid())
- `session_id` (uuid, references chat_sessions.id, on delete cascade)
- `role` (text, 'user' or 'model')
- `content` (text)
- `created_at` (timestamptz, default: now())

### `phishing_detections`
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references users.id)
- `content` (text)
- `risk_level` (text, 'low', 'medium', 'high')
- `analysis` (text)
- `created_at` (timestamptz, default: now())

### `quiz_results`
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references users.id)
- `quiz_type` (text)
- `score` (integer)
- `total_questions` (integer)
- `created_at` (timestamptz, default: now())

## 2. Security
- No RLS enabled - public access for anonymous users
- All tables are accessible for read/write operations
- UUID-based user identification without authentication

## 3. Notes
- Users are identified by UUID stored in localStorage
- Chat history persists across sessions
- Phishing detection results are saved for reference
- Quiz results track learning progress
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  last_active timestamptz DEFAULT now()
);

-- Create chat_sessions table
CREATE TABLE IF NOT EXISTS chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  title text DEFAULT 'New Chat',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES chat_sessions(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'model')),
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create phishing_detections table
CREATE TABLE IF NOT EXISTS phishing_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  analysis text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create quiz_results table
CREATE TABLE IF NOT EXISTS quiz_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  quiz_type text NOT NULL,
  score integer NOT NULL,
  total_questions integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user_id ON chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_phishing_detections_user_id ON phishing_detections(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_results_user_id ON quiz_results(user_id);