import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const APP_ID = Deno.env.get('APP_ID') || 'app-8ascq50f7k01';
const SUBMIT_API_URL = 'https://api-integrations.appmedo.com/app-8ascq50f7k01/api-BYdwzE2qzDDL/image-generation/submit';
const QUERY_API_URL = 'https://api-integrations.appmedo.com/app-8ascq50f7k01/api-eLMlJRg7r4j9/image-generation/task';

Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  try {
    const { prompt } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Invalid request: prompt string required' }),
        { 
          status: 400,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    console.log('Generating image with prompt:', prompt);

    // Step 1: Submit image generation task
    console.log('Submitting image generation task...');
    
    let submitResponse;
    try {
      submitResponse = await fetch(SUBMIT_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID,
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: prompt
                }
              ]
            }
          ]
        })
      });
    } catch (fetchError) {
      console.error('Network error submitting task:', fetchError);
      return new Response(
        JSON.stringify({ 
          error: 'Network error: Unable to connect to image generation service. Please try again later.',
          details: fetchError instanceof Error ? fetchError.message : String(fetchError)
        }),
        { 
          status: 503,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    if (!submitResponse.ok) {
      const errorText = await submitResponse.text();
      console.error('Submit API error:', errorText);
      return new Response(
        JSON.stringify({ error: `Failed to submit task: ${submitResponse.status}`, details: errorText }),
        { 
          status: submitResponse.status,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    const submitData = await submitResponse.json();
    console.log('Task submitted:', submitData);

    if (submitData.status !== 0) {
      console.error('Submit API returned error:', submitData.message);
      return new Response(
        JSON.stringify({ error: submitData.message || 'Failed to submit task' }),
        { 
          status: 500,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    const taskId = submitData.data?.taskId;
    if (!taskId) {
      console.error('No taskId in response');
      return new Response(
        JSON.stringify({ error: 'No task ID received' }),
        { 
          status: 500,
          headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    console.log('Task ID:', taskId);

    // Step 2: Poll for task completion
    const maxAttempts = 60; // 60 attempts * 10 seconds = 10 minutes max
    const pollInterval = 10000; // 10 seconds
    let attempts = 0;

    while (attempts < maxAttempts) {
      attempts++;
      console.log(`Polling attempt ${attempts}/${maxAttempts}...`);

      // Wait before polling (except first attempt)
      if (attempts > 1) {
        await new Promise(resolve => setTimeout(resolve, pollInterval));
      } else {
        // First poll after 5 seconds
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

      const queryResponse = await fetch(QUERY_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID,
        },
        body: JSON.stringify({ taskId })
      });

      if (!queryResponse.ok) {
        console.error('Query API HTTP error:', queryResponse.status, queryResponse.statusText);
        // Don't fail immediately, continue polling
        continue;
      }

      let queryData;
      try {
        queryData = await queryResponse.json();
      } catch (parseError) {
        console.error('Failed to parse query response:', parseError);
        continue;
      }

      console.log('Query response status:', queryData.status, 'Task status:', queryData.data?.status);

      if (queryData.status !== 0) {
        console.error('Query API returned error:', queryData.message);
        continue; // Retry on error
      }

      const taskStatus = queryData.data?.status;
      console.log('Task status:', taskStatus);

      if (taskStatus === 'SUCCESS') {
        // Extract image from result
        const markdownText = queryData.data?.result?.candidates?.[0]?.content?.parts?.[0]?.text;
        
        if (!markdownText) {
          console.error('No markdown text in success response');
          return new Response(
            JSON.stringify({ error: 'No image data in response' }),
            { 
              status: 500,
              headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
              }
            }
          );
        }

        // Extract data URL from markdown: ![image](data:image/jpeg;base64,...)
        const dataUrlMatch = markdownText.match(/!\[image\]\((data:image\/[^;]+;base64,[^)]+)\)/);
        
        if (!dataUrlMatch || !dataUrlMatch[1]) {
          console.error('Could not extract data URL from markdown:', markdownText.substring(0, 100));
          return new Response(
            JSON.stringify({ error: 'Invalid image format in response' }),
            { 
              status: 500,
              headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
              }
            }
          );
        }

        const dataUrl = dataUrlMatch[1];
        console.log('Image generation successful!');

        return new Response(
          JSON.stringify({ 
            success: true,
            imageUrl: dataUrl
          }),
          {
            headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*',
            },
          }
        );
      } else if (taskStatus === 'FAILED') {
        const errorCode = queryData.data?.error?.code;
        const errorMessage = queryData.data?.error?.message;
        console.error('Task failed:', errorCode, errorMessage);
        return new Response(
          JSON.stringify({ error: `Image generation failed: ${errorMessage || errorCode}` }),
          { 
            status: 500,
            headers: { 
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*'
            }
          }
        );
      } else if (taskStatus === 'TIMEOUT') {
        console.error('Task timeout');
        return new Response(
          JSON.stringify({ error: 'Image generation timeout' }),
          { 
            status: 504,
            headers: { 
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*'
            }
          }
        );
      }
      // If PENDING, continue polling
    }

    // Max attempts reached
    console.error('Max polling attempts reached');
    return new Response(
      JSON.stringify({ error: 'Image generation timeout - please try again' }),
      { 
        status: 504,
        headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );

  } catch (error) {
    console.error('Edge function error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        message: error instanceof Error ? error.message : String(error)
      }),
      { 
        status: 500,
        headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );
  }
});
