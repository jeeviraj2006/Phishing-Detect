# WHERE TO ADD MAIL - Quick Visual Guide

## 🎯 Answer: You Add Emails by FORWARDING Them

### The Simple Answer:

**You DON'T manually type or paste emails into the app.**

**Instead, you FORWARD suspicious emails from your email inbox to a special monitoring address.**

---

## 📍 Step-by-Step Visual Guide

```
┌─────────────────────────────────────────────────────────────┐
│  STEP 1: Open CyberGuard AI Assistant                      │
│  ↓                                                           │
│  Click "Email Monitor" in the navigation menu               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 2: You'll See This Screen                            │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  📧 Your Monitoring Address                           │ │
│  │  ┌─────────────────────────────────────┬──────────┐  │ │
│  │  │ security@cyberguard.monitor         │ [Copy]   │  │ │
│  │  └─────────────────────────────────────┴──────────┘  │ │
│  │  How to use: When you receive a suspicious email,    │ │
│  │  click "Forward" in your email client, paste this    │ │
│  │  address in the "To" field, and send!                │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 3: Click the [Copy] Button                           │
│  (This copies: security@cyberguard.monitor)                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 4: Go to Your Email Inbox (Gmail, Outlook, etc.)     │
│  ↓                                                           │
│  Open a suspicious email                                    │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 5: Click "Forward" Button in Your Email              │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  From: suspicious@phishing.com                        │ │
│  │  Subject: Urgent! Verify your account                 │ │
│  │  ┌─────────────────────────────────────────────────┐ │ │
│  │  │ [Reply] [Reply All] [Forward] [Delete]          │ │ │
│  │  │                      ↑ CLICK THIS                │ │ │
│  │  └─────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 6: Paste the Monitoring Address                      │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  To: security@cyberguard.monitor  ← PASTE HERE       │ │
│  │  Subject: Fwd: Urgent! Verify your account           │ │
│  │  ┌─────────────────────────────────────────────────┐ │ │
│  │  │ [Original email content will be here]           │ │ │
│  │  └─────────────────────────────────────────────────┘ │ │
│  │  [Send]  ← CLICK SEND                                │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 7: Go Back to CyberGuard Email Monitor               │
│  ↓                                                           │
│  Click "Monitored Emails" tab                               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 8: See Your Analysis Results!                        │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  🔴 HIGH RISK                              [New]      │ │
│  │  Urgent! Verify your account                          │ │
│  │  From: suspicious@phishing.com                        │ │
│  │  ─────────────────────────────────────────────────    │ │
│  │  Analysis: This is a phishing attempt. The sender    │ │
│  │  domain is suspicious, the email uses urgent         │ │
│  │  language to pressure you, and contains a fake       │ │
│  │  login link. DO NOT click any links. Delete this     │ │
│  │  email immediately.                                   │ │
│  │  ─────────────────────────────────────────────────    │ │
│  │  [Mark Read] [🗑️ Delete]                              │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔑 Key Points

### Where is the Monitoring Address?

**Location**: Email Monitor → Setup Tab → Scroll down to "📧 Your Monitoring Address"

**The Address**: `security@cyberguard.monitor`

**What to Do**: Click the [Copy] button next to it

---

### Where Do You Add/Forward Emails?

**NOT in CyberGuard** - You forward emails FROM your regular email inbox (Gmail, Outlook, Yahoo, etc.)

**TO the monitoring address** - `security@cyberguard.monitor`

---

### Where Do You See Results?

**Location**: Email Monitor → Monitored Emails Tab

**What You'll See**:
- List of all forwarded emails
- Risk level badges (🔴 High, 🟠 Medium, 🟢 Low)
- AI analysis of each email
- Recommendations

---

## 📱 Real Example

### Scenario: You receive a suspicious email

**Your Gmail Inbox**:
```
From: support@paypa1.com (notice the "1" instead of "l")
Subject: Your account will be suspended!
Body: Click here to verify your account immediately...
```

**What You Do**:

1. ✅ **In Gmail**: Click the "Forward" button (→ icon)
2. ✅ **In the "To" field**: Paste `security@cyberguard.monitor`
3. ✅ **Click**: Send
4. ✅ **In CyberGuard**: Go to Email Monitor → Monitored Emails tab
5. ✅ **See**: 🔴 HIGH RISK - Phishing attempt detected!

---

## ❌ Common Mistakes

### ❌ WRONG: Trying to paste email text into CyberGuard
**Why it's wrong**: There's no text box to paste emails in the Email Monitor

### ❌ WRONG: Taking a screenshot and uploading it
**Why it's wrong**: You should forward the actual email, not a screenshot

### ❌ WRONG: Copying email text and pasting somewhere
**Why it's wrong**: Just forward the email directly from your email client

### ✅ CORRECT: Forward the email to security@cyberguard.monitor
**Why it's correct**: This is the designed workflow - simple and automatic!

---

## 🎓 Summary

### Question: "Where can I add mail?"

### Answer:
1. **Get the address**: Email Monitor → Setup Tab → Copy `security@cyberguard.monitor`
2. **Forward emails**: In your email inbox (Gmail/Outlook/etc.), click Forward
3. **Paste address**: Put `security@cyberguard.monitor` in the "To" field
4. **Send**: Click Send
5. **Check results**: Email Monitor → Monitored Emails tab

**You add emails by FORWARDING them from your email inbox to the monitoring address!**

---

## 🆘 Still Confused?

### Watch for These UI Elements:

**In CyberGuard Email Monitor**:
- Look for a gray box with a monospace font address
- Look for a [Copy] button next to the address
- Look for text that says "📧 Your Monitoring Address"

**In Your Email Client**:
- Look for "Forward" button (usually has a → arrow icon)
- Look for "To:" field where you enter recipient email

**That's where you add the monitoring address!**

---

*Remember: You're not adding emails TO CyberGuard. You're forwarding emails FROM your inbox TO the monitoring address, and CyberGuard will analyze them automatically!*
