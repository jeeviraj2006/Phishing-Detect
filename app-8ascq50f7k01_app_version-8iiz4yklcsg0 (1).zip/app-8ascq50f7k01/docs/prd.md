# CyberGuard AI Assistant Requirements Document

## 1. Application Overview

### 1.1 Application Name
CyberGuard AI Assistant

### 1.2 Application Description
A streamlined AI-powered chatbot assistant designed for college students to enhance their cybersecurity awareness through conversational interaction and image-based threat analysis. The platform focuses on simplicity and ease of use, similar to ChatGPT's interface.

### 1.3 Target Users
College students seeking quick cybersecurity guidance and phishing detection through an intuitive chat interface.

### 1.4 Founder Information
- **Founder Name**: Jeeviraj V
- **Institution**: Sri Shakthi Institute of Engineering and Technology, Coimbatore
\n## 2. Backend Technology Stack

### 2.1 Supabase Integration
- **Database**: PostgreSQL database for storing user profiles, chat history, learning resources, quiz progress, phishing detection history, and email monitoring logs
- **Authentication**: Supabase Auth for user registration and login with email/password
- **Storage**: Supabase Storage for uploaded images and learning materials
- **API**: RESTful APIs for frontend-backend communication
- **Row Level Security**: Data privacy and access control\n- **Edge Functions**: Serverless functions for LLM integration, image analysis, phishing detection processing, and automated email monitoring

### 2.2 AI Image Generation Integration
- **Image Generation Tool**: Stable Diffusion Web UI API (open-source)
- **Alternative Option**: Hugging Face Inference API with Stable Diffusion models
- **Implementation**: RESTful API integration for generating cybersecurity-themed illustrations, badge designs, and educational visual content
- **Use Cases**: \n  - Generating custom badge artwork for the multi-level quiz system
  - Creating visual examples for phishing scenarios in training modules
  - Producing educational infographics for learning resources
  - Generating threat visualization diagrams\n- **API Endpoint**: Self-hosted Stable Diffusion API or Hugging Face Inference API endpoint
- **Image Storage**: Generated images stored in Supabase Storage with metadata tracking

## 3. Core Functionalities

### 3.1 User Authentication
\n#### Login Process:\n1. **Access Login Page**: Users navigate to the application homepage and click the 'Sign In' button
2. **Enter Credentials**: Users input their registered email address and password in the login form
3. **Submit**: Click the 'Log In' button to authenticate
4. **Verification**: Supabase Auth validates the credentials against the database
5. **Success**: Upon successful authentication, users are redirected to the main chat interface with their session activated
6. **Error Handling**: Invalid credentials display an error message prompting users to retry or reset password

#### Additional Authentication Features:
- **New User Registration**: Click 'Sign Up' to create a new account with email and password
- **Password Requirements**: Minimum 8 characters with at least one uppercase letter, one number, and one special character
- **Remember Me**: Optional checkbox to maintain login session across browser sessions
- **Password Reset**: 'Forgot Password' link sends a reset email to the registered address
- **Session Management**: Automatic session refresh to keep users logged in during active use
- **Secure Logout**: 'Log Out' option in user menu to safely terminate the session

#### Email Connection Button:\n- **Dedicated Email Connection Button**: A prominent 'Connect Email' button displayed in the fixed header navigation bar at the top of the page
- **Exact Button Location**: Positioned in the top-right corner of the header, specifically between the 'Email Monitor' icon and the user profile avatar icon. The button appears as the second-to-last element in the header before the user profile menu.\n- **Visual Hierarchy**: The button is placed at the same horizontal level as other header icons, maintaining consistent spacing (approximately 16px gap between adjacent elements)
- **Button Design**: \n  - Envelope icon (📧) displayed on the left side of the button text
  - Button text: 'Connect Email' in white color
  - Background color: Bright cyan (#06B6D4) to stand out from other header elements
  - Border radius: 8px for rounded corners
  - Padding: 10px horizontal, 8px vertical
  - Font size: 16px, medium weight
  - Height: 40px to match header icon sizes
- **Button Visibility**: \n  - Visible to all logged-in users who have not yet connected an email account
  - Hidden for users who have not logged in (login required first)
  - Automatically appears in the header immediately after successful login if no email is connected
- **Button State Changes**: 
  - **Disconnected State**: Shows envelope icon + 'Connect Email' text with cyan background
  - **Connected State**: Changes to envelope icon with checkmark (✓) + 'Email Connected' text with green background (#10B981)
  - **Hover State**: Background color darkens slightly (cyan becomes #0891B2) with smooth 200ms transition
  - **Loading State**: Shows spinner icon during OAuth authentication process
- **Click Action**: Opens a centered modal overlay (500px width) with email connection options
- **Modal Content**: 
  - Title: 'Connect Your Email for Automated Threat Monitoring'
  - Description: 'Link your email account to enable real-time phishing detection and automated security scanning of incoming emails.'
  - Email provider selection buttons: Gmail, Outlook, Yahoo Mail, Other (IMAP/POP3)
  - 'Connect' button (cyan background) to initiate OAuth flow
  - 'Cancel' button (gray background) to close modal
- **Post-Connection Behavior**: 
  - After successful connection, button automatically updates to 'Email Connected' state with green background
  - Toast notification appears: 'Email account successfully connected! Monitoring is now active.'
  - Button becomes clickable dropdown trigger showing connected account details
- **Multiple Accounts Support**: 
  - After first connection, clicking the button reveals a dropdown menu\n  - Dropdown shows list of all connected email accounts with provider icons
  - Options in dropdown: 'View Monitoring Dashboard', 'Add Another Email', 'Manage Connected Emails', 'Disconnect'\n- **Mobile Responsive Behavior**: 
  - On screens below 768px width, button text changes to just the envelope icon to save space
  - Full text reappears on hover/tap with tooltip: 'Connect Email'
  - Modal adjusts to 90% screen width on mobile devices
- **Accessibility Features**:
  - ARIA label: 'Connect email account for monitoring'
  - Keyboard accessible: Tab to focus, Enter/Space to activate\n  - Screen reader announces button state changes
\n### 3.2 Interactive Chat Interface
- Clean, minimalist chat interface similar to ChatGPT
- Natural language conversation with the AI assistant
- Real-time message streaming for AI responses
- Ask questions about cybersecurity topics and receive instant answers
- Context-aware responses based on conversation history
- Chat history saved automatically for logged-in users
- Simple text input field without plus symbol or additional buttons in the search area
- New chat functionality accessible from the header or sidebar menu, not within the input field
\n### 3.3 Image Upload and Analysis
- Drag-and-drop image upload functionality
- Support for common image formats (PNG, JPG, JPEG, WebP)
- Click-to-upload option with file browser
- Image preview before sending
- AI-powered analysis of uploaded images for:\n  - Suspicious emails or messages (screenshots)\n  - Phishing attempts\n  - Malicious links or QR codes
  - Security threats in visual content
- Instant feedback on potential threats detected in images
\n### 3.4 Conversation Management
- New chat button located in the header or sidebar menu
- Automatic conversation saving\n- Access to previous chat sessions
- Clear conversation history option
\n### 3.5 Enhanced Sidebar Navigation
\n#### 3.5.1 Sidebar Display
- **Default State**: Sidebar is open by default on desktop view (width: 280px)
- **Toggle Button**: Hamburger menu icon in the top-left header to collapse/expand sidebar
- **Mobile Behavior**: Sidebar collapses automatically on mobile devices and opens as an overlay when toggled
- **Smooth Animation**: Slide-in/slide-out animation (300ms ease-in-out) when toggling\n\n#### 3.5.2 Sidebar Features
- **New Chat Button**: Prominent button at the top of sidebar with plus icon to start a new conversation
- **Chat History Section**:
  - Displays list of previous conversations with timestamps
  - Shows conversation preview (first message or title)
  - Click to load previous chat session
  - Hover effect with edit and delete icons
  - Search bar to filter chat history by keywords
  - Organized by date categories (Today, Yesterday, Last 7 Days, Last 30 Days, Older)
- **Quick Access Menu**:
  - Dashboard: Overview of learning progress and quiz statistics
  - Detect: Quick access to phishing detection tool
  - Learn: Navigate to learning resources library
  - Quiz: Access multi-level quiz system
  - Email Monitor: View automated email threat alerts and monitoring dashboard
  - Bookmarks: Saved conversations and important resources
  - Security Tips: Daily cybersecurity tips and best practices
- **User Profile Section**:
  - User avatar and name display at the bottom of sidebar
  - Quick access to profile settings\n  - Badge count indicator showing total earned badges
  - Current level display in quiz system
- **Theme Toggle**: Light/dark mode switch button in sidebar footer
- **Sidebar Footer**:
  - Help icon linking to help center
  - Settings icon for application settings
  - Feedback button for user feedback submission
\n### 3.6 Enhanced Phishing Detection
\n#### 3.6.1 Real-Time Threat Analysis
- Real-time analysis of text and images for phishing threats
- Risk level indicators with color-coded badges (Safe - Green, Suspicious - Orange, Dangerous - Red)
- Detailed explanations of detected threats with highlighted suspicious elements
- Actionable recommendations for staying safe
\n#### 3.6.2 URL and Link Scanner
- **Paste URL Analysis**: Users can paste suspicious URLs directly into the chat for instant scanning
- **Link Safety Score**: Numerical safety score (0-100) displayed for each analyzed URL
- **Domain Reputation Check**: Verification of domain age, SSL certificate validity, and known blacklist status
- **Redirect Chain Detection**: Identifies hidden redirects and shortened URL destinations
- **Malicious Pattern Recognition**: Detects common phishing URL patterns (typosquatting, homograph attacks, suspicious TLDs)
- **Historical Threat Database**: Cross-references URLs against known phishing databases

#### 3.6.3 Email Header Analysis
- **Email Header Parser**: Users can paste email headers for detailed analysis
- **Sender Verification**: Checks SPF, DKIM, and DMARC authentication records
- **IP Geolocation**: Displays sender's IP address location and ISP information
- **Spoofing Detection**: Identifies email address spoofing and display name manipulation
- **Attachment Risk Assessment**: Analyzes attachment file types and potential malware indicators
\n#### 3.6.4 QR Code Scanner
- **QR Code Upload**: Users can upload images containing QR codes for analysis
- **Embedded URL Extraction**: Automatically extracts and analyzes URLs hidden in QR codes
- **QR Code Safety Rating**: Provides safety assessment before users scan with their devices
- **Malicious QR Detection**: Identifies QR codes leading to phishing sites or malware downloads
\n#### 3.6.5 Phishing Simulation Training
- **Practice Scenarios**: Library of realistic phishing email examples for training purposes
- **Interactive Identification**: Users click on suspicious elements in sample emails to test their detection skills
- **Instant Feedback**: Immediate explanation of correct and incorrect identifications
- **Difficulty Levels**: Beginner, Intermediate, and Advanced phishing scenarios
- **Score Tracking**: Performance metrics showing improvement over time

#### 3.6.6 Threat Intelligence Dashboard
- **Recent Threats**: Display of latest phishing campaigns and trending attack methods
- **Personal Threat History**: Log of all scans performed by the user with timestamps and results
- **Export Reports**: Download detailed PDF reports of phishing analysis results
- **Threat Alerts**: Push notifications for newly discovered phishing campaigns targeting college students
- **Statistics Visualization**: Charts showing threat types detected, risk levels, and scan frequency

#### 3.6.7 Browser Extension Integration (Optional)
- **Real-Time Web Protection**: Browser extension that scans links before users click them
- **Automatic Page Analysis**: Warns users when visiting suspicious websites
- **One-Click Reporting**: Report suspected phishing sites directly from the browser
- **Sync with Main App**: Detection history synced across browser extension and web application

### 3.7 Automated Email Monitoring and Detection

#### 3.7.1 Email Account Integration
- **Email Connection Setup**: Users can connect their registered email account through the dedicated 'Connect Email' button in the header or during/after registration
- **Supported Email Providers**: Gmail, Outlook, Yahoo Mail, and other IMAP/POP3 compatible email services
- **OAuth Authentication**: Secure OAuth 2.0 authentication for email access without storing passwords
- **Permission Scope**: Read-only access to incoming emails for security analysis
- **Multiple Account Support**: Users can connect multiple email accounts for monitoring
- **Connection Modal**: Dedicated modal triggered by the 'Connect Email' button with provider selection and OAuth flow
- **Connection Status Display**: Header button updates to show connected status with checkmark icon
\n#### 3.7.2 Real-Time Email Scanning
- **Automatic Detection**: System automatically scans all incoming emails in real-time upon arrival
- **Background Processing**: Email analysis runs in the background without user intervention
- **AI-Powered Analysis**: Uses machine learning models to detect phishing indicators, suspicious links, malicious attachments, and social engineering tactics
- **Threat Classification**: Emails categorized as Safe, Suspicious, or Dangerous based on analysis results
- **Scan Frequency**: Continuous monitoring with email checks every 2-5 minutes
\n#### 3.7.3 Instant Notification System
- **Push Notifications**: Real-time browser push notifications when a phishing email is detected
- **Email Alerts**: Optional email notifications sent to user's registered email with threat summary
- **In-App Alerts**: Red badge notification on the Email Monitor icon in the sidebar showing unread threat alerts
- **Notification Content**: Includes sender information, threat level, detected suspicious elements, and recommended actions
- **Alert Priority Levels**: High-priority alerts for dangerous emails, medium for suspicious, informational for safe emails with minor warnings

#### 3.7.4 Email Monitoring Dashboard
- **Threat Overview**: Summary of total emails scanned, threats detected, and current monitoring status
- **Recent Scans**: List of recently analyzed emails with timestamps, sender details, subject lines, and threat levels
- **Threat Details**: Click on any email entry to view detailed analysis report including:
  - Sender verification results
  - Link safety analysis
  - Attachment risk assessment
  - Phishing indicators found
  - Recommended actions (delete, report, ignore)
- **Filter Options**: Filter emails by threat level (All, Safe, Suspicious, Dangerous) and date range
- **Search Functionality**: Search monitored emails by sender, subject, or keywords
- **Export History**: Download monitoring history as CSV or PDF report

#### 3.7.5 Alert Management
- **Alert History**: View all past email threat alerts with timestamps and resolution status
- **Mark as Resolved**: Users can mark alerts as resolved after taking action
- **False Positive Reporting**: Option to report false positives to improve detection accuracy
- **Alert Preferences**: Customize notification settings (enable/disable push notifications, email alerts, sound alerts)
- **Whitelist Management**: Add trusted senders to whitelist to prevent false alerts
- **Blacklist Management**: Manually add suspicious senders to blacklist for automatic flagging

#### 3.7.6 Email Security Insights
- **Weekly Security Reports**: Automated weekly summary of email threats detected and blocked
- **Trend Analysis**: Visualize phishing attempt trends over time with charts and graphs
- **Common Threat Patterns**: Identify recurring phishing tactics targeting the user\n- **Security Score**: Overall email security score based on threat exposure and user actions
- **Recommendations**: Personalized security recommendations based on detected threats\n
#### 3.7.7 Privacy and Data Security
- **End-to-End Encryption**: All email data encrypted during transmission and storage
- **No Email Storage**: System analyzes emails in real-time without permanently storing email content
- **Metadata Only**: Only email metadata (sender, subject, timestamps) stored for monitoring history
- **User Control**: Users can disconnect email accounts or pause monitoring at any time through the header button dropdown menu
- **GDPR Compliance**: Full compliance with data protection regulations\n- **Audit Logs**: Transparent logging of all email access and analysis activities

### 3.8 Learning Module\n- **Learning Resources Library**: Curated collection of cybersecurity educational materials including articles, guides, and tutorials
- **Resource Categories**: Organized by topics such as Password Security, Phishing Awareness, Safe Browsing, Data Protection, and Social Engineering
- **Clickable Resources**: Each resource opens in a new tab or embedded viewer for seamless access
- **Resource Format Support**: PDF documents, web links, video tutorials, and interactive content
- **Learning Symbol**: A book icon or graduation cap symbol displayed in the navigation menu to access the learning section
- **Progress Tracking**: Users can mark resources as completed and track their learning progress\n- **Search Functionality**: Search bar to quickly find specific learning topics
- **Bug Fix**: Resolved issue where learning resources failed to open - implemented proper URL validation and error handling for resource links

### 3.9 Multi-Level Gamified Quiz System

#### 3.9.1 Multi-Level Structure
- **Total Levels**: 8 progressive levels with increasing difficulty, forming a comprehensive multi-level learning path
- **Practice Modules per Level**: 7 practice modules in each level (college portal style structure)
- **Questions per Module**: Minimum 10 quiz questions in each practice module
- **Sequential Progression**: Users must complete all 7 practice modules in a level before unlocking the next level
- **Hierarchical Difficulty**: Each level builds upon previous knowledge with progressively complex scenarios
- **Level Topics**:
  - Level 1: Basic Security Fundamentals
  - Level 2: Password Protection Strategies
  - Level 3: Phishing Awareness and Detection
  - Level 4: Network Security Essentials
  - Level 5: Data Privacy and Encryption
  - Level 6: Advanced Threat Analysis
  - Level 7: Social Engineering Defense
  - Level 8: Comprehensive Cyber Defense

#### 3.9.2 College Portal Layout Design
- **Expandable Level Sections**: Each level displayed as a collapsible card with chevron icon (similar to WhatsApp Image 2025-12-21 at 23.10.41_f9fb57ad.jpg)
- **Level Header**: Shows level number and title (e.g., 'Level 1 - Practice Module 1', 'Level 1 - Practice Module 2')\n- **Collapse/Expand Toggle**: Click on level header to expand or collapse the practice module list
- **Collapse All Button**: Top-right button to collapse all expanded levels at once
- **Practice Module List**: When expanded, shows vertical list of all 7 practice modules under that level
- **Module Icons**: Each practice module has a document/quiz icon on the left side
- **Module Naming**: Practice modules named as 'L1 - Practice - PS - 1', 'L1 - Practice - PS - 2', etc.
- **Completion Indicators**: Checkmark or completion icon displayed next to completed modules
- **Lock Icons**: Locked modules shown with lock icon until prerequisites are met
- **Active Module Highlight**: Currently active or in-progress module highlighted with distinct background color
- **Level Progress Indicator**: Visual indicator showing how many modules completed out of 7 in each level

#### 3.9.3 Practice Module Structure
- **Quiz Format**: Multiple-choice questions, true/false, and scenario-based questions
- **Questions per Module**: Minimum 10 questions per practice module
- **Passing Criteria**: Minimum 70% score to complete a practice module
- **Retry Option**: Users can retake failed modules unlimited times
- **Module Feedback**: Instant feedback on answers with explanations
- **Module Progression**: Users must complete practice modules sequentially within each level (Module 1 → Module 2 → ... → Module 7)
- **Progress Bar**: Visual progress indicator showing question number (e.g., 'Question 1 of 10')
- **Difficulty Scaling**: Questions become more challenging as users progress through levels
\n#### 3.9.4 Badge System
- **Level Completion Badges**: Earn a unique badge upon completing all 7 practice modules in a level
- **Badge Design**: Each level has a distinct badge design reflecting the cybersecurity theme and difficulty tier, generated using Stable Diffusion API for custom artwork
- **Badge Collection Location**: Users can view and collect their earned badges in the following locations:
  - **User Profile Page**: Dedicated 'Badges' or 'Achievements' section displaying all earned badges
  - **Quiz Dashboard**: Badge showcase area at the top of the quiz section showing recently earned badges
  - **Profile Menu**: Click on user avatar/name in the header to access profile dropdown with 'My Badges' option
  - **Post-Completion Screen**: Badges are automatically awarded and displayed immediately after completing all 7 modules in a level with celebratory animation
  - **Sidebar Profile Section**: Badge count indicator showing total earned badges
- **Badge Display**: Badges displayed in user profile and achievements section with horizontal scrollable gallery
- **Badge Names**:
  - Level 1 - 'Security Novice'
  - Level 2 - 'Password Guardian'
  - Level 3 - 'Phishing Detector'
  - Level 4 - 'Network Defender'
  - Level 5 - 'Privacy Protector'
  - Level 6 - 'Threat Analyst'
  - Level 7 - 'Social Engineer Defender'
  - Level 8 - 'Cyber Expert'
- **Master Badge**: Special 'CyberGuard Master' badge awarded upon completing all 8 levels
- **Badge Rarity Tiers**: Bronze (Levels 1-2), Silver (Levels 3-5), Gold (Levels 6-7), Platinum (Level 8)
- **Badge Notification**: Toast notification appears when a new badge is earned with option to 'View Badge' or 'Continue'\n\n#### 3.9.5 Progress Tracking
- **Visual Progress Bar**: Shows completion percentage for current level (based on 7 practice modules)
- **Module Status Indicators**: Completed, in-progress, and locked modules clearly marked
- **Level Overview**: Dashboard showing all 8 levels with completion status in hierarchical view
- **Statistics**: Track total modules completed, average scores, time spent, and current level
- **Leaderboard**: Optional leaderboard showing top performers among users with level rankings
- **Achievement Milestones**: Special recognition for completing multiple levels (e.g., 25%, 50%, 75%, 100% completion)
\n#### 3.9.6 Quiz Access\n- **Quiz Icon**: Trophy or star icon in navigation menu to access the multi-level quiz system
- **Course View Layout**: Main quiz page displays all 8 levels in vertical list format (college portal style)
- **Tab Navigation**: Optional tabs for 'Course', 'Participants', 'Grades', 'Competencies' at the top of quiz section
- **Module Selection**: Click on any unlocked practice module to start the quiz
- **Level Navigation**: Easy navigation between levels with breadcrumb trail showing current position
\n### 3.10 Feedback System
- **Feedback Form**: Accessible via a 'Feedback' button in the user menu or footer
- **Feedback Categories**: Bug Report, Feature Request, General Feedback, User Experience\n- **Input Fields**: Title, category selection, detailed description text area, optional screenshot upload
- **Submission Confirmation**: Toast notification confirming successful feedback submission
- **Feedback Storage**: All feedback stored in Supabase database with user ID, timestamp, and status tracking
\n### 3.11 Help and Support
- **Help Center**: Dedicated section with FAQs, troubleshooting guides, and how-to articles
- **Support Topics**: Account Management, Using the Chat Interface, Image Analysis, Learning Resources, Multi-Level Quiz System, Email Monitoring, Technical Issues
- **Contact Support**: Email contact form for direct support inquiries
- **Live Chat Support**: Optional real-time chat support during business hours
- **Help Icon**: Question mark icon in the header for quick access to help resources

### 3.12 Settings Menu
\n#### 3.12.1 Settings Access
- **Settings Icon Location**: Gear/cog icon located in the user profile menu in the top-right corner of the header
- **Access Path**: Click on user avatar/name → Select 'Settings' from dropdown menu → Settings page opens
- **Alternative Access**: Settings icon also available in the sidebar footer for quick access
- **Settings Tab**: The settings page opens as a dedicated full-page view with a tabbed interface for easy navigation between different settings categories
\n#### 3.12.2 Settings Options
- **Profile Settings Tab**: Update user name, email, and password
- **Email Monitoring Settings Tab**: Connect/disconnect email accounts, configure scan frequency, manage whitelist/blacklist
- **Notification Preferences Tab**: Toggle email notifications, push notifications, and in-app alerts for threats and quiz achievements
- **Privacy Settings Tab**: Manage data sharing, chat history retention, and email monitoring permissions
- **Theme Selection Tab**: Choose between light and dark mode\n- **Language Preferences Tab**: Select preferred language for the interface
- **About Section Tab**: Accessible as the last tab in the Settings menu, displays:\n  - **Founder Name**: Jeeviraj V\n  - **Institution**: Sri Shakthi Institute of Engineering and Technology, Coimbatore
  - Application version number\n  - Copyright information
  - Terms of Service and Privacy Policy links

#### 3.12.3 Settings Tab Navigation
- **Tab Layout**: Horizontal tab navigation at the top of the settings page with the following tabs:
  1. Profile\n  2. Email Monitoring\n  3. Notifications
  4. Privacy
  5. Theme
  6. Language
  7. About
- **Active Tab Indicator**: Currently selected tab highlighted with accent color underline
- **Tab Icons**: Each tab has a corresponding icon for visual identification
- **Mobile Responsive**: Tabs collapse into a dropdown menu on mobile devices

## 4. Design Style\n
### 4.1 Color Scheme
- Primary color: Deep blue (#1E3A8A) for trust and security
- Secondary color: Light gray (#F3F4F6) for backgrounds\n- Accent color: Bright cyan (#06B6D4) for interactive elements and the 'Connect Email' button
- Warning color: Warm orange (#F59E0B) for alerts\n- Danger color: Red (#EF4444) for high-risk phishing threats
- Success color: Green (#10B981) for completed modules, badges, safe scan results, and connected email status
- Text color: Dark gray (#1F2937) for readability\n- Level tier colors: Bronze (#CD7F32), Silver (#C0C0C0), Gold (#FFD700), Platinum (#E5E4E2) for badge rarity indicators
- Sidebar background: White (#FFFFFF) in light mode, Dark gray (#1F2937) in dark mode
- Sidebar hover: Light cyan (#E0F2FE) for menu item hover effects
- Email alert badge: Red (#EF4444) for unread threat notifications

### 4.2 Visual Elements
- Minimalist, clean interface inspired by ChatGPT
- Rounded corners (12px radius) for modern feel
- Subtle shadows for depth without distraction
- Message bubbles: user messages in cyan, AI responses in light gray
- Smooth fade-in animations for new messages (200ms)\n- Loading indicator with pulsing dots during AI response generation
- Learning module icon: Book or graduation cap symbol in navigation
- Quiz icon: Trophy or star symbol in navigation
- Phishing detection icon: Shield with magnifying glass in navigation and quick access menu
- Email Monitor icon: Envelope with shield symbol in sidebar quick access menu
- **Connect Email Button**: Envelope icon with 'Connect Email' text, styled with accent color (#06B6D4), positioned in header top-right area between Email Monitor icon and user profile icon
- **Connected Email Button**: Envelope icon with checkmark and 'Email Connected' text, styled with success color (#10B981)\n- Badge animations: Celebratory animation with confetti effect when earning a new badge
- Progress bars with gradient fill showing completion percentage
- Locked level overlay with semi-transparent effect and lock icon
- Feedback icon: Speech bubble or comment icon\n- Help icon: Question mark in circle\n- Settings icon: Gear/cog symbol in user menu and sidebar footer
- Expandable sections with smooth accordion animation (300ms)
- Chevron icons rotate 90 degrees when expanding/collapsing levels
- Module icons: Document or quiz paper icon in pink/magenta color
- Level completion celebration: Animated badge reveal with particle effects
- Badge collection icon: Medal or trophy icon in user profile menu
- Sidebar toggle icon: Hamburger menu (three horizontal lines) in header
- Sidebar shadow: Subtle right-side shadow (0 2px 8px rgba(0,0,0,0.1)) for depth
- Chat history items: Rounded rectangles with hover background color change
- Active chat highlight: Cyan background (#E0F2FE) for currently selected conversation
- Risk level badges: Color-coded circular badges with icons (Safe - green checkmark, Suspicious - orange warning triangle, Dangerous - red alert icon)
- Threat visualization: Highlighted suspicious elements in analyzed content with red underlines or borders
- Scan result cards: Elevated cards with shadow effect displaying analysis results
- URL safety meter: Horizontal progress bar with color gradient from red to green
- Email threat alert cards: Elevated cards with color-coded left border indicating threat level
- Notification badge: Small red circle with number showing unread email alerts on Email Monitor icon
- Real-time scanning indicator: Animated pulse effect on Email Monitor icon when scanning is active
- **Email Connection Modal**: Centered modal with white background, rounded corners, and subtle shadow, containing provider selection buttons and OAuth flow
- **Settings Tab Indicators**: Active tab highlighted with cyan underline and bold text
\n### 4.3 Typography
- Primary font: Inter for all text elements
- Font sizes: 16px for messages, 14px for UI elements, 20px for headings, 24px for level titles, 18px for module names, 15px for sidebar menu items, 13px for email metadata, 16px for 'Connect Email' button text, 14px for settings tab labels
- Line height: 1.5 for comfortable reading
- Bold weight for level headers, completed module indicators, threat warnings, email sender names, 'Connect Email' button text, and active settings tab labels
- Sidebar section headers: 12px uppercase with letter-spacing for category labels
- Monospace font: Courier New for displaying URLs, email headers, and technical data
\n### 4.4 Layout
- Single-column centered layout (max-width: 800px) for chat interface
- Fixed header with app logo, hamburger menu toggle, new chat button, learning icon, quiz icon, detect icon, email monitor icon, **Connect Email button**, feedback icon, help icon, and user menu
- **Connect Email Button Position**: Located in the top-right area of the header, specifically positioned between the Email Monitor icon and the user profile avatar icon. The button is the second-to-last element in the header navigation bar before the user profile menu.
- Sidebar width: 280px when open, 0px when collapsed
- Sidebar position: Fixed left side, full height from header to bottom
- Scrollable chat area taking up main viewport
- Fixed bottom input area with clean text field and separate image upload button (no plus symbol in the input field)
- Input field design: Simple text box with placeholder text 'Ask about cybersecurity...' and send button on the right\n- Image upload button positioned adjacent to the input field, not inside it
- Responsive design for desktop (1920px), tablet (768px), and mobile (375px)\n- Sidebar for chat history (open by default on desktop, collapsible on mobile with overlay)
- Learning module: Grid layout for resource cards with thumbnails and titles
- Multi-level quiz system: Vertical list layout with expandable level sections (college portal style)
- Each level section contains collapsible card with header and practice module list
- Practice modules displayed as vertical list items with icons and completion status
- Badge showcase: Horizontal scrollable gallery in user profile with tier grouping
- Badge collection page: Grid layout displaying all earned badges with filtering options by tier (Bronze, Silver, Gold, Platinum)
- User profile dropdown: Includes 'My Badges' menu item with badge count indicator
- Feedback form: Modal overlay with form fields\n- Help center: Accordion-style FAQ sections with expandable answers
- Settings page: Full-page view with horizontal tab navigation at the top, each tab displaying its respective settings options in a vertical list format. The About section is accessible as the last tab, displaying founder and institution information.
- Sidebar sections: Vertically stacked with clear visual separation between categories
- Phishing detection dashboard: Two-column layout with scan input on left and results/history on right
- Threat intelligence cards: Grid layout with 3 columns on desktop, 1 column on mobile
- URL scanner: Centered input field with prominent scan button
- Email header analyzer: Full-width text area with collapsible result sections
- Email Monitoring Dashboard: Two-column layout with threat overview and statistics on left, recent scans list on right
- Email alert cards: Vertical list with color-coded borders and expandable details
- **Email Connection Modal Layout**: Centered modal (max-width: 500px) with vertical layout containing title, description, provider buttons, and action buttons
- **Settings Tab Layout**: Horizontal tab bar at the top of the settings page with tab labels and icons, content area below displaying selected tab's settings
\n### 4.5 Interactive Components
- Hover effects on buttons with subtle color shift
- Focus states for input fields with cyan border
- Smooth transitions (250ms ease-in-out)\n- Toast notifications for upload success/errors, feedback submission, quiz completion, level unlocks, badge earnings, phishing scan results, email threat alerts, and email connection status
- Modal for image preview before analysis
- Clickable resource cards with hover elevation effect
- Level section cards with hover effect and pointer cursor
- Expandable/collapsible level sections with smooth accordion animation
- Practice module items with hover background color change
- Completion checkmark animation when finishing modules
- Badge unlock animation with confetti effect and sound notification
- Badge collection button in user profile with hover effect
- Badge detail modal showing badge name, description, earning date, and rarity tier
- Progress bar fill animation when completing practice modules
- Expandable FAQ items with smooth animation
- Settings menu opens as full-page view with tab navigation\n- Settings tabs with click interaction to switch between different settings categories
- Active tab highlight with smooth transition animation
- 'Collapse all' button with hover effect in quiz section header
- Level unlock animation with glowing effect when prerequisites are met
- Badge notification popup with 'View in Profile' and 'Dismiss' buttons
- Sidebar toggle animation: Smooth slide-in/slide-out with content reflow
- Chat history item hover: Background color change with edit/delete icons fade-in
- Sidebar menu item hover: Background color change with smooth transition
- Active sidebar menu item: Highlighted with accent color border on left side
- Sidebar scroll: Custom scrollbar styling with thin width and rounded thumb
- URL scan button: Pulsing animation during analysis
- Risk level badge animation: Fade-in with scale effect when results appear
- Threat element highlighting: Animated red border pulse on suspicious content
- Copy-to-clipboard button: Appears on hover for URLs and technical data with success feedback
- Export report button: Download icon with loading spinner during PDF generation
- QR code upload: Drag-and-drop zone with visual feedback on file hover
- Email alert notification: Slide-in animation from top-right corner with auto-dismiss after 5 seconds
- Email threat card expansion: Click to expand and view detailed analysis with smooth accordion animation
- Real-time scanning status indicator: Animated spinner icon when email scanning is in progress
- Whitelist/Blacklist management: Drag-and-drop interface for adding/removing email addresses
- **Connect Email Button Hover**: Background color darkens slightly (cyan #06B6D4 becomes #0891B2) with smooth transition (200ms)
- **Connect Email Button Click**: Opens email connection modal with fade-in animation (300ms)
- **Email Connection Modal**: Fade-in overlay background with modal slide-down animation\n- **Provider Selection Buttons**: Hover effect with background color change and pointer cursor
- **OAuth Flow**: Loading spinner displayed during authentication process
- **Connection Success**: Toast notification with success message and automatic button state update
- **Connected Email Dropdown**: Click on connected email button to reveal dropdown menu with smooth slide-down animation
- **Dropdown Menu Items**: Hover effect with background color change for each menu option
- **Settings Tab Click**: Smooth transition animation when switching between tabs with content fade-in effect
- **Settings Tab Hover**: Tab background color change with smooth transition
\n## 5. Reference Images
- User interface reference: image.png
- Design inspiration: image.png
- Additional reference: image.png
- Settings menu reference: image.png
- About section reference: image.png
- Chat interface without plus symbol: image.png
- Input field design reference: image-2.png
- Quiz system reference: image.png
- Badge display reference: image-2.png
- College portal quiz layout reference: WhatsApp Image 2025-12-21 at 23.10.41_f9fb57ad.jpg